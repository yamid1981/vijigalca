#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
svg2gcode.py — печать SVG-файлов перьевым плоттером на FluidNC / GRBL.

Зачем: Inkscape для кириллицы и нот бесполезен, а тут любой вектор,
который умеет сохранять SVG, превращается в G-code с теми же правилами
пера, что и у text2gcode.py.

Перо управляется осью Z:  G0 Z<z_up> — поднять,  G1 Z<z_down> — опустить.

Как пользоваться:

  py svg2gcode.py risunok.svg
  py svg2gcode.py risunok.svg noty.svg          (несколько файлов разом)
  py svg2gcode.py risunok.svg --page a4 --margin 10 --pos center
  py svg2gcode.py risunok.svg --fit up          (растянуть на весь лист)
  py svg2gcode.py risunok.svg --width 180       (принудительно 180 мм шириной)
  py svg2gcode.py noty.svg --near --join-eps 0.2   (меньше подъёмов пера)

Что читается: path (все команды, включая дуги A), line, polyline, polygon,
rect (в т.ч. скруглённый), circle, ellipse, вложенные <g> с transform
(translate / scale / rotate / matrix / skew), <use>.

ЗАЛИВКИ (v1.2): чёрные и просто тёмные заливки ЗАКРАШИВАЮТСЯ штрихом:
  --fill lines    параллельные строки (перо поднимается на переходах)
  --fill zigzag   зигзаг — те же строки, но соединённые там, где внутри
                  фигуры (меньше подъёмов, быстрее)
  --fill cross    перекрёстная штриховка (два прохода, самая плотная)
  --fill off      только контуры, как раньше (по умолчанию)
  --fill-step 0.4    расстояние между штрихами, мм (плотность):
                     сплошной тон — 0.6–0.8 × диаметр шарика пера
                     (для 0.5 мм пера это 0.3–0.4 мм); с просветами —
                     0.8–1.2 мм; крупные плашки быстрее — шаг больше
  --fill-angle 45    угол штриха, градусы (для cross — первый проход)
Белые и светлые заливки (фон, подсветка текста) НЕ закрашиваются.

Что НЕ читается: <text> (надписи шрифтом), <image>, clip/mask.
Если в SVG есть текст — в редакторе-источнике переведите надписи в кривые.

PDF (v1.2): связка с pdf2gcode.py — Word «Сохранить как PDF» -> настоящая
вёрстка (шрифты Word, буквы контурами, чёрные плашки) -> G-code:
  py pdf2gcode.py документ.pdf                (нужен: pip install pymupdf)

Ноты: MuseScore -> Файл -> Экспорт -> SVG -> py svg2gcode.py noty.svg
(надписи темпов/динамики MuseScore пишет текстом — их в экспорте нет:
либо без них, либо перевести в кривые).

Единицы: если в SVG ширина задана в мм/см/дюймах — рисунок печатается
в НАТУРАЛЬНУЮ величину (умещается на лист, если не влезает). Если в px —
пересчёт через --dpi (по умолчанию 96, как в браузере и Inkscape).

Проверить версию:  py svg2gcode.py --version
"""
import argparse
import datetime
import gzip
import math
import os
import re
import sys
import xml.etree.ElementTree as ET

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION = "1.3"

PAGE_SIZES = {
    "a4": (210.0, 297.0),
    "a3": (297.0, 420.0),
    "a5": (148.0, 210.0),
    "letter": (215.9, 279.4),
}

SVGNS = "{http://www.w3.org/2000/svg}"
XLINKNS = "{http://www.w3.org/1999/xlink}"

SKIP_TAGS = {"defs", "clipPath", "mask", "pattern", "marker", "metadata",
             "style", "title", "desc", "script", "symbol"}

# яркость, ниже которой заливка считается «тёмной» и закрашивается
DARK_LUM = 0.82

FILL_LABELS = {"lines": "строки", "zigzag": "зигзаг", "cross": "крест"}

_NAMED = {
    "black": (0, 0, 0), "white": (1, 1, 1), "red": (1, 0, 0),
    "lime": (0, 1, 0), "green": (0, .5, 0), "blue": (0, 0, 1),
    "yellow": (1, 1, 0), "cyan": (0, 1, 1), "magenta": (1, 0, 1),
    "gray": (.5, .5, .5), "grey": (.5, .5, .5), "silver": (.75, .75, .75),
    "darkgray": (.66, .66, .66), "darkgrey": (.66, .66, .66),
    "lightgray": (.83, .83, .83), "lightgrey": (.83, .83, .83),
    "navy": (0, 0, .5), "maroon": (.5, 0, 0), "olive": (.5, .5, 0),
    "purple": (.5, 0, .5), "teal": (0, .5, .5), "orange": (1, .65, 0),
}


def parse_color(s):
    """CSS-цвет -> (r, g, b) 0..1; None если не распознан."""
    s = (s or "").strip().lower()
    if not s:
        return None
    if s in _NAMED:
        return _NAMED[s]
    m = re.match(r"^#([0-9a-f]{3})$", s)
    if m:
        return tuple(int(c * 2, 16) / 255.0 for c in m.group(1))
    m = re.match(r"^#([0-9a-f]{6})$", s)
    if m:
        h = m.group(1)
        return tuple(int(h[k:k + 2], 16) / 255.0 for k in (0, 2, 4))
    m = re.match(r"^rgba?\(([^)]+)\)$", s)
    if m:
        vals = [v.strip() for v in m.group(1).split(",")[:3]]
        try:
            out = []
            for v in vals:
                out.append(float(v[:-1]) / 100.0 if v.endswith("%")
                           else float(v) / 255.0)
            return tuple(out)
        except ValueError:
            return None
    return None


def fill_is_dark(fill):
    """Закрашивать ли заливку с таким цветом (тёмные — да)."""
    if not fill:
        return False
    fill = fill.strip()
    if fill.lower() == "none":
        return False
    if fill.startswith("url(") or fill.lower() in ("currentcolor",):
        return True          # градиент/паттерн/наследованный — считаем тёмным
    rgb = parse_color(fill)
    if rgb is None:
        return True          # незнакомый цвет — лучше закрасить, чем потерять
    lum = 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]
    return lum <= DARK_LUM


def element_fill(el, inherited):
    """Свой fill элемента (style > атрибут) или унаследованный."""
    style = el.get("style", "") or ""
    m = re.search(r"fill\s*:\s*([^;]+)", style, re.I)
    if m:
        f = m.group(1).strip()
        return None if f.lower() == "none" else f
    f = el.get("fill")
    if f is not None:
        f = f.strip()
        return None if f.lower() == "none" else (f or None)
    return inherited

UNIT_MM = {"mm": 1.0, "cm": 10.0, "in": 25.4,
           "pt": 25.4 / 72.0, "pc": 25.4 / 6.0, "q": 0.25}


_DEC = 2  # знаков после запятой в координатах (мм); меняется --decimals


def fmt(v):
    v = float(v)
    if abs(v) < 0.0005:
        v = 0.0
    return f"{v:.{_DEC}f}"


def fword(f):
    """Подача без лишних нулей: 3000.0 -> 'F3000', 762.5 -> 'F762.5'."""
    s = f"{float(f):.3f}".rstrip("0").rstrip(".")
    return "F" + (s or "0")


def parse_xy(s):
    try:
        x, y = s.split(",")
        return (float(x), float(y))
    except Exception:
        raise argparse.ArgumentTypeError(f"Ожидалось 'X,Y', получено {s!r}")


# ---------------------------------------------------------------- единицы

def parse_len_mm(s, dpi):
    """SVG-длина (с единицами) -> мм. None если не распознано."""
    if not s:
        return None
    m = re.match(r"^\s*([+-]?\d*\.?\d+(?:[eE][-+]?\d+)?)\s*([a-zA-Z%]*)\s*$",
                 str(s))
    if not m:
        return None
    v = float(m.group(1))
    u = m.group(2).lower()
    if u in ("", "px", "em", "rem", "ex"):
        return v * dpi / 25.4
    if u == "%":
        return None
    if u in UNIT_MM:
        return v * UNIT_MM[u]
    return None


# ---------------------------------------------------------------- матрицы

def mat_mul(m1, m2):
    """m1 ∘ m2 — m2 применяется к точке первым."""
    a1, b1, c1, d1, e1, f1 = m1
    a2, b2, c2, d2, e2, f2 = m2
    return (
        a1 * a2 + c1 * b2,
        b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2,
        b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1,
        b1 * e2 + d1 * f2 + f1,
    )


def mat_apply(m, x, y):
    return (m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5])


IDENT = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)

TRANSFORM_RE = re.compile(
    r"(translate|scale|rotate|matrix|skewX|skewY)\s*\(([^)]*)\)", re.I
)


def parse_transform(s):
    """Строка transform -> итоговая матрица (левая применяется последней)."""
    if not s:
        return None
    m = IDENT
    for name, argstr in TRANSFORM_RE.findall(s):
        vals = [float(v) for v in re.findall(
            r"[+-]?\d*\.?\d+(?:[eE][-+]?\d+)?", argstr)]
        if not vals:
            continue
        name = name.lower()
        if name == "translate":
            tx = vals[0]
            ty = vals[1] if len(vals) > 1 else 0.0
            t = (1, 0, 0, 1, tx, ty)
        elif name == "scale":
            sx = vals[0]
            sy = vals[1] if len(vals) > 1 else sx
            t = (sx, 0, 0, sy, 0, 0)
        elif name == "rotate":
            a = math.radians(vals[0])
            ca, sa = math.cos(a), math.sin(a)
            t = (ca, sa, -sa, ca, 0, 0)
            if len(vals) >= 3:
                cx, cy = vals[1], vals[2]
                t = mat_mul(mat_mul((1, 0, 0, 1, cx, cy), t),
                            (1, 0, 0, 1, -cx, -cy))
        elif name == "matrix" and len(vals) >= 6:
            t = tuple(vals[:6])
        elif name == "skewx":
            t = (1, 0, math.tan(math.radians(vals[0])), 1, 0, 0)
        elif name == "skewy":
            t = (1, math.tan(math.radians(vals[0])), 0, 1, 0, 0)
        else:
            continue
        m = mat_mul(m, t)
    return m if m != IDENT else None


# ---------------------------------------------------------------- дуги/пути

def arc_to_pts(p0, rx, ry, phi_deg, large, sweep, p1, seg_deg=4.0):
    """Дуга (SVG-параметризация) -> список точек (без стартовой)."""
    if p0 == p1:
        return []
    rx, ry = abs(rx), abs(ry)
    if rx < 1e-12 or ry < 1e-12:
        return [p1]

    phi = math.radians(phi_deg % 360.0)
    cphi, sphi = math.cos(phi), math.sin(phi)
    dx2 = (p0[0] - p1[0]) / 2.0
    dy2 = (p0[1] - p1[1]) / 2.0
    x1p = cphi * dx2 + sphi * dy2
    y1p = -sphi * dx2 + cphi * dy2

    lam = x1p * x1p / (rx * rx) + y1p * y1p / (ry * ry)
    if lam > 1.0:
        s = math.sqrt(lam)
        rx *= s
        ry *= s

    num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p
    den = rx * rx * y1p * y1p + ry * ry * x1p * x1p
    if abs(den) < 1e-12:
        return [p1]
    co = math.sqrt(max(0.0, num / den))
    if large == sweep:
        co = -co
    cxp = co * rx * y1p / ry
    cyp = -co * ry * x1p / rx
    cx = cphi * cxp - sphi * cyp + (p0[0] + p1[0]) / 2.0
    cy = sphi * cxp + cphi * cyp + (p0[1] + p1[1]) / 2.0

    def ang(ux, uy, vx, vy):
        d = ux * vx + uy * vy
        n = math.hypot(ux, uy) * math.hypot(vx, vy)
        if n < 1e-12:
            return 0.0
        a = math.acos(max(-1.0, min(1.0, d / n)))
        if ux * vy - uy * vx < 0:
            a = -a
        return a

    th1 = ang(1.0, 0.0, (x1p - cxp) / rx, (y1p - cyp) / ry)
    ux, uy = (x1p - cxp) / rx, (y1p - cyp) / ry
    vx, vy = (-x1p - cxp) / rx, (-y1p - cyp) / ry
    dth = ang(ux, uy, vx, vy)
    if sweep == 0 and dth > 0:
        dth -= 2 * math.pi
    if sweep == 1 and dth < 0:
        dth += 2 * math.pi

    n = max(4, int(math.ceil(abs(dth) / math.radians(seg_deg))))
    pts = []
    for i in range(1, n + 1):
        th = th1 + dth * i / n
        pts.append((
            cx + rx * math.cos(th) * cphi - ry * math.sin(th) * sphi,
            cy + rx * math.cos(th) * sphi + ry * math.sin(th) * cphi,
        ))
    return pts


TOKEN = re.compile(r"([MmLlHhVvCcSsQqTtAaZz])|([+-]?\d*\.?\d+(?:[eE][-+]?\d+)?)")


def parse_path_d(d, curve_n=16):
    """path d -> список полилиний [(x,y), ...] в координатах пользователя."""
    toks = [(m.group(1), m.group(2)) for m in TOKEN.finditer(d)]
    i = 0
    cx = cy = sx = sy = 0.0
    strokes = []
    cur = []
    cmd = ""
    last_ctrl = None

    def nums():
        nonlocal i
        vals = []
        while i < len(toks) and toks[i][0] is None:
            vals.append(float(toks[i][1]))
            i += 1
        return vals

    def flush():
        nonlocal cur
        if len(cur) >= 2:
            strokes.append(cur)
        cur = []

    while i < len(toks):
        c, v = toks[i]
        if c is not None:
            cmd = c
            i += 1
        if not cmd:
            break
        rel = cmd.islower()
        C = cmd.upper()
        # после команд, не связанных с кривыми, «сглаженная» контрольная
        # точка S/T не наследуется (по спецификации SVG)
        if C not in ("C", "S", "Q", "T"):
            last_ctrl = None

        if C == "M":
            vals = nums()
            for k in range(0, len(vals) - 1, 2):
                x, y = (cx + vals[k], cy + vals[k + 1]) if rel and k > 0 else \
                       ((cx + vals[k], cy + vals[k + 1]) if rel
                        else (vals[k], vals[k + 1]))
                if k > 0:
                    cur.append((x, y))
                    cx, cy = x, y
                else:
                    flush()
                    cx, cy, sx, sy = x, y, x, y
                    cur = [(x, y)]
            if not vals:
                break
            cmd = "l" if rel else "L"
        elif C == "L":
            vals = nums()
            for k in range(0, len(vals) - 1, 2):
                x, y = (cx + vals[k], cy + vals[k + 1]) if rel else \
                       (vals[k], vals[k + 1])
                cur.append((x, y))
                cx, cy = x, y
        elif C == "H":
            for v_ in nums():
                x = cx + v_ if rel else v_
                cur.append((x, cy))
                cx = x
        elif C == "V":
            for v_ in nums():
                y = cy + v_ if rel else v_
                cur.append((cx, y))
                cy = y
        elif C in ("C", "S"):
            vals = nums()
            step = 6 if C == "C" else 4
            for k in range(0, len(vals) - step + 1, step):
                if C == "C":
                    p1 = (cx + vals[k], cy + vals[k + 1]) if rel else \
                         (vals[k], vals[k + 1])
                    p2 = (cx + vals[k + 2], cy + vals[k + 3]) if rel else \
                         (vals[k + 2], vals[k + 3])
                    p3 = (cx + vals[k + 4], cy + vals[k + 5]) if rel else \
                         (vals[k + 4], vals[k + 5])
                else:
                    # S: контрольная точка — отражение предыдущей p2
                    # относительно текущей позиции (спецификация SVG)
                    p1 = (2 * cx - last_ctrl[0], 2 * cy - last_ctrl[1]) \
                        if last_ctrl else (cx, cy)
                    p2 = (cx + vals[k], cy + vals[k + 1]) if rel else \
                         (vals[k], vals[k + 1])
                    p3 = (cx + vals[k + 2], cy + vals[k + 3]) if rel else \
                         (vals[k + 2], vals[k + 3])
                for j in range(1, curve_n + 1):
                    t = j / curve_n
                    mt = 1 - t
                    cur.append((
                        mt**3 * cx + 3 * mt * mt * t * p1[0] +
                        3 * mt * t * t * p2[0] + t**3 * p3[0],
                        mt**3 * cy + 3 * mt * mt * t * p1[1] +
                        3 * mt * t * t * p2[1] + t**3 * p3[1],
                    ))
                last_ctrl = p2
                cx, cy = p3
        elif C in ("Q", "T"):
            vals = nums()
            step = 4 if C == "Q" else 2
            for k in range(0, len(vals) - step + 1, step):
                if C == "Q":
                    p1 = (cx + vals[k], cy + vals[k + 1]) if rel else \
                         (vals[k], vals[k + 1])
                    p2 = (cx + vals[k + 2], cy + vals[k + 3]) if rel else \
                         (vals[k + 2], vals[k + 3])
                else:
                    # T: контрольная точка — отражение предыдущей p1
                    # относительно текущей позиции (спецификация SVG)
                    p1 = (2 * cx - last_ctrl[0], 2 * cy - last_ctrl[1]) \
                        if last_ctrl else (cx, cy)
                    p2 = (cx + vals[k], cy + vals[k + 1]) if rel else \
                         (vals[k], vals[k + 1])
                for j in range(1, curve_n + 1):
                    t = j / curve_n
                    mt = 1 - t
                    cur.append((
                        mt**2 * cx + 2 * mt * t * p1[0] + t * t * p2[0],
                        mt**2 * cy + 2 * mt * t * p1[1] + t * t * p2[1],
                    ))
                last_ctrl = p1
                cx, cy = p2
        elif C == "A":
            vals = nums()
            for k in range(0, len(vals) - 6, 7):
                rx, ry = abs(vals[k]), abs(vals[k + 1])
                rot = vals[k + 2]
                laf = 1 if vals[k + 3] else 0
                swp = 1 if vals[k + 4] else 0
                x, y = (cx + vals[k + 5], cy + vals[k + 6]) if rel else \
                       (vals[k + 5], vals[k + 6])
                for p in arc_to_pts((cx, cy), rx, ry, rot, laf, swp, (x, y)):
                    cur.append(p)
                cx, cy = x, y
        elif C == "Z":
            if cur and (abs(cur[-1][0] - sx) > 1e-9 or
                        abs(cur[-1][1] - sy) > 1e-9):
                cur.append((sx, sy))
            flush()
            cx, cy = sx, sy
        else:
            break
    flush()
    return strokes


# ---------------------------------------------------------------- элементы

def localname(el):
    return el.tag.replace(SVGNS, "").replace("{http://www.w3.org/1999/xlink}",
                                             "") if isinstance(el.tag, str) \
        else ""


def nums_pairs(s):
    vals = [float(v) for v in re.findall(
        r"[+-]?\d*\.?\d+(?:[eE][-+]?\d+)?", s or "")]
    return [(vals[k], vals[k + 1]) for k in range(0, len(vals) - 1, 2)]


def shape_polylines(el):
    """Локальные полилинии фигуры (без transform)."""
    tag = localname(el)
    out = []

    if tag == "path":
        d = el.get("d", "")
        if d.strip():
            out.extend(parse_path_d(d))

    elif tag == "line":
        try:
            x1 = float(el.get("x1", 0)); y1 = float(el.get("y1", 0))
            x2 = float(el.get("x2", 0)); y2 = float(el.get("y2", 0))
            out.append([(x1, y1), (x2, y2)])
        except ValueError:
            pass

    elif tag in ("polyline", "polygon"):
        pts = nums_pairs(el.get("points", ""))
        if len(pts) >= 2:
            pts = list(pts)
            if tag == "polygon" and pts[0] != pts[-1]:
                pts.append(pts[0])
            out.append(pts)

    elif tag == "rect":
        try:
            x = float(el.get("x", 0)); y = float(el.get("y", 0))
            w = float(el.get("width", 0)); h = float(el.get("height", 0))
        except ValueError:
            return out
        if w <= 0 or h <= 0:
            return out
        rx = ry = 0.0
        try:
            rx = abs(float(el.get("rx", 0) or 0))
            ry = abs(float(el.get("ry", 0) or 0))
        except ValueError:
            pass
        rx = min(rx or ry, w / 2.0)
        ry = min(ry or rx, h / 2.0)
        if rx > 0 and ry > 0:
            pts = [(x + rx, y)]
            pts += arc_to_pts((x + rx, y), rx, ry, 0, 0, 1, (x + w, y + ry))
            pts.append((x + w, y + h - ry))
            pts += arc_to_pts((x + w, y + h - ry), rx, ry, 0, 0, 1,
                              (x + w - rx, y + h))
            pts.append((x + rx, y + h))
            pts += arc_to_pts((x + rx, y + h), rx, ry, 0, 0, 1,
                              (x, y + h - ry))
            pts.append((x, y + ry))
            pts += arc_to_pts((x, y + ry), rx, ry, 0, 0, 1, (x + rx, y))
            out.append(pts)
        else:
            out.append([(x, y), (x + w, y), (x + w, y + h),
                        (x, y + h), (x, y)])

    elif tag in ("circle", "ellipse"):
        try:
            cx = float(el.get("cx", 0)); cy = float(el.get("cy", 0))
            if tag == "circle":
                r = abs(float(el.get("r", 0)))
                rx = ry = r
            else:
                rx = abs(float(el.get("rx", 0)))
                ry = abs(float(el.get("ry", 0)))
        except ValueError:
            return out
        if rx <= 0 or ry <= 0:
            return out
        pts = []
        n = 72
        for k in range(n + 1):
            a = 2 * math.pi * k / n
            pts.append((cx + rx * math.cos(a), cy + ry * math.sin(a)))
        out.append(pts)

    return out


def collect(el, M, out, ctx, fill=None):
    """Сбор геометрии. out — элементы {"polys": [...], "fill": цвет|None}:
    полилинии рисуются контуром, а при тёмном fill закрашиваются штрихом."""
    if not isinstance(el.tag, str):
        return
    tag = localname(el)
    if tag in SKIP_TAGS:
        return

    style = el.get("style", "") or ""
    if re.search(r"display\s*:\s*none", style, re.I) or \
            el.get("display") == "none":
        return

    T = parse_transform(el.get("transform"))
    M2 = mat_mul(M, T) if T else M

    if tag in ("g", "a", "svg", "symbol", "switch"):
        child_fill = element_fill(el, fill)
        for ch in list(el):
            collect(ch, M2, out, ctx, child_fill)

    elif tag == "use":
        href = el.get("href") or el.get(XLINKNS + "href")
        if href and href.startswith("#"):
            tgt = ctx["ids"].get(href[1:])
            if tgt is not None and id(tgt) not in ctx["stack"]:
                try:
                    dx = float(el.get("x", 0) or 0)
                    dy = float(el.get("y", 0) or 0)
                except ValueError:
                    dx = dy = 0.0
                M3 = mat_mul(M2, (1, 0, 0, 1, dx, dy)) \
                    if (dx or dy) else M2
                use_fill = element_fill(el, fill)
                ctx["stack"].add(id(tgt))
                if localname(tgt) == "symbol":
                    # <use> на <symbol> рисуем, хотя symbol в SKIP_TAGS
                    for ch in list(tgt):
                        collect(ch, M3, out, ctx, use_fill)
                else:
                    collect(tgt, M3, out, ctx, use_fill)
                ctx["stack"].discard(id(tgt))

    elif tag in ("path", "line", "polyline", "polygon", "rect",
                 "circle", "ellipse"):
        pls = [[mat_apply(M2, x, y) for x, y in pl]
               for pl in shape_polylines(el)]
        if pls:
            f = element_fill(el, fill)
            out.append({"polys": pls, "fill": f})

    elif tag == "text" or tag == "tspan":
        ctx["texts"] += 1

    elif tag == "image":
        ctx["images"] += 1


def load_svg_geometry(path, dpi):
    """SVG-файл -> (геометрия в px (y вниз), инфо о размере, warnings).
    Геометрия — список {"polys": [...], "fill": цвет|None}."""
    with open(path, "rb") as f:
        head = f.read(2)
    opener = gzip.open if head == b"\x1f\x8b" else open

    with opener(path, "rb") as f:
        tree = ET.parse(f)
    root = tree.getroot()

    ids = {}
    for el in root.iter():
        if isinstance(el.tag, str) and el.get("id"):
            ids[el.get("id")] = el

    vb = root.get("viewBox")
    vb_w = vb_h = None
    if vb:
        vals = [float(v) for v in re.findall(
            r"[+-]?\d*\.?\d+(?:[eE][-+]?\d+)?", vb)]
        if len(vals) >= 4:
            vb_w, vb_h = vals[2], vals[3]

    w_mm = parse_len_mm(root.get("width"), dpi)
    h_mm = parse_len_mm(root.get("height"), dpi)

    if w_mm and vb_w:
        # ширина в мм + viewBox: координаты пользователя -> мм напрямую
        s = w_mm / vb_w
        unit_info = f"1:1 ({root.get('width')})"
    elif w_mm and h_mm and vb_w is None:
        # ширина в мм, но нет viewBox: координаты считаем px при dpi
        s = dpi / 25.4
        unit_info = f"px->мм по dpi {dpi:g} ({root.get('width')})"
    else:
        s = dpi / 25.4
        unit_info = f"px->мм по dpi {dpi:g}"

    out = []
    ctx = {"ids": ids, "stack": set(), "texts": 0, "images": 0}
    collect(root, IDENT, out, ctx)

    info = {
        "scale": s,
        "unit_info": unit_info,
        "texts": ctx["texts"],
        "images": ctx["images"],
        "n_shapes": len(out),
        "n_paths": sum(len(g["polys"]) for g in out),
        "filled_dark": sum(1 for g in out if fill_is_dark(g["fill"])),
        "vb_w": vb_w,
        "vb_h": vb_h,
        "w_mm": w_mm,
        "h_mm": h_mm,
    }
    return out, info


# ---------------------------------------------------------------- заливка

def _point_inside(x, y, polys):
    """Точка внутри объединения полигонов? (чётно-нечётное правило)."""
    inside = False
    for pts in polys:
        n = len(pts)
        j = n - 1
        for i in range(n):
            xi, yi = pts[i]
            xj, yj = pts[j]
            if (yi > y) != (yj > y):
                xc = (xj - xi) * (y - yi) / (yj - yi) + xi
                if x < xc:
                    inside = not inside
            j = i
    return inside


def _hatch_pass(subpaths, step, angle_deg, connect):
    """Один проход штриховки параллельными строками.
    subpaths — замкнутые контуры области (мм, y вверх);
    connect=True — попробовать сшивать строки зигзагом (меньше подъёмов).
    Возвращает список полилиний."""
    step = max(0.05, float(step))
    a = math.radians(float(angle_deg) % 180.0)
    ca, sa = math.cos(a), math.sin(a)

    def fwd(x, y):      # поворот на -angle: штрихи станут горизонтальными
        return (x * ca + y * sa, -x * sa + y * ca)

    def back(x, y):     # и обратно
        return (x * ca - y * sa, x * sa + y * ca)

    rp = [[fwd(x, y) for x, y in sp] for sp in subpaths]
    ys = [p[1] for sp in rp for p in sp]
    if not ys:
        return []
    vmin, vmax = min(ys), max(ys)
    if vmax - vmin < 1e-9:
        return []

    n_rows = max(1, int(math.ceil((vmax - vmin) / step - 1e-9)) + 1)
    v0 = vmin + max(0.0, (vmax - vmin) - (n_rows - 1) * step) / 2.0

    out = []
    cur = None            # текущая незавершённая полилиния (для зигзага)
    prev_end = None

    def row_segments(v):
        xs = []
        for sp in rp:
            n = len(sp)
            j = n - 1
            for i in range(n):
                x1, y1 = sp[i]
                x2, y2 = sp[j]
                if (y1 > v) != (y2 > v):
                    xs.append(x1 + (v - y1) * (x2 - x1) / (y2 - y1))
                j = i
        if len(xs) < 2:
            return []
        xs.sort()
        if len(xs) % 2:
            xs.pop()
        segs = [(xs[k], xs[k + 1]) for k in range(0, len(xs) - 1, 2)]
        return [s for s in segs if s[1] - s[0] >= 0.03]

    def try_connect(p_from, p_to):
        """Можно ли прочертить связку, не выходя из фигуры?"""
        d = math.hypot(p_to[0] - p_from[0], p_to[1] - p_from[1])
        if d < 1e-9:
            return True
        if d > step * 6.0:
            return False
        n = max(2, int(d / (step / 3.0)) + 1)
        for k in range(1, n):
            t = k / n
            x = p_from[0] + (p_to[0] - p_from[0]) * t
            y = p_from[1] + (p_to[1] - p_from[1]) * t
            if not _point_inside(x, y, rp):
                return False
        return True

    for r in range(n_rows):
        v = v0 + r * step
        segs = row_segments(v)
        if not segs:
            prev_end = None
            continue
        rev = (r % 2 == 1)          # нечётный ряд рисуем справа налево
        if rev:
            segs = [(b, a) for a, b in reversed(segs)]

        for x1, x2 in segs:
            p1, p2 = (x1, v), (x2, v)
            if cur is not None and connect and prev_end is not None and \
                    try_connect(prev_end, p1):
                cur.append(back(*p1))
            else:
                if cur is not None:
                    out.append(cur)
                cur = [back(*p1)]
            cur.append(back(*p2))
            prev_end = p2
    if cur is not None:
        out.append(cur)
    return out


def hatch_region(subpaths, step, angle_deg, mode):
    """Закраска области выбранным типом штриха.
    mode: lines | zigzag | cross. Возвращает полилинии (мм)."""
    if mode == "cross":
        return (_hatch_pass(subpaths, step, angle_deg, False) +
                _hatch_pass(subpaths, step, float(angle_deg) + 90.0, False))
    return _hatch_pass(subpaths, step, angle_deg, mode == "zigzag")


# ---------------------------------------------------------------- запуск

def dedupe(pts):
    if len(pts) < 2:
        return pts
    out = [pts[0]]
    for p in pts[1:]:
        dx = p[0] - out[-1][0]
        dy = p[1] - out[-1][1]
        if dx * dx + dy * dy > 1e-12:
            out.append(p)
    return out


def merge_polylines(polys, eps):
    """Сшивка концов полилиний в непрерывные трассы (как в text2gcode)."""
    remaining = [list(p) for p in polys]
    if eps <= 0 or len(remaining) < 2:
        return remaining
    eps2 = eps * eps
    merged = []
    cur = remaining.pop(0)

    def nearest(px, py):
        bi, bd, brev = -1, float("inf"), False
        for i, s in enumerate(remaining):
            d = (s[0][0] - px) ** 2 + (s[0][1] - py) ** 2
            if d < bd:
                bd, bi, brev = d, i, False
            d = (s[-1][0] - px) ** 2 + (s[-1][1] - py) ** 2
            if d < bd:
                bd, bi, brev = d, i, True
        return bi, bd, brev

    while remaining:
        bi, bd, brev = nearest(cur[-1][0], cur[-1][1])
        if bd <= eps2:
            s = remaining.pop(bi)
            if brev:
                s.reverse()
            cur.extend(s)
            continue
        bi, bd, brev = nearest(cur[0][0], cur[0][1])
        if bd <= eps2:
            s = remaining.pop(bi)
            if brev:
                s.reverse()
            cur = s + cur
            continue
        merged.append(cur)
        bi, bd, brev = nearest(cur[-1][0], cur[-1][1])
        s = remaining.pop(bi)
        if brev:
            s.reverse()
        cur = s
    merged.append(cur)
    return merged


def order_near(polys):
    """Жадный порядок обхода: каждая следующая полилиния — ближайшая."""
    remaining = [list(p) for p in polys]
    ordered = []
    pos = (0.0, 0.0)
    while remaining:
        bi, bd, brev = -1, float("inf"), False
        for i, s in enumerate(remaining):
            d = (s[0][0] - pos[0]) ** 2 + (s[0][1] - pos[1]) ** 2
            if d < bd:
                bd, bi, brev = d, i, False
            d = (s[-1][0] - pos[0]) ** 2 + (s[-1][1] - pos[1]) ** 2
            if d < bd:
                bd, bi, brev = d, i, True
        s = remaining.pop(bi)
        if brev:
            s.reverse()
        ordered.append(s)
        pos = s[-1]
    return ordered


def emit_gcode(polys, args, header_lines):
    g = list(header_lines)
    g.append("G21 ; mm")
    g.append("G90 ; absolute")
    g.append(f"G0 Z{fmt(args.z_up)} ; перо вверх")

    # Подача модальная (как в GRBL и положено): слово F ставится только
    # при СМЕНЕ скорости. Раньше F{...} писалось в каждой строке — файл
    # был толще на ~40%, а каждый лишний байт — это лишнее время на
    # запись в SD и печать по USB.
    last_f = [None]

    def fw(f):
        if last_f[0] is None or abs(float(f) - last_f[0]) > 0.001:
            last_f[0] = float(f)
            return fword(f)
        return ""

    stats = {"strokes": 0, "draw": 0.0, "travel": 0.0, "downs": 0}
    z_hop = getattr(args, "z_hop", 0.0) or 0.0
    hop = z_hop if 0.0 < z_hop < args.z_up else 0.0

    prev_end = None
    first = True
    for pts in polys:
        pts = list(pts)
        if len(pts) == 1 or (len(pts) == 2 and pts[0] == pts[1]):
            pts = [pts[0], (pts[0][0] + 0.05, pts[0][1])]
        if first:
            g.append(f"G0 X{fmt(pts[0][0])} Y{fmt(pts[0][1])} "
                     f"{fw(args.f_travel)}".rstrip())
            g.append(f"G1 Z{fmt(args.z_down)} {fw(args.f_z)}".rstrip())
            first = False
        else:
            d = math.hypot(pts[0][0] - prev_end[0], pts[0][1] - prev_end[1])
            stats["travel"] += d
            z_lvl = hop if (hop and d <= 5.0) else args.z_up
            g.append(f"G0 Z{fmt(z_lvl)}")
            g.append(f"G0 X{fmt(pts[0][0])} Y{fmt(pts[0][1])} "
                     f"{fw(args.f_travel)}".rstrip())
            g.append(f"G1 Z{fmt(args.z_down)} {fw(args.f_z)}".rstrip())

        stats["downs"] += 1
        cur = pts[0]
        for px, py in pts[1:]:
            g.append(f"G1 X{fmt(px)} Y{fmt(py)} {fw(args.f_draw)}".rstrip())
            stats["draw"] += math.hypot(px - cur[0], py - cur[1])
            cur = (px, py)
        stats["strokes"] += 1
        prev_end = cur

    g.append("; конец")
    g.append(f"G0 Z{fmt(args.z_up + 5)} ; перо высоко вверх")
    if args.home:
        g.append(f"G0 X{fmt(args.home[0])} Y{fmt(args.home[1])} "
                 f"{fw(args.f_travel)}".rstrip())
    return g, stats


def render_preview(png_path, polys, args, page=None, drawn_bbox=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)
    if page:
        pw, ph = page
        m = args.margin
        ax.add_patch(plt.Rectangle((0, 0), pw, ph, fill=False,
                                   ec="#999999", lw=1.2))
        if pw - 2 * m > 0 and ph - 2 * m > 0:
            ax.add_patch(plt.Rectangle((m, m), pw - 2 * m, ph - 2 * m,
                                       fill=False, ec="#cccccc", lw=0.8,
                                       ls="--"))
        ax.set_xlim(-6, pw + 6)
        ax.set_ylim(-6, ph + 6)
    elif drawn_bbox:
        minx, miny, maxx, maxy = drawn_bbox
        pad = max(5.0, (maxx - minx) * 0.05)
        ax.set_xlim(minx - pad, maxx + pad)
        ax.set_ylim(miny - pad, maxy + pad)

    for pts in polys:
        if len(pts) >= 2:
            xs, ys = zip(*pts)
            ax.plot(xs, ys, "k-", lw=1.0)
        elif pts:
            ax.plot([pts[0][0]], [pts[0][1]], "k.", ms=2)

    ax.set_aspect("equal")
    ax.axis("off")
    fig.savefig(png_path, dpi=110)
    plt.close(fig)


def convert_one(src, args):
    global _DEC
    _DEC = max(2, min(4, int(getattr(args, "decimals", 2) or 2)))
    base = os.path.splitext(src)[0]
    out = args.out or (base + ".nc")
    if not out.lower().endswith(".nc"):
        out += ".nc"

    geoms, info = load_svg_geometry(src, args.dpi)
    s = info["scale"]

    def to_mm(pl):
        return [(x * s, -y * s) for x, y in pl]

    mm_polys = [dedupe(to_mm(pl)) for g in geoms for pl in g["polys"]]
    mm_polys = [p for p in mm_polys if len(p) >= 2]

    # области закраски: замкнутые контуры фигур с ТЕМНОЙ заливкой
    fill_regions = [[to_mm(pl) for pl in g["polys"]]
                    for g in geoms if fill_is_dark(g["fill"])]
    light_fills = sum(1 for g in geoms
                      if g["fill"] and not fill_is_dark(g["fill"]))

    if not mm_polys and not fill_regions:
        extra = (" — похоже, это СКАН или фото: перо растровые картинки "
                 "не печатает, нужен PDF/SVG с текстом и вектором"
                 if info.get("images") else "")
        sys.exit(f"В {src!r} не найдено контуров для пера{extra}")
    if not mm_polys:
        sys.exit(f"В {src!r} только заливки — включите закраску: --fill lines")

    if info["texts"]:
        print(f"   ! {info['texts']} текстовых надписей в SVG пропущено "
              f"(переведите их в кривые в программе-источнике)")
    if info["images"]:
        print(f"   ! {info['images']} растровых картинок пропущено "
              f"(перо не печатает растры)")
    if fill_regions and getattr(args, "fill", "off") == "off":
        print(f"   * {len(fill_regions)} фигур с заливкой печатаются "
              f"контуром (закрасить: --fill lines/zigzag/cross)")
    elif fill_regions:
        print(f"   * закрашиваю {len(fill_regions)} фигур: "
              f"{FILL_LABELS[args.fill]}, шаг {args.fill_step:g} мм, "
              f"угол {args.fill_angle:g}°")
    if light_fills:
        print(f"   * светлых заливок пропущено: {light_fills} "
              f"(фон/подсветка — перо их не красит)")

    xs = [p[0] for pl in mm_polys for p in pl]
    ys = [p[1] for pl in mm_polys for p in pl]
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    W, H = maxx - minx, maxy - miny

    # ---- итоговый масштаб: fit * args.scale
    if args.page != "off":
        pw_full, ph_full = PAGE_SIZES[args.page]
        pw, ph = (pw_full, ph_full) if args.orient == "portrait" \
            else (ph_full, pw_full)
        avail_w, avail_h = pw - 2 * args.margin, ph - 2 * args.margin
    else:
        pw = ph = None

    if args.width:
        k = args.width / W
    elif args.height:
        k = args.height / H
    elif args.page == "off" or args.fit == "none":
        k = 1.0
    elif args.fit == "up":
        k = min(avail_w / W, avail_h / H)
    else:  # down
        k = min(1.0, avail_w / W, avail_h / H)
    k *= args.scale

    mm_polys = [[(x * k, y * k) for x, y in pl] for pl in mm_polys]
    fill_regions = [[[(x * k, y * k) for x, y in pl] for pl in sub]
                    for sub in fill_regions]
    xs = [p[0] for pl in mm_polys for p in pl]
    ys = [p[1] for pl in mm_polys for p in pl]
    minx, maxx, miny, maxy = min(xs), max(xs), min(ys), max(ys)
    W, H = maxx - minx, maxy - miny

    # ---- позиционирование
    ps = getattr(args, "page_size_mm", None)
    if args.page == "off":
        if ps:
            # PDF: страница известна — контур страницы в координатах:
            # x: 0..pw, y: -ph..0 (после переворота оси Y). Ставим рисунок
            # на его НАСТОЯЩЕЕ место на листе (ноль — левый нижний угол).
            dx = args.x0 - 0.0
            dy = args.y0 - (-ps[1])
        else:
            dx = args.x0 - minx
            dy = args.y0 - miny
    else:
        avail_w, avail_h = pw - 2 * args.margin, ph - 2 * args.margin
        if args.pos == "center":
            dx = args.margin + (avail_w - W) / 2.0 - minx
            dy = args.margin + (avail_h - H) / 2.0 - miny
        else:  # topleft
            dx = args.margin - minx
            dy = args.margin - miny

    mm_polys = [[(x + dx, y + dy) for x, y in pl] for pl in mm_polys]
    fill_regions = [[[(x + dx, y + dy) for x, y in pl] for pl in sub]
                    for sub in fill_regions]

    # ---- оптимизация пера
    eps = args.join_eps
    if eps > 0:
        n_raw = len(mm_polys)
        mm_polys = merge_polylines(mm_polys, eps)
        if len(mm_polys) < n_raw:
            print(f"   * сшивка контуров (допуск {eps:.2f} мм): "
                  f"{n_raw} -> {len(mm_polys)}")

    if args.near:
        mm_polys = order_near(mm_polys)

    if args.double:
        mm_polys = mm_polys + [list(p) for p in mm_polys]

    # ---- закраска заливок выбранным штрихом
    if fill_regions and args.fill != "off":
        t0 = datetime.datetime.now()
        n_hatch = 0
        for sub in fill_regions:
            hp = hatch_region(sub, args.fill_step, args.fill_angle, args.fill)
            mm_polys.extend(hp)
            n_hatch += len(hp)
        dt = (datetime.datetime.now() - t0).total_seconds()
        print(f"   * штрихов закраски: {n_hatch} "
              f"({dt:.1f} c расчёта)")

    # ---- итог
    if args.page != "off":
        xs = [p[0] for pl in mm_polys for p in pl]
        ys = [p[1] for pl in mm_polys for p in pl]
        inside = (min(xs) >= args.margin - 0.5 and
                  min(ys) >= args.margin - 0.5 and
                  max(xs) <= pw - args.margin + 0.5 and
                  max(ys) <= ph - args.margin + 0.5)
        size_txt = f"{max(xs) - min(xs):.0f}x{max(ys) - min(ys):.0f} мм"
        if inside:
            print(f"   габарит {size_txt} — внутри листа "
                  f"{args.page.upper()} {pw:.0f}x{ph:.0f} мм")
        else:
            print(f"   ! ВНИМАНИЕ: габарит {size_txt} выходит за "
                  f"печатную область {args.page.upper()} "
                  f"{pw:.0f}x{ph:.0f} мм (поле {args.margin:g} мм)")

    pct = f", масштаб {k * 100:.0f}%" if abs(k - 1.0) > 1e-6 else ", 1:1"
    orient = args.orient if args.page != "off" else "portrait"
    page_note = (f"; лист {args.page.upper()} {orient}, "
                 f"поле {args.margin:g} мм, рисунок {W:.0f}x{H:.0f} мм"
                 + pct) if args.page != "off" else \
                f"; лист без ограничений, рисунок {W:.0f}x{H:.0f} мм" + pct

    header = [
        "; ==== svg2gcode.py — перьевой плоттер FluidNC/GRBL ===="
        + ("; закраска заливок: "
           f"{FILL_LABELS[args.fill]}, шаг {args.fill_step:g} мм, "
           f"угол {args.fill_angle:g}°"
           if (fill_regions and args.fill != "off") else ""),
        f"; источник: {src}",
        f"; страница {ps[0]:.0f}x{ps[1]:.0f} мм из PDF: ноль станка — "
        f"ЛЕВЫЙ НИЖНИЙ угол листа, печать 1:1"
        if getattr(args, "page_size_mm", None) else "",
        page_note,
        f"; единицы: {info['unit_info']}",
        f"; перо: Z{fmt(args.z_down)}=вниз, Z{fmt(args.z_up)}=вверх  "
        f"подачи: рисование F{fmt(args.f_draw)}, "
        f"подвод F{fmt(args.f_travel)}, Z F{fmt(args.f_z)}",
        f"; создано: {datetime.datetime.now().isoformat(timespec='seconds')}",
    ]

    g, stats = emit_gcode(mm_polys, args, header)
    with open(out, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(g) + "\n")

    preview_path = None
    if args.preview:
        pv = str(args.preview)
        if pv.lower() == "auto":
            preview_path = os.path.splitext(out)[0] + ".png"
        elif os.path.isdir(pv):
            preview_path = os.path.join(
                pv, os.path.splitext(os.path.basename(out))[0] + ".png")
        else:
            preview_path = pv
    if preview_path:
        try:
            render_preview(preview_path, mm_polys, args,
                           page=(pw, ph) if args.page != "off" else None)
            print(f"   превью -> {preview_path}")
        except ImportError:
            print("   ! для превью нужен matplotlib:  pip install matplotlib")
        except Exception as e:
            print(f"   ! превью не создано: {e}")

    return out, stats


def build_parser():
    ap = argparse.ArgumentParser(
        description="SVG -> G-code для перьевого плоттера (FluidNC/GRBL)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("--version", action="version",
                    version=f"svg2gcode {VERSION}")
    ap.add_argument("svg", nargs="+", help="входные .svg (или .svgz) файлы")
    ap.add_argument("--out", default=None,
                    help="имя .nc (только при одном входном файле)")

    ap.add_argument("--page", choices=["a4", "a3", "a5", "letter", "off"],
                    default="a4", help="лист; off = без ограничений")
    ap.add_argument("--orient", choices=["portrait", "landscape"],
                    default="portrait", help="ориентация листа")
    ap.add_argument("--margin", type=float, default=10.0,
                    help="поле от края листа, мм")
    ap.add_argument("--pos", choices=["center", "topleft"], default="center",
                    help="размещение рисунка на листе")
    ap.add_argument("--fit", choices=["down", "up", "none"], default="down",
                    help="down = уменьшить, если не влезает; up = растянуть "
                         "на весь лист; none = 1:1 как есть")
    ap.add_argument("--scale", type=float, default=1.0,
                    help="дополнительный множитель размера")
    ap.add_argument("--width", type=float, default=None,
                    help="принудительная ширина рисунка, мм")
    ap.add_argument("--height", type=float, default=None,
                    help="принудительная высота рисунка, мм")
    ap.add_argument("--dpi", type=float, default=96.0,
                    help="dpi для px-координат (96 = браузер/Inkscape)")
    ap.add_argument("--x0", type=float, default=0.0,
                    help="X рисунка при --page off, мм")
    ap.add_argument("--y0", type=float, default=0.0,
                    help="Y рисунка при --page off, мм")

    ap.add_argument("--join-eps", type=float, default=0.0, metavar="ММ",
                    help="сшивка концов контуров в непрерывные линии, мм; "
                         "0 — выключено")
    ap.add_argument("--near", action="store_true",
                    help="рисовать в порядке близости (меньше подвода)")
    ap.add_argument("--double", action="store_true",
                    help="пройти каждый контур дважды (жирнее линия)")

    ap.add_argument("--fill", choices=["lines", "zigzag", "cross", "off"],
                    default="off",
                    help="закраска тёмных заливок: строки / зигзаг (без "
                         "подъёмов) / крест (два прохода) / off = контуры")
    ap.add_argument("--fill-step", type=float, default=0.4, metavar="ММ",
                    help="шаг штриха закраски, мм (плотность): сплошной "
                         "тон = 0.6-0.8 диаметра шарика пера")
    ap.add_argument("--fill-angle", type=float, default=45.0, metavar="ГРАД",
                    help="угол штриха закраски, градусы (для cross первый "
                         "проход; второй — +90)")

    ap.add_argument("--z-hop", type=float, default=0.0, metavar="ММ",
                    help="короткие переходы (до 5 мм) поднимать на эту "
                         "высоту вместо --z-up, мм")
    ap.add_argument("--z-up", type=float, default=4.0, help="Z вверх, мм")
    ap.add_argument("--z-down", type=float, default=0.0, help="Z вниз, мм")
    ap.add_argument("--f-draw", type=float, default=3000.0,
                    help="подача рисования, мм/мин")
    ap.add_argument("--f-travel", type=float, default=9000.0,
                    help="подача подвода, мм/мин")
    ap.add_argument("--f-z", type=float, default=9000.0,
                    help="подача Z, мм/мин")
    ap.add_argument("--decimals", type=int, default=2, choices=(2, 3, 4),
                    help="знаков в координатах: 2 = шаг 0.01 мм (файл "
                         "меньше на ~25%%, запись на SD и печать быстрее); "
                         "3 = как в старых версиях")
    ap.add_argument("--home", type=parse_xy, default=None, metavar="'X,Y'",
                    help="вернуться в точку 'X,Y' в конце")
    ap.add_argument("--preview", nargs="?", const="auto", default=None,
                    metavar="PATH", help="PNG предпросмотр (auto или файл)")

    return ap


def main():
    args = build_parser().parse_args()

    if args.out and len(args.svg) > 1:
        sys.exit("--out нельзя совмещать с несколькими входными файлами")
    if args.width and args.height:
        sys.exit("Задайте что-то одно: --width или --height")

    total_min = 0.0
    for src in args.svg:
        if not os.path.isfile(src):
            sys.exit(f"Файл не найден: {src!r}")
        print(f"-- {src}")
        out, stats = convert_one(src, args)

        t_draw = stats["draw"] / args.f_draw if args.f_draw else 0.0
        t_z = stats["downs"] * abs(args.z_up - args.z_down) / args.f_z \
            if args.f_z else 0.0
        t_tr = stats["travel"] / args.f_travel if args.f_travel else 0.0
        minutes = t_draw + t_z + t_tr
        total_min += minutes

        print(f"OK -> {out}")
        print(f"   контуров (опусканий пера): {stats['strokes']}, "
              f"путь рисования: {stats['draw']:.0f} мм, "
              f"подвод: {stats['travel']:.0f} мм, "
              f"оценка времени ~{minutes:.1f} мин")

    if len(args.svg) > 1:
        print(f"Готово: файлов {len(args.svg)}, "
              f"оценка времени ~{total_min:.1f} мин")


if __name__ == "__main__":
    main()
