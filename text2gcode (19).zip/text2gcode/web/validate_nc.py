#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Валидатор G-code: состояние пера, границы листа, дубли-ходы.

Настройки листа читаются из шапки .nc (строка '; лист A4 portrait, поле 10 мм').
Если шапки нет — проверяются обе ориентации A4.
"""
import re
import sys

path = sys.argv[1]

PAGE_SIZES = {  # (ширина, высота) в портретной ориентации
    "A4": (210.0, 297.0),
    "A3": (297.0, 420.0),
    "A5": (148.0, 210.0),
    "LETTER": (215.9, 279.4),
}

page_re = re.compile(
    r";\s*лист\s+(A4|A3|A5|LETTER)\s+(portrait|landscape)\s*,\s*поле\s*([\d.]+)\s*мм"
)

# «лист OFF» / «без ограничений» — границы листа не проверяем
page_off_re = re.compile(r";\s*лист\s+(?:OFF|без\s+ограничений)", re.I)

page_name = None
orient = None
margin = None
page_off = False

with open(path, encoding="utf-8") as f:
    head = [next(f, "") for _ in range(30)]

for hline in head:
    if page_off_re.search(hline):
        page_off = True
        break
    m = page_re.search(hline)
    if m:
        page_name, orient, margin = (
            m.group(1).upper(), m.group(2), float(m.group(3)),
        )
        break

if page_off:
    pw = ph = None
    MARGIN = 0.0
    page_txt = "без ограничений (лист не задан)"
elif page_name:
    pw0, ph0 = PAGE_SIZES[page_name]
    pw, ph = (pw0, ph0) if orient == "portrait" else (ph0, pw0)
    MARGIN = margin
    page_txt = f"{page_name} {orient}, поле {margin:g} мм"
else:
    # шапки нет: принимаем любую ориентацию A4
    pw = ph = None
    MARGIN = 10.0
    page_txt = "A4 (ориентация не задана — годится любая)"

pen_down = False
minx = miny = 1e9
maxx = maxy = -1e9
errors = []
n_down = n_up = 0
prev_xy = None
dup_moves = 0
n_draw = 0

with open(path, encoding="utf-8") as f:
    for ln, raw in enumerate(f, 1):
        line = raw.split(";")[0].strip()
        if not line:
            continue
        m = re.match(r"^(G0|G1)\b(.*)", line)
        if not m:
            continue
        cmd, rest = m.group(1), m.group(2)
        x = re.search(r"X(-?\d+\.?\d*)", rest)
        y = re.search(r"Y(-?\d+\.?\d*)", rest)
        z = re.search(r"Z(-?\d+\.?\d*)", rest)

        if z is not None and x is None and y is None:
            zval = float(z.group(1))
            if cmd == "G1":
                if pen_down:
                    errors.append(f"стр.{ln}: опускание при уже опущенном пере")
                pen_down = True
                n_down += 1
            else:
                if not pen_down and n_up > 0:
                    errors.append(f"стр.{ln}: подъём при уже поднятом пере")
                pen_down = False
                n_up += 1
            continue

        if x is not None:
            xv = float(x.group(1))
            minx, maxx = min(minx, xv), max(maxx, xv)
        if y is not None:
            yv = float(y.group(1))
            miny, maxy = min(miny, yv), max(maxy, yv)

        if cmd == "G0" and pen_down:
            errors.append(f"стр.{ln}: G0-перемещение с опущенным пером!")
        if cmd == "G1" and not pen_down:
            errors.append(f"стр.{ln}: рисование с поднятым пером!")
        if cmd == "G1":
            n_draw += 1

        if x is not None and y is not None:
            cur = (float(x.group(1)), float(y.group(1)))
            if cur == prev_xy:
                dup_moves += 1
            prev_xy = cur

def fits(w, h):
    return (minx >= MARGIN - 0.6 and maxx <= w - MARGIN + 0.6
            and miny >= MARGIN - 0.6 and maxy <= h - MARGIN + 0.6)

print(f"файл: {path}")
print(f"опусканий (G1 Z): {n_down}, подъёмов (G0 Z): {n_up}, "
      f"рабочих ходов (G1 XY): {n_draw}")
print(f"габариты текста: X {minx:.1f}..{maxx:.1f}, Y {miny:.1f}..{maxy:.1f}")

if page_off:
    print(f"лист {page_txt}: проверка границ выключена "
          f"(габариты X {minx:.1f}..{maxx:.1f}, Y {miny:.1f}..{maxy:.1f})")
    ok_box = True
elif pw is not None:
    ok_box = fits(pw, ph)
    print(f"лист {page_txt}: печатная область "
          f"{pw - 2*MARGIN:.0f}x{ph - 2*MARGIN:.0f} — "
          f"{'ДА, влезает' if ok_box else 'НЕТ — ВЫЛЕЗАЕТ!'}")
else:
    ok_box = fits(297.0, 210.0) or fits(210.0, 297.0)
    print(f"лист {page_txt}: {'ДА, влезает' if ok_box else 'НЕТ — ВЫЛЕЗАЕТ!'}")
print(f"дубли-ходов: {dup_moves}")

if not ok_box:
    errors.append("текст выходит за печатную область листа")

if errors:
    print(f"ОШИБКИ ({len(errors)}):")
    for e in errors[:10]:
        print("  " + e)
    sys.exit(1)
print("структура G-code: ОК (перо не ездит опущенным, порядок команд верный)")
