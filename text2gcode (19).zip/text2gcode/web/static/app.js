/* Логика веб-пульта text2gcode (Alpine.js). Без внешних зависимостей.
 * serial.js подключается раньше и даёт глобальный PlotterSerial. */
function panel() {
  return {
    tab: 'text',
    busy: false,
    error: '',
    result: null,
    mOpen: false,          // модалка «Станок»
    info: { web: '…', text2gcode: '…', svg2gcode: '…', pdf2gcode: '…',
            pdf_ok: null,
            fonts: [{ id: 'vasek', label: 'vasek' }] },
    o: {
      text: 'Привет, мир!\nЭто печатает перьевой плоттер.',
      font: 'vasek',
      height: 10,
      align: 'left',
      wrap: true,
      rich: true,
      bold_style: 'repeat',
      bold_off: '',
      join_eps: '',
      link_mm: '',
      file: null,
      fileName: '',
      svgFile: null,
      svgName: '',
      fit: 'down',
      width: '',
      near: true,
      double: false,
      fill: 'lines',
      fill_step: '',
      fill_angle: '',
      page: 'a4',
      orient: 'auto',
      margin: 10,
      z_up: 4,
      z_down: 0,
      z_hop: 0,
      f_draw: 3000,
      f_travel: 9000,
    },

    /* ------- пульт станка: нули, подъезд, мягкий старт ------- */
    mach: {
      margin: 5,        // отступ быстрым ходом от (0,0), мм
      f_fast: 9000,     // скорость быстрой фазы, мм/мин
      f_slow: 600,      // финальная медленная, мм/мин
      soft_start: true, // подъезд в ноль перед печатью
    },

    /* ---------------- станок (Web Serial → FluidNC) ---------------- */
    link: null,
    pendingJob: null,   // прерванная печать: переживает переподключение USB
    ser: {
      supported: true,
      connecting: false,
      connected: false,
      baud: 115200,
      quick: false,        // есть порт, разрешённый в прошлый раз
      _port: null,
      fw: '',
      state: '—',
      pos: null,
      posSrc: '',
      step: 10,
      feed: 9000,
      jogging: false,
      prog: { sent: 0, total: 0, pct: 0, paused: false, running: false },
      canResume: false,     // есть прерванная печать — можно возобновить
      resumeAt: 0,          // строка, с которой продолжим (с 1)
      resumeTotal: 0,
      sd: { name: '', uploading: false, upPct: 0, running: false, pct: 0 },
      error: '',
      logLines: [],
      logText: '',
    },

    async init() {
      this.ser.supported = !!(window.PlotterSerial && window.PlotterSerial.isSupported());
      // пульт станка: помним настройки между запусками
      try {
        const saved = JSON.parse(localStorage.getItem('t2g_mach') || '{}');
        for (const k of ['margin', 'f_fast', 'f_slow']) {
          if (typeof saved[k] === 'number' && saved[k] >= 0) this.mach[k] = saved[k];
        }
        if (typeof saved.soft_start === 'boolean') this.mach.soft_start = saved.soft_start;
      } catch (e) { /* старый/битый localStorage — берём умолчания */ }
      // порт, разрешённый пользователем раньше, можно открыть без диалога
      if (navigator.serial && navigator.serial.getPorts) {
        const self = this;
        navigator.serial.getPorts().then(function (ps) {
          self.ser.quick = ps.length > 0;
          self.ser._port = ps[0] || null;
        }).catch(function () {});
      }
      // реальновременный "?" не мешает очереди команд — можно дёргать всегда
      setInterval(() => {
        if (this.link && this.ser.connected) this.link.poll();
      }, 400);
      try {
        const r = await fetch('/api/info');
        this.info = await r.json();
        if (this.info.fonts && this.info.fonts.length) this.o.font = this.info.fonts[0].id;
      } catch (e) { /* сервер рядом, но пусть UI живёт и без info */ }
    },

    /* Альпийские выражения не умеют try/catch — сохранение в методе. */
    saveMach() {
      try { localStorage.setItem('t2g_mach', JSON.stringify(this.mach)); }
      catch (e) { /* приватный режим браузера — просто не помним */ }
    },

    onFile(e) {
      this.o.file = e.target.files[0] || null;
      this.o.fileName = this.o.file ? this.o.file.name : '';
      if (this.o.fileName.toLowerCase().endsWith('.docx') === false) this.o.rich = false;
    },

    onSvg(e) {
      this.o.svgFile = e.target.files[0] || null;
      this.o.svgName = this.o.svgFile ? this.o.svgFile.name : '';
    },

    previewUrl() {
      return this.result ? `/api/job/${this.result.id}/preview.png?v=${this.result.ts}` : '';
    },
    get previewSrc() { return this.previewUrl(); },
    get ncUrl() { return this.result ? `/api/job/${this.result.id}/out.nc` : '#'; },

    fm(v, d = 0) { return (Number(v) || 0).toFixed(d); },
    sz(mm) { return Array.isArray(mm) ? `${this.fm(mm[0])}×${this.fm(mm[1])}` : '—'; },
    pageTxt() {
      if (!this.result || !this.result.stats.page) return 'без листа';
      const or = this.result.stats.orient === 'landscape' ? 'альбом.' : 'книжн.';
      return `${this.result.stats.page} ${or}`;
    },

    async generate() {
      this.busy = true;
      this.error = '';
      this.result = null;
      const fd = new FormData();
      fd.append('mode', this.tab === 'svg' ? 'svg' : (this.tab === 'file' ? 'file' : 'text'));
      fd.append('page', this.o.page);
      fd.append('orient', this.o.orient);
      fd.append('margin', this.o.margin);
      fd.append('z_up', this.o.z_up);
      fd.append('z_down', this.o.z_down);
      fd.append('z_hop', this.o.z_hop);
      fd.append('f_draw', this.o.f_draw);
      fd.append('f_travel', this.o.f_travel);
      fd.append('join_eps', this.o.join_eps);

      if (this.tab === 'svg') {
        if (!this.o.svgFile) {
          this.error = 'Выберите файл .svg / .svgz или .pdf (из Word)';
          this.busy = false;
          return;
        }
        fd.append('file', this.o.svgFile);
        fd.append('fit', this.o.fit);
        fd.append('width', this.o.width);
        fd.append('near', this.o.near ? '1' : '');
        fd.append('double', this.o.double ? '1' : '');
        fd.append('fill', this.o.fill || 'off');
        fd.append('fill_step', this.o.fill_step || '');
        fd.append('fill_angle', this.o.fill_angle || '');
      } else {
        if (this.tab === 'file' && this.o.file) fd.append('file', this.o.file);
        if (this.tab === 'text') fd.append('text', this.o.text);
        fd.append('font', this.o.font);
        fd.append('height', this.o.height);
        fd.append('align', this.o.align);
        fd.append('wrap', this.o.wrap ? '1' : '');
        fd.append('rich', this.o.rich ? '1' : '');
        fd.append('bold_style', this.o.bold_style || '');
        fd.append('bold_off', this.o.bold_off || '');
        fd.append('link_mm', this.o.link_mm);
      }

      try {
        const r = await fetch('/api/generate', { method: 'POST', body: fd });
        const j = await r.json();
        if (!j.ok) {
          this.error = (j.log || 'Ошибка генерации').slice(0, 4000);
        } else {
          this.result = j;
        }
      } catch (e) {
        this.error = 'Нет связи с сервером пульта (' + e + '). ' +
          'Похоже, процесс закрылся — запустите его снова:  py web\\app.py';
      }
      this.busy = false;
    },

    /* ======================= СТАНОК: Web Serial ======================= */

    serLog(s) {
      const t = new Date().toTimeString().slice(0, 8);
      this.ser.logLines.push(t + '  ' + s);
      if (this.ser.logLines.length > 300) this.ser.logLines.splice(0, this.ser.logLines.length - 300);
      this.ser.logText = this.ser.logLines.join('\n');
    },

    serError(e) {
      const m = String((e && (e.message || e)) || e);
      if (/отменён|dismiss|No port|gesture/i.test(m)) return 'Выбор порта отменён';
      if (/Failed to open|busy|access|denied|открыть порт/i.test(m)) {
        return 'Не удалось открыть порт: он занят другой программой (FluidTerm, PuTTY, Arduino IDE?) или отвалится кабель. Закройте отправители и попробуйте снова.';
      }
      if (/Web Serial/i.test(m)) return 'Этот браузер не умеет Web Serial — нужен Chrome или Edge на компьютере.';
      return m.slice(0, 400);
    },

    async serConnect(useQuick) {
      if (!window.PlotterSerial) return;
      this.ser.error = '';
      this.ser.connecting = true;
      try {
        const t = new PlotterSerial.WebSerialTransport();
        await t.request(useQuick && this.ser._port ? this.ser._port : null);
        const self = this;
        this.link = new PlotterSerial.PlotterLink({
          log: function (s) { if (s) self.serLog(s); },
          onEvent: function (ev) { self.onSerEvent(ev); },
        });
        await this.link.connect(t, this.ser.baud);
        this.ser.connected = true;
        if (this.pendingJob) {
          /* печать, прерванная обрывом связи, живёт между подключениями */
          this.link.lastJob = this.pendingJob;
          this.ser.canResume = true;
          this.ser.resumeAt = this.pendingJob.stopIndex + 1;
          this.ser.resumeTotal = this.pendingJob.total;
          this.serLog('• Найдена прерванная печать (строка ' +
            (this.pendingJob.stopIndex + 1) + ' из ' + this.pendingJob.total +
            ') — можно возобновить.');
        }
        this.serLog('— статус опрашивается каждые 0.4 с');
      } catch (e) {
        this.ser.error = this.serError(e);
        this.serLog('! ' + this.ser.error);
        if (this.link) { try { await this.link.disconnect(); } catch (e2) { /* уже */ } this.link = null; }
      }
      this.ser.connecting = false;
    },

    async serDisconnect() {
      if (this.link) { try { await this.link.disconnect(); } catch (e) { /* уже */ } }
      this.link = null;
      this.ser.connected = false;
      this.ser.state = '—';
      this.ser.pos = null;
    },

    onSerEvent(ev) {
      if (ev.type === 'status') {
        this.ser.state = ev.state || this.ser.state;
        this.ser.pos = ev.pos;
        this.ser.posSrc = ev.posSrc;
        /* печать с SD: в статусе появляется поле SD:45.5 (проценты файла).
         * Работает и после переподключения — увидим идущую на станке печать. */
        if (ev.sd != null) {
          if (!this.ser.sd.running && !this.ser.sd.uploading) {
            this.ser.sd.running = true;
            this.serLog('• На станке идёт печать с SD (' + ev.sd + '%) — ' +
              'она переживёт обрыв USB.');
          }
          this.ser.sd.pct = ev.sd;
        } else if (this.ser.sd.running && this.ser.state === 'Idle') {
          this.ser.sd.running = false;
          this.serLog('✔ Печать с SD завершена.');
        }
      } else if (ev.type === 'fw') {
        this.ser.fw = ev.fw;
      } else if (ev.type === 'closed') {
        this.ser.connected = false;
        this.ser.state = '—';
        this.ser.prog.running = false;
        const lj = this.link && this.link.lastJob;
        if (lj && lj.stopIndex < lj.total) {
          /* задание переживает переподключение — храним на уровне панели */
          this.pendingJob = lj;
          this.ser.canResume = true;
          this.ser.resumeAt = lj.stopIndex + 1;
          this.ser.resumeTotal = lj.total;
          this.serLog('! Связь оборвалась (помеха, кабель, ESP32 пере-'
            + 'enumerated). Печать запомнена: строка ' +
            (lj.stopIndex + 1) + ' из ' + lj.total + '.');
          this.serLog('  После подключения: перо в ноль листа → «X = 0, Y = 0» → Возобновить.');
        } else {
          this.serLog('! Порт закрылся (кабель, помеха или ESP32 перезагрузился).');
        }
      }
    },

    get serPos() {
      const p = this.ser.pos;
      if (!p) return 'X —  Y —  Z —';
      const f = (n) => (n >= 0 ? '' : '') + Number(n).toFixed(1);
      return `X ${f(p.x)}  Y ${f(p.y)}  Z ${f(p.z)}` + (this.ser.posSrc ? ` (${this.ser.posSrc})` : '');
    },

    get serBusy() {
      return !this.ser.connected || this.ser.state === 'Alarm' ||
             (this.ser.prog.running || this.ser.prog.paused);
    },

    get canPrint() {
      return !!this.result && this.ser.connected &&
        !this.ser.prog.running && !this.ser.prog.paused &&
        this.ser.state !== 'Alarm' && this.ser.state !== 'Run' && !this.busy;
    },

    get progText() {
      if (this.ser.sd.running) {
        return 'печать с SD: ' + (this.ser.sd.pct || 0) + '% · ' + this.ser.state.toLowerCase();
      }
      const p = this.ser.prog;
      if (!p.total) return 'нет задания';
      const st = p.paused ? 'ПАУЗА' : (p.running ? 'печатает' : 'остановлено');
      return `${p.sent} / ${p.total} строк · ${p.pct}% · ${st}`;
    },

    async serCmd(kind) {
      if (!this.link) return;
      try {
        if (kind === 'home') { this.serLog('— поиск домой ($H)…'); await this.link.home(); }
        else if (kind === 'unlock') { this.serLog('— разблокировка ($X)…'); await this.link.unlock(); }
        else if (kind === 'zero') { this.serLog('— ноль листа установлен (G92 X0 Y0)'); await this.link.setZeroXY(); }
        else if (kind === 'zeroz') { this.serLog('— Z обнулён (G92 Z0)'); await this.link.setZeroZ(); }
        else if (kind === 'corner') { this.serLog('— перо в угол листа…'); await this.link.goZeroXY(this.o.f_travel); }
      } catch (e) {
        this.serLog('! ' + this.serError(e));
      }
    },

    /* Обнулить отдельные оси: 'xy' — ноль листа, иначе 'x'/'y'/'z'. */
    async zeroAxis(a) {
      if (!this.link) return;
      const names = { xy: 'ноль листа (G92 X0 Y0)', x: 'X=0 (G92 X0)',
                      y: 'Y=0 (G92 Y0)', z: 'Z=0 (G92 Z0)' };
      try {
        this.serLog('— обнуляю: ' + (names[a] || a));
        await this.link.setZeroAxis(a);
      } catch (e) {
        this.serLog('! ' + this.serError(e));
      }
    },

    /* Двухфазный подъезд в ноль листа (без концевиков):
     * перо вверх -> быстро до отступа -> медленно точно в (0,0). */
    async goZeroSoft() {
      if (!this.link) return;
      try {
        this.serLog('— в ноль листа: быстро до ' + this.mach.margin +
                    ' мм, затем медленно (' + this.mach.f_slow + ')…');
        await this.link.goZeroSoft(this.o.z_up, this.mach.f_fast,
                                   this.mach.f_slow, this.mach.margin);
        this.serLog('• Перо в ноле листа (0, 0), перо поднято.');
      } catch (e) {
        this.serLog('! ' + this.serError(e));
      }
    },

    async serPen(up) {
      if (!this.link) return;
      try {
        if (up) { this.serLog('— перо вверх'); await this.link.penUp(this.o.z_up); }
        else { this.serLog('— перо вниз'); await this.link.penDown(this.o.z_down, this.o.f_travel); }
      } catch (e) {
        this.serLog('! ' + this.serError(e));
      }
    },

    async jog(dx, dy, dz) {
      if (!this.link) return;
      const d = Number(this.ser.step) || 10;
      this.ser.jogging = true;
      try {
        await this.link.jog(dx * d, dy * d, dz * d, this.ser.feed);
      } catch (e) {
        this.serLog('! ' + this.serError(e));
      }
      this.ser.jogging = false;
    },

    async jogCancel() {
      if (!this.link) return;
      try { await this.link.jogCancel(); } catch (e) { /* реальновременная */ }
    },

    async printJob() {
      if (!this.link || !this.result) return;
      if (this.ser.state === 'Alarm') {
        this.ser.error = 'Станок в аварии — сначала «Разблок ($X)»';
        return;
      }
      this.ser.error = '';
      this.pendingJob = null;          // начинаем новую печать — обрыв забыт
      this.ser.canResume = false;
      let text = '';
      try {
        text = await (await fetch(this.ncUrl)).text();
      } catch (e) {
        this.ser.error = 'Не удалось прочитать .nc: ' + e;
        return;
      }
      const lines = text.split(/\r?\n/);
      const self = this;
      /* мягкий подъезд: перо вверх -> быстро к отступу -> медленно в (0,0).
       * С него начинается печать, если галочка включена. */
      if (this.mach.soft_start) {
        try {
          this.serLog('— мягкий подъезд: быстро до ' + this.mach.margin +
                      ' мм от нуля, в конце медленно…');
          await this.link.goZeroSoft(this.o.z_up, this.mach.f_fast,
                                     this.mach.f_slow, this.mach.margin);
        } catch (e) {
          this.ser.error = 'Подъезд не удался: ' + this.serError(e) +
            ' — печать НЕ начата. Проверьте ноль листа и попробуйте снова.';
          return;
        }
      }
      this.ser.prog = { sent: 0, total: 0, pct: 0, paused: false, running: true };
      this.serLog(`— печать: ${this.result.stats ? this.result.stats.downs : '?'} опусканий пера…`);
      this.link.runJob(lines, {
        onProgress: function (p) {
          self.ser.prog = {
            sent: p.sent, total: p.total, pct: p.pct,
            paused: p.paused, running: p.running,
          };
        },
        onDone: function () {
          self.ser.prog.running = false;
          self.serLog('✔ Печать завершена. Перо поднято последней строкой файла.');
        },
        onError: function (e, line) {
          self.ser.prog.running = false;
          self.ser.prog.paused = true;
          self.ser.error = 'Ошибка контроллера на строке «' + line + '»: ' + e.message +
            ' — движение в паузе. «Стоп» сбросит станок.';
          const lj = self.link && self.link.lastJob;
          if (lj && lj.stopIndex < lj.total) {
            self.pendingJob = lj;
            self.ser.canResume = true;
            self.ser.resumeAt = lj.stopIndex + 1;
            self.ser.resumeTotal = lj.total;
          }
        },
      });
    },

    serPause() { if (this.link) { this.link.pause(); this.serLog('— пауза (!)'); } },
    serResume() { if (this.link) { this.link.resume(); this.serLog('— продолжаем (~)'); } },

    /* Возобновить ПРЕРВАННУЮ печать после обрыва/переподключения USB.
     * Перед нажатием: перо — джогом в ноль листа, оси обнулены. */
    async serResumeJob() {
      if (!this.link || !this.link.lastJob || this.ser.prog.running) return;
      if (this.ser.state === 'Alarm') {
        this.ser.error = 'Станок в аварии — сначала «Разблок ($X)»';
        return;
      }
      const lj = this.link.lastJob, self = this;
      this.ser.error = '';
      this.ser.canResume = false;
      this.ser.prog = { sent: lj.stopIndex, total: lj.total, pct: 0,
                        paused: false, running: true };
      try {
        this.serLog('— возобновление: перо вверх, подвод к строке ' +
                    (lj.stopIndex + 1) + '…');
        const job = await this.link.resumeJob({
          zUp: this.o.z_up, fTravel: this.o.f_travel,
          onProgress: function (p) {
            self.ser.prog = { sent: p.sent, total: p.total, pct: p.pct,
                              paused: p.paused, running: p.running };
          },
          onDone: function () {
            self.ser.prog.running = false;
            self.serLog('✔ Печать завершена — возобновлённая часть допечатана.');
          },
          onError: function (e, line) {
            self.ser.prog.running = false;
            self.ser.prog.paused = true;
            self.ser.error = 'Ошибка контроллера на строке «' + line + '»: ' +
              e.message + ' — движение в паузе. «Стоп» сбросит станок.';
          },
        });
        if (job) this.serLog('— продолжаю со строки ' + (lj.stopIndex + 1) +
                             ' из ' + lj.total);
      } catch (e) {
        this.ser.prog.running = false;
        this.ser.canResume = true;      // можно попробовать снова
        this.ser.error = this.serError(e);
        this.serLog('! Возобновление не удалось: ' + this.ser.error);
      }
    },

    serForgetJob() {
      this.pendingJob = null;
      if (this.link) this.link.lastJob = null;
      this.ser.canResume = false;
      this.ser.resumeAt = 0;
      this.ser.resumeTotal = 0;
      this.serLog('— прерванная печать забыта');
    },

    /* ==================== SD-карта: железобетонная печать ================== */

    /* Записать текущий .nc на SD-карту станка по XMODEM (как FluidTerm). */
    async sdWrite() {
      if (!this.link || !this.result || this.ser.sd.uploading) return;
      this.ser.error = '';
      let text = '';
      try {
        text = await (await fetch(this.ncUrl)).text();
      } catch (e) {
        this.ser.error = 'Не удалось прочитать .nc: ' + e;
        return;
      }
      const d = new Date();
      const p2 = n => String(n).padStart(2, '0');
      const name = 'plotter_' + d.getFullYear() + p2(d.getMonth() + 1) +
                   p2(d.getDate()) + '_' + p2(d.getHours()) + p2(d.getMinutes()) + '.nc';
      this.ser.sd.uploading = true;
      this.ser.sd.upPct = 0;
      this.serLog('— пишу на SD: /sd/' + name + ' (XModem, ' +
                  Math.ceil(text.length / 1024) + ' КБ)…');
      try {
        const st = await this.link.sdStatus();
        if (!st.present) {
          this.ser.error = 'FluidNC не видит SD-карту ($SD/Status: ' + (st.text || 'молчание') +
            '). Проверьте карту (FAT32) и секции spi:/sdcard: в config.yaml.';
          this.serLog('! ' + this.ser.error);
          return;
        }
        this.serLog('— SD на месте, передаю файл…');
        await this.link.sdUpload(name, text, pr => { this.ser.sd.upPct = pr.pct; });
        this.ser.sd.name = name;
        this.ser.sd.pct = 0;
        this.serLog('✔ Файл на карте: /sd/' + name + '. Теперь «ПЕЧАТЬ С SD» — и USB ' +
                    'можно не беречь: файл играет сам станок.');
      } catch (e) {
        this.ser.error = this.serError(e);
        this.serLog('! Запись на SD не удалась: ' + this.ser.error);
        this.serLog('  Передача идёт с контрольной суммой: битые помехами блоки '
                  + 'ловятся и повторяются сами; станок сброшен — хвост не '
                  + 'поедет в движение. Повторите ещё раз; если падает '
                  + 'постоянно — README «Запись на SD: скорость и помехи» '
                  + '(скорость порта, феррит на кабель).');
      } finally {
        this.ser.sd.uploading = false;
      }
    },

    /* Запустить файл с SD: станок играет сам, пульт только смотрит статус. */
    async sdPrint() {
      if (!this.link || !this.ser.sd.name || this.ser.sd.running) return;
      if (this.ser.state === 'Alarm') {
        this.ser.error = 'Станок в аварии — сначала «Разблок ($X)»';
        return;
      }
      this.ser.error = '';
      try {
        await this.link.sdRun(this.ser.sd.name);
        this.ser.sd.running = true;
        this.ser.sd.pct = 0;
        this.serLog('• Печать с SD пошла: /sd/' + this.ser.sd.name +
                    '. Пауза/Стоп работают как обычно.');
      } catch (e) {
        this.ser.error = this.serError(e);
        this.serLog('! Не удалось запустить с SD: ' + this.ser.error);
      }
    },

    async serStop() {
      if (!this.link) return;
      this.serLog('— СТОП: мягкий сброс контроллера');
      try { await this.link.stop(); } catch (e) { this.serLog('! ' + this.serError(e)); }
      this.ser.prog = { sent: 0, total: 0, pct: 0, paused: false, running: false };
    },

    scrollLog() {
      this.$nextTick(() => {
        const el = this.$refs.serlog;
        if (el) el.scrollTop = el.scrollHeight;
      });
    },
  };
}
window.panel = panel;
