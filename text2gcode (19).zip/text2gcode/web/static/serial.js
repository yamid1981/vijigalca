/* serial.js — прямая связь браузера с FluidNC/GRBL через Web Serial API.
 *
 * Браузер сам открывает COM-порт ESP32 и шлёт G-code строку за строкой,
 * дожидаясь "ok" от контроллера (окно подтверждений). Сервер Flask тут
 * больше НЕ участвует в печати — только в генерации файла.
 *
 * Работает в Chrome / Edge (десктоп) на http://localhost — это безопасный
 * контекст, HTTPS не нужен. Firefox/Safari Web Serial не поддерживают.
 *
 * Модуль не привязан к браузеру жёстко: транспорт (порт) подменяемый,
 * поэтому вся логика протестирована в Node с виртуальным FluidNC.
 */
(function (global) {
  'use strict';

  // ---- реальные (внеочередные) символы GRBL: шлются без перевода строки
  var RT_HOLD = '!';        // пауза подачи
  var RT_RESUME = '~';      // продолжить
  var RT_RESET = '\x18';    // мягкий сброс (Ctrl-X)
  var RT_JOG_CANCEL = '\x85'; // отменить джог

  function isSupported() {
    return typeof navigator !== 'undefined' && !!navigator.serial &&
      typeof navigator.serial.requestPort === 'function';
  }

  /* Убираем комментарии и пустышки: "(скобки)", "; до конца строки",
   * строки "%". GRBL их просто съедает, но окно подтверждений неместно
   * тратить на мусор. */
  function cleanLine(s) {
    var out = String(s).replace(/\([^)]*\)/g, '');
    var i = out.indexOf(';');
    if (i >= 0) out = out.slice(0, i);
    out = out.trim();
    if (!out || out === '%') return '';
    return out;
  }

  function r3(n) {
    n = Math.round(Number(n) * 1000) / 1000;
    return String(n);
  }

  /* X/Y из строки движения G0/G1 — чтобы после обрыва вернуть перо
   * к месту, где печать прервалась. Не-движения (G92, M-коды, F) — null. */
  function parseXY(line) {
    if (!/^G[01](?![\d.])/.test(line)) return null;
    var x = line.match(/X(-?\d*\.?\d+)/), y = line.match(/Y(-?\d*\.?\d+)/);
    if (!x && !y) return null;
    return { x: x ? parseFloat(x[1]) : null, y: y ? parseFloat(y[1]) : null };
  }

  /* CRC16 XModem (полином 0x1021, начальное 0) — для пакетов передачи
   * файла на SD-карту FluidNC. */
  function crc16(data, len) {
    var crc = 0;
    for (var i = 0; i < len; i++) {
      crc ^= data[i] << 8;
      for (var b = 0; b < 8; b++) {
        crc = (crc & 0x8000) ? ((crc << 1) ^ 0x1021) : (crc << 1);
        crc &= 0xffff;
      }
    }
    return crc;
  }

  /* ------------------------------------------------------------------ *
   *  Транспорт: настоящий COM-порт через Web Serial API                 *
   * ------------------------------------------------------------------ */
  function WebSerialTransport() {
    this.port = null;
    this.writer = null;
    this.onLine = null;    // cb(строка без \n)
    this.onClosed = null;  // cb() — порт отвалился
    this.rawMode = false;  // XMODEM: байты напрямую, без разбора строк
    this.onRaw = null;     // cb(Uint8Array) в сыром режиме
    this._reader = null;
    this._ondisconnect = null; // обработчик системного «порт исчез»
    this._buf = '';
    this._enc = new TextEncoder();
    this._dec = new TextDecoder();
  }

  /* preferred — уже выданный ранее SerialPort (navigator.serial.getPorts) */
  WebSerialTransport.prototype.request = async function (preferred) {
    if (preferred) { this.port = preferred; return this.port; }
    if (!isSupported()) {
      throw new Error('Браузер без Web Serial — нужен Chrome или Edge');
    }
    this.port = await navigator.serial.requestPort();
    return this.port;
  };

  WebSerialTransport.prototype.open = async function (opts) {
    if (!this.port) throw new Error('Порт не выбран');
    var self = this;
    /* USB отвал (помехи, выдернутый кабель, пере-enumeration ESP32):
     * система сообщает событием disconnect — отменяем читателя сразу,
     * не дожидаясь, пока упадёт read(); onClosed позовётся из readLoop
     * ровно один раз. */
    if (typeof navigator !== 'undefined' && navigator.serial &&
        typeof navigator.serial.addEventListener === 'function') {
      this._ondisconnect = function (e) {
        if (!self.port) return;
        if (e && e.port && e.port !== self.port) return; // чужой порт
        if (self._reader) { try { self._reader.cancel(); } catch (err) { /* уже */ } }
      };
      navigator.serial.addEventListener('disconnect', this._ondisconnect);
    }
    await this.port.open({ baudRate: (opts && opts.baud) || 115200 });
    this.writer = this.port.writable.getWriter();
    this._readLoop();
  };

  WebSerialTransport.prototype.write = async function (s) {
    if (!this.writer) throw new Error('Порт закрыт');
    await this.writer.write(this._enc.encode(s));
  };

  /* Сырые байты — для XMODEM (бинарные пакеты, CRC, EOT). */
  WebSerialTransport.prototype.writeBytes = async function (u8) {
    if (!this.writer) throw new Error('Порт закрыт');
    await this.writer.write(u8);
  };

  WebSerialTransport.prototype.close = async function () {
    try {
      if (typeof navigator !== 'undefined' && navigator.serial &&
          navigator.serial.removeEventListener && this._ondisconnect) {
        navigator.serial.removeEventListener('disconnect', this._ondisconnect);
      }
      if (this._reader) { try { await this._reader.cancel(); } catch (e) { /* уже */ } }
      if (this.writer) { try { this.writer.releaseLock(); } catch (e) { /* уже */ } }
      if (this.port) { try { await this.port.close(); } catch (e) { /* уже */ } }
    } finally {
      this.port = null; this.writer = null; this._reader = null;
    }
  };

  WebSerialTransport.prototype._readLoop = async function () {
    while (this.port && this.port.readable) {
      try {
        this._reader = this.port.readable.getReader();
        for (;;) {
          var res = await this._reader.read();
          if (res.done) break;
          if (this.rawMode) {
            /* XMODEM: байты как есть, строки не разбираем */
            if (this.onRaw) { try { this.onRaw(res.value); } catch (e) { /* не роняем цикл */ } }
            continue;
          }
          this._buf += this._dec.decode(res.value, { stream: true });
          var idx;
          while ((idx = this._buf.indexOf('\n')) >= 0) {
            var line = this._buf.slice(0, idx).replace(/\r$/, '');
            this._buf = this._buf.slice(idx + 1);
            if (this.onLine) { try { this.onLine(line); } catch (e) { /* не роняем цикл */ } }
          }
        }
      } catch (e) {
        break; // выдернули кабель / порт умер
      } finally {
        try { if (this._reader) this._reader.releaseLock(); } catch (e) { /* уже */ }
        this._reader = null;
      }
    }
    if (this.onClosed) { try { this.onClosed(); } catch (e) { /* уже */ } }
  };

  /* ------------------------------------------------------------------ *
   *  Связь с контроллером: очередь подтверждений, статусы, команды      *
   * ------------------------------------------------------------------ */
  function PlotterLink(opts) {
    opts = opts || {};
    this.log = opts.log || function () {};
    this.onEvent = opts.onEvent || function () {};
    this.WINDOW = opts.window || 6;   // строк в полёте (ждут "ok")
    this.t = null;
    this.connected = false;
    this.ready = false;
    this.fw = '';
    this.state = '?';                 // Idle/Run/Hold/Jog/Alarm/…
    this.pos = null;                  // рабочие координаты
    this.posSrc = '';                 // WPos | MPos(пересчитан)
    this._g92 = { x: 0, y: 0, z: 0 }; // сдвиг G92 для пересчёта MPos
    this._queue = [];
    this._polling = false;
    this.job = null;
    this.lastJob = null;   // прерванная печать: {all, stopIndex, xy, total}
    this.busyRaw = false;  // идёт XMODEM-передача — опрос "?" запрещён
  }

  PlotterLink.prototype.connect = async function (transport, baud) {
    this.t = transport;
    var self = this;
    transport.onLine = function (l) { self._line(l); };
    transport.onClosed = function () { self._closed(); };
    await transport.open({ baud: baud || 115200 });
    this.connected = true;
    this.log('— порт открыт, жду контроллер…');
    await this.write('\n');             // растормошить баннер
    await this._waitReady(2200);
    if (!this.ready) {                  // ESP32 иногда просыпается медленно
      await this.write('\n');
      await this._waitReady(1400);
    }
    if (!this.ready) {
      this.log('! Контроллер молчит. Проверьте скорость (FluidNC: 115200) и кабель.');
    } else {
      try { await this.cmd('G21', 4000); await this.cmd('G90', 4000); } catch (e) { /* не критично */ }
      try { await this.cmd('$I', 4000); } catch (e) { /* не критично */ }
      this.log('• Связь есть: ' + (this.fw || 'контроллер отвечает'));
      this.onEvent({ type: 'ready', fw: this.fw });
    }
    this.onEvent({ type: 'connected', fw: this.fw });
  };

  PlotterLink.prototype._waitReady = function (ms) {
    var self = this;
    return new Promise(function (resolve) {
      var t0 = Date.now();
      var iv = setInterval(function () {
        if (self.ready || Date.now() - t0 > ms) { clearInterval(iv); resolve(); }
      }, 50);
    });
  };

  PlotterLink.prototype.write = async function (s) {
    if (this.t) await this.t.write(s);
  };

  /* Послать строку и дождаться "ok". Отклоняется на "error:N" и таймауте. */
  PlotterLink.prototype.cmd = function (line, timeout) {
    var self = this;
    return new Promise(function (resolve, reject) {
      var item = {
        line: line, resolve: resolve, reject: reject,
        timer: setTimeout(function () {
          self._queue = self._queue.filter(function (q) { return q !== item; });
          reject(new Error('нет ответа на: ' + line));
        }, timeout || 15000)
      };
      self._queue.push(item);
      self.write(line + '\n').catch(function (e) {
        clearTimeout(item.timer);
        self._queue = self._queue.filter(function (q) { return q !== item; });
        reject(e);
      });
    });
  };

  PlotterLink.prototype._ack = function (errText) {
    var item = this._queue.shift();
    if (!item) return;                 // случайный "ok" без запроса — игнор
    clearTimeout(item.timer);
    if (errText) item.reject(new Error(errText));
    else item.resolve();
  };

  PlotterLink.prototype._flushQueue = function (why) {
    var q = this._queue; this._queue = [];
    q.forEach(function (item) {
      clearTimeout(item.timer);
      item.reject(new Error(why));
    });
  };

  PlotterLink.prototype._line = function (raw) {
    var l = (raw || '').trim();
    if (!l) return;
    if (this._tap) { try { this._tap(l); } catch (e) { /* не мешаем */ } }
    if (l === 'ok') return this._ack(null);
    var mErr = l.match(/^error:(\d+)(:.*)?/i);
    if (mErr) {
      this.log('! ' + l);
      return this._ack('контроллер ответил "' + l + '"');
    }
    if (l.charAt(0) === '<' && l.charAt(l.length - 1) === '>') return this._status(l);
    if (/^ALARM:/i.test(l)) {
      this.state = 'Alarm';
      this.onEvent({ type: 'state', state: 'Alarm' });
      this.log('! ' + l + ' — нажмите «Разблок ($X)»');
      return;
    }
    var mVer = l.match(/^\[VER:([^\]]*)\]/i);
    if (mVer) {
      this.fw = mVer[1].trim();
      this.onEvent({ type: 'fw', fw: this.fw });
      return this.log(l);
    }
    if (/grbl|fluidnc/i.test(l) && l.charAt(0) !== '[') {
      this.ready = true;
      if (!this.fw) { this.fw = l; this.onEvent({ type: 'fw', fw: l }); }
      return this.log(l);
    }
    this.log(l);
  };

  /* <Idle|WPos:1.000,2.000,0.000|FS:0,0> или <Run|MPos:...> */
  PlotterLink.prototype._status = function (l) {
    var parts = l.slice(1, -1).split('|');
    var st = (parts[0] || '').split(':')[0];
    if (st) this.state = st;
    var pos = null, src = '', sd = null;
    for (var k = 0; k < parts.length; k++) {
      var mSD = parts[k].match(/^SD:([\d.]+)/);
      if (mSD) { sd = parseFloat(mSD[1]); continue; }   // % файла с SD
      var m = parts[k].match(/^WPos:(-?[\d.]+),(-?[\d.]+),(-?[\d.]+)/);
      if (m) { pos = { x: +m[1], y: +m[2], z: +m[3] }; src = 'WPos'; break; }
      m = parts[k].match(/^MPos:(-?[\d.]+),(-?[\d.]+),(-?[\d.]+)/);
      if (m) {
        pos = { x: +m[1] - this._g92.x, y: +m[2] - this._g92.y, z: +m[3] - this._g92.z };
        src = 'MPos';
      }
    }
    if (pos) { this.pos = pos; this.posSrc = src; }
    this.onEvent({ type: 'status', state: this.state, pos: this.pos, posSrc: src, sd: sd });
  };

  /* Опрос статуса "?" — реальновременный, ответ "ok" не ждём.
   * Во время XMODEM-загрузки на SD опрос ЗАПРЕЩЁН: ответы статуса
   * перемешались бы с байтами передачи. */
  PlotterLink.prototype.poll = function () {
    if (!this.connected || this._polling || this.busyRaw) return;
    this._polling = true;
    var self = this;
    this.write('?').catch(function () {}).finally(function () { self._polling = false; });
  };

  PlotterLink.prototype._closed = function () {
    this.connected = false; this.ready = false;
    this._abortJob('порт закрылся');
    this._flushQueue('порт закрылся');
    this.onEvent({ type: 'closed' });
  };

  PlotterLink.prototype.disconnect = async function () {
    var t = this.t;
    this.t = null; this.connected = false; this.ready = false;
    this._abortJob('отключено');
    this._flushQueue('отключено');
    if (t) await t.close();
    this.onEvent({ type: 'closed' });
  };

  /* ------------------------- команды станка ------------------------- */

  PlotterLink.prototype.home = function () { return this.cmd('$H', 240000); };
  PlotterLink.prototype.unlock = function () { return this.cmd('$X', 8000); };

  /* Ноль листа: как в наших .nc — G92 X0 Y0 (перья Z не касаемся). */
  PlotterLink.prototype.setZeroXY = async function () {
    await this.cmd('G92 X0 Y0', 8000);
    this._markG92(['x', 'y']);
  };
  PlotterLink.prototype.setZeroZ = async function () {
    await this.cmd('G92 Z0', 8000);
    this._markG92(['z']);
  };
  /* Обнулить отдельные оси: 'x', 'y', 'z' или 'xy' (ноль листа).
   * Для станков без концевиков — основная калибровка: поставил перо
   * в угол листа вручную/джогом и обнулил нужные оси. */
  PlotterLink.prototype.setZeroAxis = async function (a) {
    var k = String(a || 'xy').toLowerCase();
    var axes = k === 'xy' ? ['x', 'y'] : [k];
    if (!/^[xyz]$/.test(axes[0])) throw new Error('не знаю такую ось: ' + a);
    var line = 'G92 ' + axes.map(function (s) { return s.toUpperCase() + '0'; }).join(' ');
    await this.cmd(line, 8000);
    this._markG92(axes);
  };
  /* axes — какие оси реально обнулили, чтобы не испортить показания
   * остальных (G92 X0 Y0 не меняет Z). */
  PlotterLink.prototype._markG92 = function (axes) {
    if (this.posSrc === 'WPos' || !this.pos) { this._g92 = { x: 0, y: 0, z: 0 }; return; }
    // новая точка нуля — там, где сейчас стоит перо:
    // машинные = показ + старый сдвиг
    var self = this;
    (axes || ['x', 'y', 'z']).forEach(function (a) {
      self._g92[a] = self.pos[a] + self._g92[a];
    });
  };

  PlotterLink.prototype.goZeroXY = function (f) {
    var self = this;
    return this.cmd('G90', 5000).then(function () {
      return self.cmd('G0 X0 Y0 F' + r3(f || 9000), 120000);
    });
  };

  /* Двухфазный подъезд в ноль листа БЕЗ концевиков:
   *   1) перо вверх, 2) быстро до отступа margin от (0,0),
   *   3) последние миллиметры — медленно: инерция не уводит каретку,
   * ноль точный, перо не бьётся. Ноль — тот, что задан G92. */
  PlotterLink.prototype.goZeroSoft = function (zUp, fFast, fSlow, margin) {
    var self = this;
    var m = Math.max(0, Number(margin) || 0);
    var seq = this.cmd('G90', 5000).then(function () {
      return self.cmd('G0 Z' + r3(zUp || 4), 60000);
    });
    if (m > 0.01) {
      seq = seq.then(function () {
        return self.cmd('G0 X' + r3(m) + ' Y' + r3(m) + ' F' + r3(fFast || 9000), 120000);
      });
    }
    return seq.then(function () {
      return self.cmd('G0 X0 Y0 F' + r3(fSlow || 600), 120000);
    });
  };

  /* Джог через $J= — контроллер сам вернёт прежний режим после движения. */
  PlotterLink.prototype.jog = function (dx, dy, dz, f) {
    var p = [];
    if (dx) p.push('X' + r3(dx));
    if (dy) p.push('Y' + r3(dy));
    if (dz) p.push('Z' + r3(dz));
    if (!p.length) return Promise.resolve();
    return this.cmd('$J=G91 G21 ' + p.join(' ') + ' F' + r3(f || 9000), 120000);
  };
  PlotterLink.prototype.jogCancel = function () { return this.write(RT_JOG_CANCEL); };

  PlotterLink.prototype.penUp = function (zUp) {
    return this.cmd('G0 Z' + r3(zUp), 60000);
  };
  PlotterLink.prototype.penDown = function (zDown, fz) {
    return this.cmd('G1 Z' + r3(zDown) + ' F' + r3(fz || 9000), 60000);
  };

  /* ------------------------- печать файла --------------------------- */

  /* lines — массив строк .nc. Стритель шлёт окно из WINDOW строк и ждёт
   * "ok" на каждую. Пауза — "!" контроллеру + перестаём подавать новые.
   * Ошибка контроллера — останавливаем подачу и держим перо ("!").
   * startIndex — продолжить с индекса (возобновление после обрыва USB).
   * Прерванная работа запоминается в this.lastJob — см. resumeJob(). */
  PlotterLink.prototype.runJob = function (lines, cb, startIndex) {
    cb = cb || {};
    var self = this;
    var all = (lines || []).map(cleanLine).filter(Boolean);
    var start = Math.max(0, Math.min(startIndex | 0, all.length));
    var job = {
      total: all.length, sent: start, i: start, inflight: 0,
      paused: false, aborted: false, finished: false, err: null,
      lastXY: null,                    // цель последней подтверждённой строки
      _all: all,
      onProgress: cb.onProgress || function () {},
      onDone: cb.onDone || function () {},
      onError: cb.onError || function () {}
    };
    this.job = job;
    this.lastJob = null;               // новая печать — прежний обрыв забыт

    var prog = function () {
      job.onProgress({
        sent: job.sent, total: job.total,
        pct: job.total ? Math.round(100 * job.sent / job.total) : 100,
        paused: job.paused,
        running: !job.finished && !job.aborted && !job.err
      });
    };
    job._prog = prog;

    var pump = function () {
      if (job.finished || job.aborted || job.err) return;
      if (job.paused) return;
      while (job.i < job.total && job.inflight < self.WINDOW) {
        let line = all[job.i++];   // let! каждое замыкание ловит СВОЮ строку
        job.inflight++;
        self.cmd(line, 120000).then(function () {
          job.inflight--; job.sent++;
          var xy = parseXY(line);
          if (xy) {
            job.lastXY = {
              x: xy.x != null ? xy.x : (job.lastXY ? job.lastXY.x : null),
              y: xy.y != null ? xy.y : (job.lastXY ? job.lastXY.y : null)
            };
          }
          prog(); pump();
        }).catch(function (e) {
          job.inflight--; job.err = e; prog();
          self._stash(job);
          self.log('! ОШИБКА на «' + line + '»: ' + e.message);
          self.log('  Движение поставлено на паузу (!). Стоп = сброс контроллера.');
          self.log('  Печать запомнена — после подключения можно возобновить.');
          self.write(RT_HOLD).catch(function () {});
          job.onError(e, line);
        });
      }
      if (job.i >= job.total && job.inflight === 0 && !job.err && !job.finished) {
        job.finished = true; prog(); job.onDone();
      }
    };
    job.pump = pump;
    pump();
    return job;
  };

  /* Запомнить прерванную печать: продолжать с первой строки, которую
   * контроллер НЕ подтвердил ("ok" приходят по порядку), и с координатой
   * последней подтверждённой точки — туда вернём перо при возобновлении. */
  PlotterLink.prototype._stash = function (job) {
    if (!job || job.finished || !job._all || !job._all.length) return;
    this.lastJob = {
      all: job._all,
      stopIndex: Math.min(job.sent, job._all.length),
      xy: job.lastXY,
      total: job.total
    };
  };

  PlotterLink.prototype.pause = function () {
    var j = this.job;
    if (j && !j.paused && !j.finished && !j.aborted && !j.err) {
      j.paused = true;
      this.write(RT_HOLD).catch(function () {});
      j._prog();
    }
  };
  PlotterLink.prototype.resume = function () {
    var j = this.job;
    if (j && j.paused) {
      j.paused = false;
      this.write(RT_RESUME).catch(function () {});
      j._prog();
      j.pump();
    }
  };
  PlotterLink.prototype._abortJob = function (why) {
    var j = this.job;
    if (j && !j.finished) { j.aborted = true; this._stash(j); j._prog(); }
    this.job = null;
    if (why) this.log('— печать остановлена: ' + why);
  };

  /* Возобновить ПРЕРВАННУЮ печать (обрыв USB, помеха, «Стоп»).
   * Контроллер при переподключении перезапускается и теряет ноль листа,
   * поэтому СНАЧАЛА пользователь джогом ставит перо в ноль листа и
   * обнуляет оси («X = 0, Y = 0»), ПОТОМ вызывается это:
   *   перо вверх -> быстрый подвод к точке обрыва -> строки с первой
   *   неподтверждённой и до конца файла. Один и тот же штрих может быть
   *   пройден пером дважды — шариковой ручке это безвредно. */
  PlotterLink.prototype.resumeJob = async function (cb) {
    var lj = this.lastJob;
    if (!lj || !lj.all || !(lj.stopIndex < lj.all.length)) return null;
    await this.cmd('G0 Z' + r3(cb && cb.zUp != null ? cb.zUp : 4), 60000);
    if (lj.xy && lj.xy.x != null && lj.xy.y != null) {
      await this.cmd('G0 X' + r3(lj.xy.x) + ' Y' + r3(lj.xy.y) +
                     ' F' + r3((cb && cb.fTravel) || 9000), 120000);
    }
    return this.runJob(lj.all, cb, lj.stopIndex);
  };
  /* ------------------- SD-карта: файл на станке --------------------- *
   * Печать с SD — «железобетонная»: файл играет сам ESP32, и обрыв
   * USB ему безразличен. Протокол FluidNC:
   *   $SD/Status          -> [MSG:INFO: SD card detected] (+ ok)
   *   $Xmodem/Receive=/sd/имя  -> [MSG:...], затем символы 'C',
   *   после них — XMODEM-CRC блоками по 1024 байта (STX, «XModem-1K»;
   *   приёмник FluidNC их принимает — src/xmodem.cpp, case STX) —
   *   в 8 раз меньше подтверждений и записей на карту, чем у
   *   классических 128 байт (SOH), потому и в разы быстрее. Если
   *   прошивка STX не знает — откат на 128. В конце EOT; контроллер
   *   печатает "Received N bytes to file ..." и 'ok'. Так же работает
   *   FluidTerm (mode='xmodem').
   *   $SD/Run=/sd/имя     -> станок играет файл; в статусе появится
   *   поле SD:45.5 (проценты файла). */

  PlotterLink.prototype.sdStatus = async function () {
    var lines = [], self = this;
    this._tap = function (l) { lines.push(l); };
    try {
      await this.cmd('$SD/Status', 8000);
    } finally {
      this._tap = null;
    }
    var present = lines.some(function (l) { return /sd card detected/i.test(l) && !/no sd/i.test(l); });
    var absent = lines.some(function (l) { return /no sd card/i.test(l); });
    return { present: present, absent: absent, text: lines.join(' | ') };
  };

  PlotterLink.prototype.sdRun = function (name) {
    return this.cmd('$SD/Run=/sd/' + name, 12000);
  };

  /* Записать файл на SD через XMODEM-CRC блоками 1024 байта (STX) с
   * откатом на 128 (SOH), если прошивка 1К не берёт.
   * onProgress({sent,total,pct}). Возвращает {bytes}. Перед вызовом
   * лучше проверить sdStatus(). */
  PlotterLink.prototype.sdUpload = function (name, text, onProgress) {
    var t = this.t;
    if (!t || !this.connected) return Promise.reject(new Error('нет порта'));
    if (this.busyRaw) return Promise.reject(new Error('передача уже идёт'));
    var self = this;
    return new Promise(function (resolve, reject) {
      (async function () {
        var bytes = new TextEncoder().encode(String(text));
        var buf = [], waiters = [];
        t.rawMode = true;
        self.busyRaw = true;
        t.onRaw = function (arr) {
          for (var i = 0; i < arr.length; i++) buf.push(arr[i]);
          var w = waiters.splice(0);
          for (var k = 0; k < w.length; k++) w[k]();
        };
        var cleanup = function () { t.rawMode = false; t.onRaw = null; self.busyRaw = false; };

        /* ждём один байт не дольше ms; null = тишина */
        var getc = function (ms) {
          return new Promise(function (res) {
            if (buf.length) { res(buf.shift()); return; }
            var done = false;
            var to = setTimeout(function () {
              if (!done) { done = true; res(null); }
            }, ms);
            waiters.push(function () {
              if (!done && buf.length) { done = true; clearTimeout(to); res(buf.shift()); }
            });
          });
        };
        var sleepMs = function (ms) {
          return new Promise(function (r) { setTimeout(r, ms); });
        };
        /* копим строку до \n; одиночный байт 'C' — стартовое "пиканье" XMODEM.
         * Возвращает: завершённую строку | 'C' | null */
        var line = '';
        var feed = function (b) {
          if (b === 0x0a) {
            var s = line.replace(/\r$/, '');
            line = '';
            if (s) self.log(s);
            return s;
          }
          if (b === 0x43 && !line) return 'C';   // 'C' вне строки
          line += String.fromCharCode(b);
          if (line.length > 160) { self.log(line); line = ''; }
          return null;
        };

        try {
          /* 1) команда приёма файла */
          await self.write('$Xmodem/Receive=/sd/' + name + '\n');

          /* 2) ждём 'C' (приём по CRC) или NAK (совсем старая прошивка —
           * приём по контрольной сумме); заодно показываем [MSG] */
          var got = false, crcMode = true, t0 = Date.now();
          while (Date.now() - t0 < 20000 && !got) {
            if (!self.connected) throw new Error('порт закрылся во время передачи');
            var b = await getc(1000);
            if (b == null) continue;
            if (b === 0x43) { got = true; }                        // 'C'
            else if (b === 0x15) { got = true; crcMode = false; }  // NAK
            else if (feed(b) === 'C') { got = true; }
          }

          if (!got) throw new Error('FluidNC не начал приём (нет "C") — ' +
            'проверьте SD-карту ($SD/Status) и версию прошивки');

          /* 3) блоки 1024 байта (STX) + CRC16; помеха = NAK = повтор того
           * же блока (приёмник FluidNC дубликат по номеру принимает).
           * Если 1К-блоки NAKаются, а ни один ещё не прошёл, — прошивка
           * без STX: откат на 128 байт (SOH). Совсем старые прошивки
           * стартуют NAK'ом — тогда сразу 128 байт и 1-байтовая сумма. */
          var useCrc = crcMode, size1K = crcMode;
          var seq = 1, pos = 0;
          var acked1K = 0, t0up = Date.now(), lastLog = 0;
          while (pos < bytes.length) {
            var bsize = size1K ? 1024 : 128;
            var end = Math.min(pos + bsize, bytes.length);
            var frame = new Uint8Array(bsize + (useCrc ? 5 : 4));
            frame[0] = size1K ? 0x02 : 0x01;       // STX | SOH
            frame[1] = seq & 0xff;
            frame[2] = 0xff - (seq & 0xff);
            frame.set(bytes.subarray(pos, end), 3);
            var ip;
            for (ip = end - pos; ip < bsize; ip++) frame[3 + ip] = 0x1a; // Ctrl-Z добивка
            if (useCrc) {
              var cc = crc16(frame.subarray(3, 3 + bsize), bsize);
              frame[3 + bsize] = (cc >> 8) & 0xff;
              frame[4 + bsize] = cc & 0xff;
            } else {
              var sum = 0;
              for (ip = 0; ip < bsize; ip++) sum = (sum + frame[3 + ip]) & 0xff;
              frame[3 + bsize] = sum;
            }
            var acked = false, tries = 0, nakCnt = 0;
            var dead = Date.now() + 90000;         // упрёмся в 90 с на блок
            while (!acked && tries < 20 && Date.now() < dead) {
              tries++;
              await t.writeBytes(frame);
              for (var w2 = 0; w2 < 12 && !acked; w2++) {
                var a = await getc(4000);
                if (!self.connected) throw new Error('порт закрылся во время передачи');
                if (a == null) break;                       // тишина — шлём блок ещё раз
                if (a === 0x06) { acked = true; }           // ACK
                else if (a === 0x15) { nakCnt++; break; }   // NAK — повторить блок
                else { feed(a); /* мусор от помех — ждать дальше */ }
              }
            }
            if (acked && size1K) acked1K++;
            if (!acked && size1K && acked1K === 0 && nakCnt >= 3) {
              size1K = false;                        // прошивка без STX
              self.log('— 1К-блоки не приняты, перехожу на 128 байт');
              continue;                              // тот же кусок файла, тот же номер
            }
            if (!acked) throw new Error('контроллер не подтвердил блок ' + seq +
              ' (помехи на линии — кабель/феррит/скорость, см. README)');
            pos = end;
            seq = (seq + 1) & 0xff;
            var pct = Math.round(100 * pos / bytes.length);
            if (pct >= lastLog + 10 || pos === bytes.length) {
              var secs = Math.max((Date.now() - t0up) / 1000, 0.1);
              self.log('— передано ' + pct + '% (' + Math.round(pos / 1024) +
                       ' КБ, ' + (pos / 1024 / secs).toFixed(1) + ' КБ/с)');
              lastLog = pct - (pct % 10);
            }
            if (onProgress) {
              onProgress({ sent: pos, total: bytes.length, pct: pct });
            }
          }

          /* 4) EOT — конец файла */
          var eotOk = false;
          for (var r2 = 0; r2 < 6 && !eotOk; r2++) {
            await t.writeBytes(new Uint8Array([0x04]));
            var e = await getc(4000);
            if (e === 0x06) eotOk = true;                  // ACK
            /* NAK после первого EOT — классика: шлём EOT снова */
          }
          if (!eotOk) throw new Error('нет подтверждения конца передачи');

          /* 5) докушиваем хвост: "Received N bytes to file ..." + ok */
          var okSeen = false, t3 = Date.now();
          while (Date.now() - t3 < 10000 && !okSeen) {
            var b2 = await getc(1000);
            if (b2 == null) continue;
            var res = feed(b2);
            if (typeof res === 'string' && /^ok$/i.test(res)) okSeen = true;
          }
          await sleepMs(300);                    // дать линии замолчать
          resolve({ bytes: bytes.length, name: name });
        } catch (err) {
          /* Аварийный выход. Гасим приёмник CAN'ами и мягко сбрасываем
           * контроллер: иначе недопереданные хвосты последнего блока
           * FluidNC разберёт как G-code и поедет рисовать мусор.
           * 0x18 внутри XMODEM = CAN, вне его = Ctrl-X (мягкий сброс). */
          try {
            await sleepMs(300);
            await t.writeBytes(new Uint8Array([0x18, 0x18, 0x18]));
            await sleepMs(400);
            await self.write('\n' + RT_RESET);
            self.ready = false;
            self.log('— контроллер сброшен, чтобы хвост неудавшейся передачи '
                     + 'не уехал в движение');
            await self._waitReady(2500);
          } catch (e2) { /* порт уже мёртв — catch (err) важнее */ }
          reject(err);
        } finally {
          cleanup();
        }
      })().catch(function (e) { try { reject(e); } catch (x) { /* уже отклонено */ } });
    });
  };

  /* Стоп = мягкий сброс контроллера (буфер движений очищается). */
  PlotterLink.prototype.stop = async function () {
    this._abortJob('нажат СТОП');
    this._flushQueue('сброс контроллера');
    await this.write(RT_RESET).catch(function () {});
    this.ready = false;
    this.log('— контроллер перезапущен, жду баннер…');
    await this._waitReady(2000);
    if (this.ready) this.log('• Контроллер снова на связи');
    else this.log('! Баннера не дождались — проверьте панель станка');
    this.onEvent({ type: 'reset' });
  };

  var PlotterSerial = {
    PlotterLink: PlotterLink,
    WebSerialTransport: WebSerialTransport,
    cleanLine: cleanLine,
    isSupported: isSupported,
    RT: { HOLD: RT_HOLD, RESUME: RT_RESUME, RESET: RT_RESET, JOG_CANCEL: RT_JOG_CANCEL }
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = PlotterSerial;
  global.PlotterSerial = PlotterSerial;
})(typeof window !== 'undefined' ? window : globalThis);
