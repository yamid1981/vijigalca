#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""web/app.py — ЛОКАЛЬНЫЙ веб-пульт для пакета text2gcode.

Запуск (Windows, из папки пакета):
    pip install flask
    py web\app.py            — откроется http://127.0.0.1:5000

Всё работает ЛОКАЛЬНО, интернет не нужен:
  * Alpine.js уже лежит в web/static/alpine.min.js;
  * предпросмотр рисует web/nc_preview.py чистым Python (matplotlib не нужен).

Страница: три вкладки (Текст / Файл txt-docx / SVG), опции станка,
кнопка «Сгенерировать», предпросмотр PNG, статистика, проверка
валидатором и скачивание .nc.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
import webbrowser

from flask import Flask, abort, render_template, request, send_file

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # пакет
HERE = os.path.dirname(os.path.abspath(__file__))                   # web/
JOBS = os.path.join(HERE, "jobs")
os.makedirs(JOBS, exist_ok=True)
sys.path.insert(0, HERE)

import nc_preview  # noqa: E402

app = Flask(__name__)
WEB_VERSION = "2.11"           # видно в шапке пульта — маркер обновления
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024
app.config["JSON_AS_ASCII"] = False
app.config["TEMPLATES_AUTO_RELOAD"] = True

SAFE_NAME = re.compile(r"[^A-Za-zА-Яа-яЁё0-9_.-]+")
TEXT_EXT = (".txt", ".docx")
SVG_EXT = (".svg", ".svgz", ".pdf")

_info_cache = None
_pdf_ok_cache = None   # (время проверки, результат)


# ---------------------------------------------------------------- утилиты

def run_child(argv, timeout=240):
    """Запуск нашего же CLI-скрипта тем же интерпретатором Python."""
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"      # Windows-консоль не трогает вывод
    env["PYTHONUTF8"] = "1"
    p = subprocess.run([sys.executable] + argv, cwd=BASE,
                       capture_output=True, timeout=timeout, env=env)
    out = (p.stdout or b"").decode("utf-8", "replace") + \
          (p.stderr or b"").decode("utf-8", "replace")
    return p.returncode, out.strip()


def tool_version(script):
    try:
        rc, out = run_child([os.path.join(BASE, script), "--version"], 20)
        return out.splitlines()[0].strip() if rc == 0 and out else "?"
    except Exception:
        return "?"


def font_label(path):
    """Человеческое имя шрифта из JSON (поле name)."""
    try:
        d = json.load(open(path, encoding="utf-8"))
        n = str(d.get("name", "")).strip()
        if n:
            return n
    except Exception:
        pass
    return os.path.basename(path)


def font_list():
    fonts = [("vasek", "Vasek — рукописный курсив"),
             ("print", "Печатный (Hershey)"),
             ("fonts/propisi.json", "Прописи — школьный курсив")]
    seen = {"vasek", "print", "fonts/propisi.json"}
    fd = os.path.join(BASE, "fonts")
    if os.path.isdir(fd):
        for n in sorted(os.listdir(fd)):
            if n.lower().endswith(".json"):
                fid = os.path.join("fonts", n)
                if fid in seen:
                    continue
                seen.add(fid)
                fonts.append((fid, font_label(os.path.join(fd, n))))
    return fonts


def pdf_ok(max_age=60.0):
    """Есть ли РАБОЧИЙ PyMuPDF для генерации PDF.

    ВАЖНО: процесс пульта САМ НИКОГДА не импортирует pymupdf/fitz.
    Некоторые сборки (например PyMuPDF 2.0 на Windows + Python 3.14)
    падают нативно прямо при import — без traceback, и раньше это
    убивало весь сервер при открытии страницы (ERR_CONNECTION_RESET).
    Поэтому:
      1) importlib.util.find_spec — «пакет установлен?» (код НЕ исполняется,
         упасть невозможно в принципе);
      2) пробный import в ОТДЕЛЬНОМ процессе — упадёт, пульт выживет.
    Результат кешируется на max_age секунд."""
    global _pdf_ok_cache
    now = time.time()
    if _pdf_ok_cache is not None and now - _pdf_ok_cache[0] < max_age:
        return _pdf_ok_cache[1]
    import importlib.util
    ok = False
    if (importlib.util.find_spec("pymupdf") is not None
            or importlib.util.find_spec("fitz") is not None):
        try:
            rc, _ = run_child(["-c", "import pymupdf"], 60)
            if rc != 0:                     # экзотика: установлен только fitz
                rc, _ = run_child(["-c", "import fitz"], 60)
            ok = (rc == 0)
        except Exception:                   # таймаут и пр.
            ok = False
    _pdf_ok_cache = (now, ok)
    return ok


def cleanup_jobs(max_age_h=24.0):
    cutoff = time.time() - max_age_h * 3600
    for n in os.listdir(JOBS):
        p = os.path.join(JOBS, n)
        try:
            if os.path.isdir(p) and os.path.getmtime(p) < cutoff:
                shutil.rmtree(p, ignore_errors=True)
        except OSError:
            pass


def num(form, key, cast=float, default=None):
    v = form.get(key, "")
    if v is None or str(v).strip() == "":
        return default
    try:
        return cast(str(v).replace(",", "."))
    except ValueError:
        return default


def flag(form, key):
    return str(form.get(key, "")).lower() in ("1", "true", "on", "yes", "да")


def save_upload(fdata, job_dir, name, allowed):
    if not name:
        return None
    name = SAFE_NAME.sub("_", os.path.basename(name)) or "input"
    ext = os.path.splitext(name)[1].lower()
    if ext not in allowed:
        return None
    p = os.path.join(job_dir, "input" + ext)
    with open(p, "wb") as f:
        f.write(fdata)
    return p


# ---------------------------------------------------------------- маршруты

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/info")
def api_info():
    global _info_cache
    if _info_cache is None:
        _info_cache = {
            "web": "пульт " + WEB_VERSION,
            "text2gcode": tool_version("text2gcode.py"),
            "svg2gcode": tool_version("svg2gcode.py"),
            "pdf2gcode": tool_version("pdf2gcode.py"),
            "pdf_ok": pdf_ok(),
            "fonts": [{"id": fid, "label": lab} for fid, lab in font_list()],
        }
    return json.dumps(_info_cache, ensure_ascii=False), \
        200, {"Content-Type": "application/json; charset=utf-8"}


@app.route("/api/generate", methods=["POST"])
def api_generate():
    f = request.form
    mode = f.get("mode", "text")
    job_id = uuid.uuid4().hex[:10]
    job_dir = os.path.join(JOBS, job_id)
    os.makedirs(job_dir, exist_ok=True)
    out_nc = os.path.join(job_dir, "out.nc")

    argv = None
    try:
        # ---------- общие опции станка
        common = []
        page = f.get("page", "a4")
        orient = f.get("orient", "auto")
        margin = num(f, "margin", float, 10.0)
        z_up = num(f, "z_up", float, 4.0)
        z_dn = num(f, "z_down", float, 0.0)
        f_draw = num(f, "f_draw", float, 3000.0)
        f_trav = num(f, "f_travel", float, 9000.0)
        z_hop = num(f, "z_hop", float, 0.0)

        if mode == "svg":
            up = request.files.get("file")
            src = save_upload(up.read(), job_dir, up.filename or "",
                              SVG_EXT) if up else None
            if not src:
                return json.dumps(
                    {"ok": False,
                     "log": "Прикрепите файл .svg / .svgz или .pdf"},
                    ensure_ascii=False), 400
            is_pdf = src.lower().endswith(".pdf")
            argv = [os.path.join(BASE,
                                 "pdf2gcode.py" if is_pdf else "svg2gcode.py"),
                    src]
            if is_pdf:
                # Листом служит сама страница PDF: печать 1:1 «как есть»,
                # настройки формы Лист/Поле/Вписать НЕ применяются.
                common += ["--page", "off"]
                if not pdf_ok():
                    return json.dumps(
                        {"ok": False, "id": job_id,
                         "log": "PyMuPDF не работает — без него PDF не "
                                "генерируется (сам пульт при этом жив — "
                                "это отдельный процесс). Откройте командную "
                                "строку и выполните:\n"
                                "    py -m pip install --upgrade pymupdf\n"
                                "Если после обновления снова не заведётся "
                                "(бывает с PyMuPDF 2.0), верните стабильную "
                                "1.x — она ставится и на Python 3.14:\n"
                                "    py -m pip install \"pymupdf==1.28.2\"\n"
                                "затем перезапустите пульт и повторите."},
                        ensure_ascii=False), 200
            else:
                if page != "off":
                    common += ["--page", page]
                    if orient in ("portrait", "landscape"):
                        common += ["--orient", orient]
                    common += ["--margin", str(margin)]
                else:
                    common += ["--page", "off"]  # дефолт у CLI — a4, надо явно
                fit = f.get("fit", "down")
                if fit in ("down", "up", "none"):
                    common += ["--fit", fit]
                w = num(f, "width", float, None)
                if w:
                    common += ["--width", str(w)]
            if flag(f, "near"):
                common += ["--near"]
            if flag(f, "double"):
                common += ["--double"]
            je = num(f, "join_eps", float, None)
            if je:
                common += ["--join-eps", str(je)]
            # закраска чёрных заливок (SVG и PDF)
            fill_mode = f.get("fill", "off")
            if fill_mode in ("lines", "zigzag", "cross"):
                common += ["--fill", fill_mode]
                fs = num(f, "fill_step", float, None)
                if fs:
                    common += ["--fill-step", str(fs)]
                fa = num(f, "fill_angle", float, None)
                if fa is not None:
                    common += ["--fill-angle", str(fa)]
            if is_pdf:
                # pdf2gcode пишет постранично в job_dir; веб отдаёт первую
                common += ["--outdir", job_dir]
        else:
            # text | file
            up = request.files.get("file")
            src = in_path = None
            text = (f.get("text") or "").replace("\r\n", "\n").strip()
            if mode == "file" and up:
                src = save_upload(up.read(), job_dir, up.filename or "",
                                  TEXT_EXT)
                if not src:
                    return json.dumps(
                        {"ok": False,
                         "log": "Файл должен быть .txt или .docx"},
                        ensure_ascii=False), 400
                in_path = src
            if not in_path and not text:
                return json.dumps(
                    {"ok": False, "log": "Пусто: введите текст или выберите "
                                         "файл"},
                    ensure_ascii=False), 400
            argv = [os.path.join(BASE, "text2gcode.py")]
            if in_path:
                argv += ["--in", in_path]
            else:
                argv += [text]
            font = f.get("font", "vasek")
            if font.startswith("fonts/") and os.path.isfile(
                    os.path.join(BASE, font)):
                font = os.path.join(BASE, font)
            common += ["--font", font,
                       "--height", str(num(f, "height", float, 10.0)),
                       "--align", f.get("align", "left"),
                       "--wrap", "off" if not flag(f, "wrap") else "on",
                       "--rich", "off" if not flag(f, "rich") else "on"]
            bs = f.get("bold_style", "")
            if bs in ("shift", "repeat", "wide"):
                common += ["--bold-style", bs]
            bo = num(f, "bold_off", float, None)
            if bo is not None and bo > 0:
                common += ["--bold-off", str(bo)]
            if page != "off":
                common += ["--page", page]
                if orient in ("portrait", "landscape", "auto"):
                    common += ["--orient", orient]
                common += ["--margin", str(margin)]
            else:
                common += ["--page", "off"]  # дефолт у CLI — a4, надо явно
            je = num(f, "join_eps", float, None)
            if je is not None and je > 0:
                common += ["--join-eps", str(je)]
            lm = num(f, "link_mm", float, None)
            if lm is not None and lm > 0:
                common += ["--link-mm", str(lm)]

        if z_hop and z_hop > 0:
            common += ["--z-hop", str(z_hop)]
        common += ["--z-up", str(z_up), "--z-down", str(z_dn),
                   "--f-draw", str(f_draw), "--f-travel", str(f_trav)]
        if not (mode == "svg" and src and src.lower().endswith(".pdf")):
            common += ["--out", out_nc]  # pdf2gcode именует страницы сам

        rc, log = run_child(argv + common)

        # PDF: pdf2gcode кладёт страницы input-p1.nc, input-p2.nc, ...
        # в веб-пульте печатаем первую страницу
        if mode == "svg" and src and src.lower().endswith(".pdf"):
            pages = sorted(n for n in os.listdir(job_dir)
                           if n.startswith("input-p") and n.endswith(".nc"))
            if rc == 0 and pages:
                shutil.copyfile(os.path.join(job_dir, pages[0]), out_nc)
                if len(pages) > 1:
                    log += (f"\nСтраниц в PDF: {len(pages)}. В пульте "
                            f"готова ПЕРВАЯ (out.nc). Все страницы сразу: "
                            f"py pdf2gcode.py файл.pdf")
            elif rc == 0:
                rc = 1
                log = (log or "") + "\nPDF не дал страниц (пустой документ?)"

        if rc != 0 or not os.path.isfile(out_nc):
            if not (log or "").strip():
                log = "Скрипт упал молча (без сообщений)."
                if mode == "svg" and src and src.lower().endswith(".pdf"):
                    log += ("\nВероятная причина — сбой PyMuPDF. Проверьте "
                            "файл вручную в консоли (увидите настоящую "
                            "ошибку):\n"
                            "    py pdf2gcode.py ваш_файл.pdf\n"
                            "и обновите пакет, либо откатите на стабильный:\n"
                            "    py -m pip install --upgrade pymupdf\n"
                            "    py -m pip install \"pymupdf==1.28.2\"")
            return json.dumps(
                {"ok": False, "id": job_id, "log": log or "скрипт упал"},
                ensure_ascii=False), 200

        # ---------- предпросмотр + статистика
        nc_text = open(out_nc, encoding="utf-8").read()
        info, _ = nc_preview.render_nc_png(
            nc_text, os.path.join(job_dir, "preview.png"))

        # ---------- валидатор
        v_ok, v_out = run_child([os.path.join(HERE, "validate_nc.py"),
                                 out_nc], 60)

        warnings = [ln.strip() for ln in log.splitlines()
                    if ln.strip().startswith(("!", "ВНИМАНИЕ"))]
        return json.dumps({
            "ok": True,
            "id": job_id,
            "log": log,
            "stats": info,
            "warnings": warnings,
            "validator_ok": v_ok == 0,
            "validator_out": v_out,
            "ts": int(time.time()),
        }, ensure_ascii=False), 200

    except subprocess.TimeoutExpired:
        return json.dumps({"ok": False, "id": job_id,
                           "log": "Превышено время генерации (240 с)"},
                          ensure_ascii=False), 200
    except Exception as e:  # noqa: BLE001
        return json.dumps({"ok": False, "id": job_id,
                           "log": f"Ошибка сервера: {e}"},
                          ensure_ascii=False), 500


@app.route("/api/job/<jid>/preview.png")
def job_png(jid):
    p = os.path.join(JOBS, jid, "preview.png")
    if not re.fullmatch(r"[0-9a-f]{6,16}", jid) or not os.path.isfile(p):
        abort(404)
    resp = send_file(p, mimetype="image/png", max_age=0)
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/api/job/<jid>/out.nc")
def job_nc(jid):
    p = os.path.join(JOBS, jid, "out.nc")
    if not re.fullmatch(r"[0-9a-f]{6,16}", jid) or not os.path.isfile(p):
        abort(404)
    name = f"plotter_{time.strftime('%Y%m%d_%H%M')}.nc"
    return send_file(p, mimetype="text/plain",
                     as_attachment=True, download_name=name)


# ---------------------------------------------------------------- запуск

def main():
    import argparse
    ap = argparse.ArgumentParser(
        description="Локальный веб-пульт text2gcode")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--no-open", action="store_true",
                    help="не открывать браузер автоматически")
    args = ap.parse_args()

    cleanup_jobs()
    url = f"http://127.0.0.1:{args.port}"
    print("=" * 56)
    print("  ВЕБ-ПУЛЬТ text2gcode")
    print(f"  Адрес: {url}   (закрыть: Ctrl+C в этом окне)")
    print("  Ничего никуда не отправляется — всё на вашем компьютере.")
    print("=" * 56)

    if not args.no_open:
        threading.Timer(1.2, webbrowser.open, [url]).start()

    app.run(host="127.0.0.1", port=args.port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
