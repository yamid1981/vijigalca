#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""nc_preview.py — предпросмотр G-code для веб-пульта (web/app.py).

Парсит .nc (диалект text2gcode/svg2gcode: перо = ось Z) и рисует PNG
ЧИСТЫМ Python: без matplotlib, без PIL — только zlib/struct.
Возвращает статистику (опускания пера, длина рисования/подвода, время).

Рисование  — тёмные линии, подвод пера — светло-серые,
рамка листа и поле — тонкие серые линии.
"""
import math
import re
import struct
import zlib

PAGE_SIZES = {
    "A4": (210.0, 297.0),
    "A3": (297.0, 420.0),
    "A5": (148.0, 210.0),
    "LETTER": (215.9, 279.4),
}

RE_PAGE = re.compile(r";\s*лист\s+(A4|A3|A5|LETTER)\s+(portrait|landscape)\s*,"
                     r"\s*поле\s*([\d.]+)\s*мм", re.I)
RE_PEN = re.compile(r"Z([+-]?\d*\.?\d+)\s*=\s*вниз,\s*Z([+-]?\d*\.?\d+)\s*=\s*вверх")
RE_FEED = re.compile(r"рисование\s+F(\d*\.?\d+),\s*подвод\s+F(\d*\.?\d+),"
                     r"\s*Z\s+F(\d*\.?\d+)")
RE_MOVE = re.compile(r"^(G0|G1)\b(.*)$")
RE_WORD = re.compile(r"([XYZF])([+-]?\d*\.?\d+)")


def parse_nc(nc_text):
    """(.nc текст) -> {page, orient, margin, z_down, z_up, feeds,
                       draw:[], travel:[], downs, draw_mm, travel_mm, minutes}"""
    page = orient = None
    margin = 10.0
    z_down, z_up = 0.0, 4.0
    f_draw, f_travel, f_z = 3000.0, 9000.0, 9000.0

    head = nc_text[:2000]
    m = RE_PAGE.search(head)
    if m:
        page, orient, margin = m.group(1).upper(), m.group(2).lower(), \
            float(m.group(3))
    m = RE_PEN.search(head)
    if m:
        z_down, z_up = float(m.group(1)), float(m.group(2))
    m = RE_FEED.search(head)
    if m:
        f_draw, f_travel, f_z = (float(m.group(1)), float(m.group(2)),
                                 float(m.group(3)))

    mid = (z_down + z_up) / 2.0
    x = y = 0.0
    z_prev = z_up
    pen_down = False
    draw, travel = [], []
    downs = 0
    draw_mm = travel_mm = z_path = 0.0

    for raw in nc_text.splitlines():
        line = raw.split(";", 1)[0].strip()
        if not line:
            continue
        m = RE_MOVE.match(line)
        if not m:
            continue
        g, rest = m.group(1), m.group(2)
        words = dict((w[0], float(w[1])) for w in RE_WORD.findall(rest))

        if "Z" in words:
            nz = words["Z"]
            z_path += abs(nz - z_prev)
            z_prev = nz
            was = pen_down
            pen_down = nz <= mid
            if pen_down and not was:
                downs += 1

        if "X" in words or "Y" in words:
            nx = words.get("X", x)
            ny = words.get("Y", y)
            seg = ((x, y), (nx, ny))
            d = math.hypot(nx - x, ny - y)
            if pen_down:
                draw.append(seg)
                draw_mm += d
            elif d > 0.01:
                travel.append(seg)
                travel_mm += d
            x, y = nx, ny

    minutes = draw_mm / f_draw + travel_mm / f_travel + z_path / f_z
    return {
        "page": page, "orient": orient, "margin": margin,
        "z_down": z_down, "z_up": z_up,
        "feeds": (f_draw, f_travel, f_z),
        "draw": draw, "travel": travel, "downs": downs,
        "draw_mm": draw_mm, "travel_mm": travel_mm,
        "minutes": minutes,
    }


# ------------------------------------------------------------ растеризация

def _line(buf, W, H, x0, y0, x1, y1, r):
    """Брезенхэм с круглой кистью радиуса r (в пикселях буфера)."""
    x0, y0, x1, y1 = int(round(x0)), int(round(y0)), int(round(x1)), \
        int(round(y1))
    dx = abs(x1 - x0)
    sx = 1 if x0 < x1 else -1
    dy = -abs(y1 - y0)
    sy = 1 if y0 < y1 else -1
    err = dx + dy
    rr = r * r + r
    while True:
        if 0 <= x0 < W and 0 <= y0 < H:
            base = y0 * W + x0
            for oy in range(-r, r + 1):
                yy = y0 + oy
                if not (0 <= yy < H):
                    continue
                row = base + oy * W
                for ox in range(-r, r + 1):
                    if ox * ox + oy * oy <= rr and 0 <= x0 + ox < W:
                        buf[row + ox] = 1
        if x0 == x1 and y0 == y1:
            return
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy


def _dashed_line(buf, W, H, x0, y0, x1, y1, r, dash, gap):
    L = math.hypot(x1 - x0, y1 - y0)
    if L < 1:
        return
    ux, uy = (x1 - x0) / L, (y1 - y0) / L
    t = 0.0
    while t < L:
        t2 = min(t + dash, L)
        _line(buf, W, H, x0 + ux * t, y0 + uy * t, x0 + ux * t2, y0 + uy * t2,
              r)
        t = t2 + gap


def _seg_bounds(segs):
    if not segs:
        return None
    xs = []
    ys = []
    for (a, b) in segs:
        xs += (a[0], b[0])
        ys += (a[1], b[1])
    return min(xs), min(ys), max(xs), max(ys)


def render_nc_png(nc_text, out_path, width_px=1160, ss=2):
    """Рендер .nc -> PNG. Возвращает (info_dict, png_size)."""
    d = parse_nc(nc_text)

    if d["page"]:
        pw, ph = PAGE_SIZES[d["page"]]
        if d["orient"] == "landscape":
            pw, ph = ph, pw
        m = d["margin"]
        view = (-4.0, -4.0, pw + 4.0, ph + 4.0)
        page_rect = (0.0, 0.0, pw, ph, m)
    else:
        bb = _seg_bounds(d["draw"] + d["travel"])
        if bb is None:
            raise ValueError("в G-code нет ни одного перемещения XY")
        pad = 5.0
        view = (bb[0] - pad, bb[1] - pad, bb[2] + pad, bb[3] + pad)
        page_rect = None

    vw, vh = view[2] - view[0], view[3] - view[1]
    scale = width_px / vw
    W, H = int(vw * scale) + 2, int(vh * scale) + 2
    WS, HS = W * ss, H * ss

    def to_px(p):
        return ((p[0] - view[0]) * scale * ss, (view[3] - p[1]) * scale * ss)

    buf_draw = bytearray(WS * HS)
    buf_trav = bytearray(WS * HS)

    for (a, b) in d["travel"]:
        _line(buf_trav, WS, HS, *to_px(a), *to_px(b), 1)
    for (a, b) in d["draw"]:
        _line(buf_draw, WS, HS, *to_px(a), *to_px(b), 2)

    if page_rect:
        p0 = to_px((page_rect[0], page_rect[1]))   # левый НИЗ листа (мм)
        p3 = to_px((page_rect[2], page_rect[3]))   # правый ВЕРХ листа
        x0p, y0p = p0
        x3p, y3p = p3
        r = 1
        _line(buf_trav, WS, HS, x0p, y0p, x3p, y0p, r)
        _line(buf_trav, WS, HS, x3p, y0p, x3p, y3p, r)
        _line(buf_trav, WS, HS, x3p, y3p, x0p, y3p, r)
        _line(buf_trav, WS, HS, x0p, y3p, x0p, y0p, r)
        # пунктир печатной области (поле)
        mpx = page_rect[4] * scale * ss
        _dashed_line(buf_trav, WS, HS, x0p + mpx, y0p + mpx,
                     x3p - mpx, y0p + mpx, r, 10, 8)
        _dashed_line(buf_trav, WS, HS, x3p - mpx, y0p + mpx,
                     x3p - mpx, y3p - mpx, r, 10, 8)
        _dashed_line(buf_trav, WS, HS, x3p - mpx, y3p - mpx,
                     x0p + mpx, y3p - mpx, r, 10, 8)
        _dashed_line(buf_trav, WS, HS, x0p + mpx, y3p - mpx,
                     x0p + mpx, y0p + mpx, r, 10, 8)

    # ---- сборка RGB с даунсемплом ss x ss
    WHITE = (250, 250, 250)
    INK = (28, 28, 32)
    TRAVEL = (196, 202, 210)
    FRAME = (150, 155, 162)

    rows = []
    for py_ in range(H):
        row = bytearray()
        for px_ in range(W):
            s_trav = s_draw = 0
            for oy in range(ss):
                base = (py_ * ss + oy) * WS + px_ * ss
                for ox in range(ss):
                    v = buf_trav[base + ox]
                    if v:
                        s_trav += 1
                    if buf_draw[base + ox]:
                        s_draw += 1
            n = ss * ss
            a_draw = s_draw / n
            a_trav = max(s_trav / n, a_draw)  # рисование поверх подвода
            # рамка листа — цвет FRAME: она в buf_trav, отличить нельзя,
            # поэтому красим всё "серое" одним цветом, но рамку чуть темнее
            # нельзя без отдельного слоя — упрощение принято
            c = WHITE
            if a_trav > 0:
                c = tuple(WHITE[i] * (1 - a_trav) + TRAVEL[i] * a_trav
                          for i in range(3))
            if a_draw > 0:
                c = tuple(c[i] * (1 - a_draw) + INK[i] * a_draw
                          for i in range(3))
            row += bytes(int(min(255, max(0, v)) + 0.5) for v in c)
        rows.append(bytes(row))

    raw = b"".join(b"\x00" + r for r in rows)

    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + \
            struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) +
           chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    with open(out_path, "wb") as f:
        f.write(png)

    bb = _seg_bounds(d["draw"]) or (0, 0, 0, 0)
    info = {
        "page": d["page"], "orient": d["orient"], "margin": d["margin"],
        "downs": d["downs"],
        "draw_mm": d["draw_mm"], "travel_mm": d["travel_mm"],
        "minutes": d["minutes"],
        "size_mm": [round(bb[2] - bb[0], 1), round(bb[3] - bb[1], 1)],
        "feeds": d["feeds"],
    }
    return info, (W, H)


if __name__ == "__main__":
    import sys
    info, size = render_nc_png(open(sys.argv[1], encoding="utf-8").read(),
                               sys.argv[2])
    print(info, size)
