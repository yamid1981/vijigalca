#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""repair_font.py — лечение штрихового шрифта stroke-font-v1.

Проблема: буквы рукописного шрифта разбиты на 2-3 штриха с реальными
зазорами 1.5-3 мм и перемешанным порядком хранения. На плоттере это
даёт обрывы внутри букв и "лишние палки".

Лечение (по каждому глифу):
  1. Находится ШТРИХ-ВХОД (конец, ближайший к точке соединения слева)
     и ШТРИХ-ВЫХОД (конец справа, у advance) — они задают направление
     письма. Штрихи могут храниться задом наперёд — разворачиваются.
  2. Промежуточные штрихи пристраиваются жадно: перемычка разрешена
     только при зазоре <= 30% cap и плавном входе (поворот <= 60°).
     Ретрейс-ветка (длинные «обратные» прыжки) отключена: она давала
     прямые палки через букву (п, m, n).
  3. Перемычка — гладкая Безье по касательным; запрещена, если она
     (а) пересекает штрихи глифа («зачеркивание») или (б) существенную
     часть пути идёт ВДОЛЬ уже имеющегося штриха со сдвигом — на
     бумаге это двойная «лишняя палка» (л, и, й, м, ж).
  4. Надстрочные метки (бревно "й", точки "ё") не пришиваются — перо
     поднимается, как при живом письме.
"""
import argparse
import json
import math

MAX_CHAIN_GAP = 0.30    # доля cap: обычная перемычка (было 0.35 —
                        # пропускало диагонали 3.2-3.9 мм через букву)
MAX_RETRACE_GAP = 0.0   # ретрейс-прыжки отключены (источник «палок»)
TURN_MAX_DEG = 135.0    # макс. поворот при входе в перемычку
RETRACE_DOT = -0.85     # cos угла разворота (~148°)
NEAR_END = 12.0         # зона концов стыка, u: пересечения не считаются
HUG_LEN = 200.0         # длина начала пришиваемого штриха для теста возврата
HUG_TOL = 26.0          # близость к перемычке, u
HUG_TIP = 30.0          # зона возле вершины стыка не считается
HUG_MAX = 0.5           # доля возврата, больше которой — отказ
HUG_INK_TOL = 0.055     # доля cap: перемычка «идёт по штриху», если ближе
HUG_INK_MAX = 0.40      # доля пути перемычки вдоль чужих чернил, макс.
MARK_MIN_Y = 0.48       # доля cap: штрих целиком выше = метка
MARK_MAX_SPAN = 0.30    # доля cap: метка короткая
CURVE_PTS = 6

DEG = math.pi / 180.0


def seg_cross(p1, p2, p3, p4):
    def ccw(a, b, c):
        return (c[1] - a[1]) * (b[0] - a[0]) > (b[1] - a[1]) * (c[0] - a[0])
    return (ccw(p1, p3, p4) != ccw(p2, p3, p4)
            and ccw(p1, p2, p3) != ccw(p1, p2, p4))


def dist_to_seg(p, a, b):
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 < 1e-12:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def unit(dx, dy):
    L = math.hypot(dx, dy)
    if L < 1e-9:
        return (0.0, 0.0)
    return (dx / L, dy / L)


def turn_deg(d1, d2):
    dot = max(-1.0, min(1.0, d1[0] * d2[0] + d1[1] * d2[1]))
    return math.acos(dot) / DEG


def connector_crosses(a_end, b_start, strokes, tol=NEAR_END, skip=None):
    seg_a, seg_b = a_end, b_start
    skip = skip or set()
    for si, s in enumerate(strokes):
        if si in skip:
            continue
        for k in range(len(s) - 1):
            c, d = s[k], s[k + 1]
            if (dist_to_seg(seg_a, c, d) < tol
                    or dist_to_seg(seg_b, c, d) < tol):
                continue
            if seg_cross(seg_a, seg_b, c, d):
                return True
    return False


def make_connector(a_end, a_prev, b_start, b_next):
    """Гладкая перемычка: квадратичная Безье по касательным."""
    t0 = unit(a_end[0] - a_prev[0], a_end[1] - a_prev[1])
    t2 = unit(b_next[0] - b_start[0], b_next[1] - b_start[1])
    gap = math.hypot(b_start[0] - a_end[0], b_start[1] - a_end[1])
    if gap < 1e-9:
        return []
    denom = t0[0] * t2[1] - t0[1] * t2[0]
    ctrl = None
    if abs(denom) > 1e-6:
        wx, wy = b_start[0] - a_end[0], b_start[1] - a_end[1]
        s = (wx * t2[1] - wy * t2[0]) / denom
        u = (wx * t0[1] - wy * t0[0]) / denom
        if 0.05 < s < gap * 1.2 and 0.05 < u < gap * 1.2:
            ctrl = (a_end[0] + s * t0[0], a_end[1] + s * t0[1])
    if ctrl is None:
        # касательные почти параллельны или пересекаются далеко:
        # дуга по касательной от a_end к середине стыка
        mx = (a_end[0] + b_start[0]) / 2.0
        my = (a_end[1] + b_start[1]) / 2.0
        ctrl = (mx + t0[0] * gap * 0.3, my + t0[1] * gap * 0.3)
    d = math.hypot(ctrl[0] - a_end[0], ctrl[1] - a_end[1])
    max_d = gap * 0.9
    if d > max_d and d > 1e-9:
        k = max_d / d
        ctrl = (a_end[0] + (ctrl[0] - a_end[0]) * k,
                a_end[1] + (ctrl[1] - a_end[1]) * k)
    pts = []
    for i in range(1, CURVE_PTS + 1):
        t = i / (CURVE_PTS + 1)
        mt = 1 - t
        pts.append((mt * mt * a_end[0] + 2 * mt * t * ctrl[0] + t * t * b_start[0],
                    mt * mt * a_end[1] + 2 * mt * t * ctrl[1] + t * t * b_start[1]))
    return pts


def connector_hugs_ink(conn_pts, strokes, a_end, b_start, cap):
    """Перемычка идёт вдоль уже имеющегося штриха (двойная палка)?

    Сравниваем точки перемычки со ВСЕМИ штрихами глифа. Зоны возле
    точек крепления (a_end, b_start) не считаются — там перемычка
    обязана касаться своих штрихов. Если заметная доля среднего участка
    перемычки лежит ближе HUG_INK_TOL*cap от чужих чернил — это не
    заполнение разрыва, а дубль штриха: отказ."""
    if len(conn_pts) < 2:
        return False
    tol = HUG_INK_TOL * cap
    n = hug = 0
    total = len(conn_pts)
    for idx, p in enumerate(conn_pts):
        t = (idx + 1) / (total + 1)          # 0..1 вдоль перемычки
        if t < 0.12 or t > 0.88:             # края — законный контакт
            continue
        near_a = math.hypot(p[0] - a_end[0], p[1] - a_end[1]) < HUG_TIP
        near_b = math.hypot(p[0] - b_start[0], p[1] - b_start[1]) < HUG_TIP
        if near_a or near_b:
            continue
        n += 1
        for s in strokes:
            for k in range(len(s) - 1):
                if dist_to_seg(p, s[k], s[k + 1]) < tol:
                    hug += 1
                    break
            else:
                continue
            break
    return n > 0 and (hug / n) > HUG_INK_MAX


def is_mark(stroke, cap):
    ys = [p[1] for p in stroke]
    span_x = max(p[0] for p in stroke) - min(p[0] for p in stroke)
    span_y = max(ys) - min(ys)
    return (min(ys) > MARK_MIN_Y * cap
            and max(span_x, span_y) < MARK_MAX_SPAN * cap)


def oriented(strokes, i, rev):
    s = list(strokes[i])
    if rev:
        s.reverse()
    return s


def backtrack_over_connector(tip, s, a_end, b_start):
    """Штрих s сразу возвращается по перемычке назад (перо поедет по
    только что нарисованной линии)? Да — если заметная часть первых
    HUG_LEN единиц пути s идёт вдоль перемычки."""
    dx, dy = b_start[0] - a_end[0], b_start[1] - a_end[1]
    L = math.hypot(dx, dy)
    if L < 1e-9:
        return True
    ux, uy = dx / L, dy / L
    walked = 0.0
    hug = 0
    n = 0
    for k in range(len(s) - 1):
        c, d = s[k], s[k + 1]
        seglen = math.hypot(d[0] - c[0], d[1] - c[1])
        steps = max(1, int(seglen // 10))
        for j in range(steps):
            t = j / steps
            p = (c[0] + (d[0] - c[0]) * t, c[1] + (d[1] - c[1]) * t)
            if walked >= HUG_LEN:
                return (hug / n) > HUG_MAX if n else False
            if math.hypot(p[0] - tip[0], p[1] - tip[1]) < HUG_TIP:
                continue
            # расстояние до линии перемычки и проекция на неё
            vx, vy = p[0] - a_end[0], p[1] - a_end[1]
            proj = vx * ux + vy * uy
            perp = abs(vx * uy - vy * ux)
            if 0.0 <= proj <= L and perp < HUG_TOL:
                hug += 1
            n += 1
            walked += seglen / steps
        if walked >= HUG_LEN:
            break
    return (hug / n) > HUG_MAX if n else False


def repair_glyph(strokes, cap, x_h, debug_ch=None, strict=False):
    strokes = [list(s) for s in strokes if len(s) > 1]
    if len(strokes) < 2:
        return strokes, []

    marks = [i for i, s in enumerate(strokes) if is_mark(s, cap)]
    body = [i for i in range(len(strokes)) if i not in marks]
    if len(body) < 2:
        return strokes, []

    # Заглавные/цифры/знаки печатаются раздельными штрихами —
    # сшиваем только мелкие зазоры и никогда — ретрейсом
    max_chain = (0.25 if strict else MAX_CHAIN_GAP) * cap
    max_retr = 0.0 if strict else MAX_RETRACE_GAP * cap

    # --- вход: конец штриха, ближайший к точке соединения (0, x_h)
    best = None
    for i in body:
        for rev in (False, True):
            tip = strokes[i][0] if not rev else strokes[i][-1]
            d = math.hypot(tip[0], tip[1] - x_h)
            if best is None or d < best[0]:
                best = (d, i, rev)
    d_in, e_i, e_rev = best
    if d_in > 0.5 * cap:          # вход слишком далеко — не рискуем
        return strokes, []

    # --- выход: конец штриха с максимальным x на высоте соединения
    def exit_score(i, rev):
        tip = strokes[i][-1] if not rev else strokes[i][0]
        penalty = abs(tip[1] - x_h) * 0.6
        return tip[0] - penalty

    x_i = x_rev = None
    best_sc = None
    for i in body:
        for rev in (False, True):
            sc = exit_score(i, rev)
            if best_sc is None or sc > best_sc:
                best_sc = sc
                x_i, x_rev = i, rev
    if (x_i, x_rev) == (e_i, e_rev) and len(body) > 1:
        # вход и выход в одном штрихе: других не пришиваем
        out = [oriented(strokes, e_i, e_rev)]
        for i in marks:
            out.append(list(strokes[i]))
        for i in body:
            if i != e_i:
                out.append(list(strokes[i]))
        return out, []

    max_x = best_sc
    if max_x < 0.45 * cap:        # внятного выхода нет — не рискуем
        return strokes, []

    # --- жадная сборка от входа, выход — только последним
    order = [(e_i, e_rev)]
    used = {e_i}
    joints = []
    cur_end = strokes[e_i][-1] if not e_rev else strokes[e_i][0]
    dbg = []
    if debug_ch:
        print(f"[debug {debug_ch}] entry=stroke{e_i} rev={e_rev} "
              f"exit=stroke{x_i} rev={x_rev}; marks={marks}")

    while True:
        best = None
        rejects = []
        for i in body:
            if i in used:
                continue
            for rev in (False, True):
                tag = f"s{i}{'R' if rev else 'F'}"
                tip = strokes[i][0] if not rev else strokes[i][-1]
                # касательная выхода из текущего хвоста
                tail_stroke = oriented(strokes, order[-1][0], order[-1][1])
                t_out = unit(cur_end[0] - tail_stroke[-2][0],
                             cur_end[1] - tail_stroke[-2][1])
                t_link = unit(tip[0] - cur_end[0], tip[1] - cur_end[1])
                dot = t_out[0] * t_link[0] + t_out[1] * t_link[1]
                turn = turn_deg(t_out, t_link)
                gap = math.hypot(tip[0] - cur_end[0], tip[1] - cur_end[1])
                if gap > max_chain:
                    rejects.append(f"{tag}:gap{gap:.0f}>{max_chain:.0f}")
                    continue
                if turn > TURN_MAX_DEG:
                    rejects.append(f"{tag}:turn{turn:.0f}")
                    continue
                s_next = oriented(strokes, i, rev)
                if (gap >= 60.0
                        and backtrack_over_connector(tip, s_next,
                                                     cur_end, tip)):
                    rejects.append(f"{tag}:backtrack")
                    continue
                if connector_crosses(cur_end, tip, strokes, tol=NEAR_END):
                    rejects.append(f"{tag}:cross")
                    continue
                # перемычка не должна идти вдоль уже нарисованных штрихов
                # (двойная «палка» на бумаге: л, и, й, м, ж)
                if gap >= 25.0:
                    conn = make_connector(cur_end,
                                          tail_stroke[-2], tip,
                                          s_next[1] if len(s_next) > 1
                                          else tip)
                    if connector_hugs_ink(conn, strokes, cur_end, tip, cap):
                        rejects.append(f"{tag}:hug")
                        continue
                score = gap + turn * 0.6
                if best is None or score < best[0]:
                    best = (score, i, rev, gap, False)
        if best is None:
            if debug_ch:
                print(f"[debug {debug_ch}] стоп: кандидатов нет "
                      f"(cur_end=({cur_end[0]:.0f},{cur_end[1]:.0f}), "
                      f"used={sorted(used)}); отказы: {rejects}")
            break
        _, i, rev, gap, retrace = best
        joints.append((gap, retrace))  # retrace всегда False — ветка выключена
        order.append((i, rev))
        used.add(i)
        s = oriented(strokes, i, rev)
        cur_end = s[-1]
        if debug_ch:
            print(f"[debug {debug_ch}] + stroke{i} rev={rev} "
                  f"gap={gap:.0f}u={gap*10/cap:.2f}мм retrace={retrace}")
        if i == x_i:
            break                       # дошли до выхода — готово

    # --- сборка: цепочка сливается в непрерывные полилинии
    out = []
    for pos, (i, rev) in enumerate(order):
        s = oriented(strokes, i, rev)
        if pos > 0:
            a_end = out[-1][-1]
            a_prev = out[-1][-2] if len(out[-1]) > 1 else a_end
            b_start = s[0]
            b_next = s[1] if len(s) > 1 else b_start
            out[-1].extend(make_connector(a_end, a_prev, b_start, b_next))
            out[-1].extend(s)
        else:
            out.append(s)
    tail = [list(strokes[i]) for i in body if i not in used]
    for i in marks:
        out.append(list(strokes[i]))
    out.extend(tail)
    return out, joints


def repair_glyph_full(strokes, cap, x_h, debug_ch=None):
    return repair_glyph(strokes, cap, x_h, debug_ch)


def main():
    ap = argparse.ArgumentParser(
        description="Лечение штрихового шрифта: сшивка разорванных букв")
    ap.add_argument("font", help="JSON шрифта")
    ap.add_argument("-o", "--out", default=None,
                    help="куда сохранить (по умолчанию *_fixed.json)")
    ap.add_argument("--backup", action="store_true",
                    help="сохранить копию оригинала рядом")
    ap.add_argument("--stats", action="store_true",
                    help="только статистика, без записи")
    args = ap.parse_args()

    data = json.load(open(args.font, encoding="utf-8"))
    cap = data.get("cap_height", 634.0)
    x_h = cap * 0.26          # высота линии соединения (у propisi ~162/634)
    glyphs = data["glyphs"]

    n_chained = 0
    n_conn = 0
    n_retrace = 0
    total_before = sum(len(g["strokes"]) for g in glyphs.values())
    report = []
    debug_chars = set("пиitйлт") if not args.stats else set()
    for ch, G in glyphs.items():
        strict = ch.isupper() or ch.isdigit() or not ch.isalpha()
        fixed, joints = repair_glyph(G["strokes"], cap, x_h,
                                     debug_ch=ch if ch in debug_chars else None,
                                     strict=strict)
        if len(fixed) < len(G["strokes"]):
            n_chained += 1
        n_conn += len(joints)
        n_retrace += sum(1 for _, r in joints if r)
        if joints:
            biggest = max(d for d, _ in joints)
            report.append((ch, len(G["strokes"]), len(fixed),
                           biggest * 10.0 / cap))
        G["strokes"] = [[[round(p[0], 1), round(p[1], 1)] for p in s]
                        for s in fixed]
    total_after = sum(len(g["strokes"]) for g in glyphs.values())

    print(f"глифов исправлено: {n_chained}, перемычек добавлено: {n_conn} "
          f"(ретрейс: {n_retrace})")
    print(f"штрихов: {total_before} -> {total_after}")
    top = sorted(report, key=lambda r: -r[3])[:12]
    print("самые большие стыки (мм при 10 мм):",
          ", ".join(f"{c!r} {d:.2f}" for c, _, _, d in top))

    if args.stats:
        return

    out = args.out
    if out is None:
        root, dot, ext = args.font.rpartition(".")
        out = (root or args.font) + "_fixed" + ("." + ext if ext else "")
    if args.backup:
        import shutil
        bpath = (root or args.font) + "_original" + ("." + ext if ext else "")
        shutil.copyfile(args.font, bpath)
        print("оригинал ->", bpath)

    data["note"] = (data.get("note", "") +
                    " | лечение: сшивка штрихов с гладкими перемычками "
                    "(repair_font.py)").strip(" |")
    if "Прописи" in data.get("name", ""):
        data["cursive"] = True
    with open(out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    print("сохранено ->", out)


if __name__ == "__main__":
    main()
