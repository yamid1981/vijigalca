#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
pdf2gcode.py — печать PDF перьевым плоттером: НАСТОЯЩАЯ вёрстка «как есть».

Зачем: в Word/Writer: Файл -> Сохранить как PDF, затем:
    py pdf2gcode.py документ.pdf
и перо рисует лист ОДИН В ОДИН: буквы — настоящим шрифтом документа
(Times New Roman, Calibri и т.п., контурами), заголовки на своих местах,
таблицы и рамки — линиями, а ЧЁРНЫЕ места (жирные плашки, логотипы,
залитые значки) ЗАКРАШИВАЮТСЯ штрихом выбранного типа:

  --fill lines    параллельные строки (перо поднимается на переходах)
  --fill zigzag   зигзаг — строки соединены, где внутри фигуры (быстрее)
  --fill cross    перекрёстная штриховка (самая плотная)
  --fill off      только контуры букв, без закраски
  --fill-step 0.4    расстояние между штрихами, мм (плотность)
  --fill-angle 45    угол штриха, градусы

  py pdf2gcode.py документ.pdf                       (все страницы)
  py pdf2gcode.py документ.pdf --fill cross --fill-step 0.35
  py pdf2gcode.py документ.pdf --fill off            (контуры букв, быстро)
  py pdf2gcode.py документ.pdf --outdir gcode        (куда класть .nc)

Страница PDF печатается 1:1 на таком же листе: ноль станка — ЛЕВЫЙ
НИЖНИЙ угол листа, как обычно. Результат: документ-p1.nc, -p2.nc, ...
(рядом лежат и постраничные .svg — их можно доработать в svg2gcode).

Требуется пакет PyMuPDF (работает и 1.x, и 2.x):   pip install pymupdf
Что НЕ печатается: растровые картинки (фото, сканы) — они пропускаются.

Проверить версию:  py pdf2gcode.py --version
"""
import argparse
import os
import re
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)

import svg2gcode  # noqa: E402

VERSION = "1.2"


def import_pymupdf():
    """PyMuPDF 2.x: каноническое имя import pymupdf; у 1.x — import fitz.
    В 2.0 имя fitz устарело (FutureWarning), в будущих 2.x его уберут."""
    try:
        import pymupdf
        return pymupdf
    except ImportError:
        try:
            import fitz
            return fitz
        except ImportError:
            sys.exit("Для PDF нужен пакет PyMuPDF. Установите его командой:\n"
                     "    pip install pymupdf")


def strip_raster_images(svg_text):
    """Выкинуть <image> из SVG от PyMuPDF: перо их всё равно не печатает,
    а в памяти/на диске они занимают сотни мегабайт (base64) и тормозят
    разбор до таймаута. Возвращает (svg, сколько выкинуто)."""
    n = len(re.findall(r"<image\b", svg_text))
    if n:
        svg_text = re.sub(r"<image\b[^>]*(?:/>|>.*?</image>)", "", svg_text,
                          flags=re.S)
    return svg_text, n


def patch_svg(svg_text, w_pt, h_pt):
    """SVG от PyMuPDF -> наш формат: fill для глифов/заливок, лист в мм.

    PyMuPDF пишет:
      текст (буквы)      <use xlink:href="#font_.." .../>  — fill по умолчанию
      только контур      <path ... fill="none" stroke="#000000" .../>
      только заливка     <path ... fill-rule="evenodd"/>   — fill НЕ пишет!
    Наш collect() считает «без fill» = без закраски, поэтому проставляем
    fill="#000000" тем тегам, у которых его нет (но нет и stroke)."""
    w_mm = w_pt * 25.4 / 72.0
    h_mm = h_pt * 25.4 / 72.0

    m = re.search(r"<svg\b[^>]*>", svg_text)
    if m:
        head = m.group(0)
        head = re.sub(r'width="[^"]*"', f'width="{w_mm:.4f}mm"', head, count=1)
        head = re.sub(r'height="[^"]*"', f'height="{h_mm:.4f}mm"', head,
                      count=1)
        svg_text = svg_text[:m.start()] + head + svg_text[m.end():]

    def patch_tag(mo):
        tag = mo.group(0)
        if tag.startswith("<use"):
            if "fill=" not in tag:
                tag = tag.replace("<use", '<use fill="#000000"', 1)
        else:
            if "fill=" not in tag and "stroke=" not in tag:
                tag = tag.replace("<path", '<path fill="#000000"', 1)
        return tag

    svg_text = re.sub(r"<(?:use|path)\b[^>]*>", patch_tag, svg_text)
    return svg_text


def convert_pdf(src, args):
    pm = import_pymupdf()

    doc = pm.open(src)
    if doc.needs_pass:
        sys.exit(f"PDF {src!r} защищён паролем — снимите защиту и повторите")

    base = os.path.splitext(src)[0]
    outdir = args.outdir or os.path.dirname(src) or "."
    os.makedirs(outdir, exist_ok=True)

    if args.out and doc.page_count > 1:
        sys.exit("--out подходит только для одностраничного PDF; "
                 "для многостраничного используйте --outdir")

    outs = []
    for pno in range(doc.page_count):
        page = doc[pno]
        rect = page.rect
        w_mm, h_mm = rect.width * 25.4 / 72.0, rect.height * 25.4 / 72.0
        print(f"-- {src}: страница {pno + 1}/{doc.page_count} "
              f"({w_mm:.0f}x{h_mm:.0f} мм)")
        n_img = len(page.get_images())
        if n_img:
            print(f"   ! растровых картинок на странице: {n_img} — перо их "
                  f"НЕ печатает (фото/скан будут пропущены)")

        if not hasattr(page, "get_svg_image"):
            sys.exit("В этой версии PyMuPDF нет get_svg_image — обновите "
                     "пакет:\n    pip install --upgrade pymupdf")
        svg_text = page.get_svg_image(matrix=pm.Matrix(1, 1))
        svg_text, n_stripped = strip_raster_images(svg_text)
        if n_stripped:
            print(f"   * выкинутых из SVG растровых картинок: {n_stripped} "
                  f"(перо их не печатает)")
        svg_text = patch_svg(svg_text, rect.width, rect.height)
        svg_path = os.path.join(outdir, f"{os.path.basename(base)}"
                                        f"-p{pno + 1}.svg")
        with open(svg_path, "w", encoding="utf-8") as f:
            f.write(svg_text)

        pargs = argparse.Namespace(**vars(args))
        pargs.svg = [svg_path]
        pargs.page_size_mm = (w_mm, h_mm)   # рисунок 1:1 на своём месте листа
        if args.out:
            pargs.out = args.out
        else:
            pargs.out = os.path.join(outdir,
                                     f"{os.path.basename(base)}-p{pno + 1}.nc")
        out, stats = svg2gcode.convert_one(svg_path, pargs)
        outs.append(out)

        t_draw = stats["draw"] / args.f_draw if args.f_draw else 0.0
        t_z = stats["downs"] * abs(args.z_up - args.z_down) / args.f_z \
            if args.f_z else 0.0
        t_tr = stats["travel"] / args.f_travel if args.f_travel else 0.0
        minutes = t_draw + t_z + t_tr
        print(f"OK -> {out}")
        print(f"   опусканий пера: {stats['strokes']}, "
              f"рисование: {stats['draw']:.0f} мм, "
              f"подвод: {stats['travel']:.0f} мм, "
              f"оценка ~{minutes:.0f} мин")

    if doc.page_count > 1:
        print(f"Готово: страниц {doc.page_count}. Каждую страницу печатайте "
              f"на своём листе (ноль — левый нижний угол листа).")
    doc.close()
    return outs


def main():
    ap = svg2gcode.build_parser()
    ap.prog = "pdf2gcode.py"
    ap.description = ("PDF -> G-code: настоящая вёрстка Word «как есть» "
                      "для перьевого плоттера (FluidNC/GRBL)")
    for a in ap._actions:  # noqa: SLF001
        if getattr(a, "dest", "") == "version":
            a.version = f"pdf2gcode {VERSION}"
        elif getattr(a, "dest", "") == "svg":
            a.help = "входные .pdf файлы"
        elif getattr(a, "dest", "") == "page":
            a.default = "off"
            a.help = "лист; PDF уже страница — по умолчанию off (1:1)"
        elif getattr(a, "dest", "") == "fit":
            a.default = "none"
        elif getattr(a, "dest", "") == "out":
            a.help = "имя .nc (только для одностраничного PDF)"
    ap.add_argument("--outdir", default=None,
                    help="папка для .nc и .svg (по умолчанию рядом с PDF)")

    args = ap.parse_args()

    total_min = 0.0
    for src in args.svg:
        if not os.path.isfile(src):
            sys.exit(f"Файл не найден: {src!r}")
        outs = convert_pdf(src, args)

    print("Не забудьте: чёрные места закрашиваются штрихом "
          "(--fill lines/zigzag/cross, --fill-step).")


if __name__ == "__main__":
    main()
