#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
svg2font.py — создание штрихового шрифта (stroke-font-v1 JSON) из SVG
с обводками вашего почерка.

Как пользоваться (кратко, подробно в README.txt):
  1) py svg2font.py --make-template template.svg            # шаблон-сетка
  2) открыть template.svg в Inkscape, нарисовать буквы
     (инструмент «Карандаш», один непрерывный контур на букву,
      подъём пера = разрыв контура: M ... L ... M ... L ...)
  3) py svg2font.py template.svg -o my_handwriting.json

Координаты: SVG y растёт вниз -> в шрифте y вверх, baseline берётся из
--baseline (в шаблоне отмечен линией).

Формат глифов: stroke-font-v1, совместим с text2gcode.py.
"""
import argparse
import json
import math
import re
import sys
import xml.etree.ElementTree as ET

SVGNS = "{http://www.w3.org/2000/svg}"

# ---------- флаттенение кривых ----------

def bez3(p0, p1, p2, p3, t):
    mt = 1 - t
    x = mt**3*p0[0] + 3*mt*mt*t*p1[0] + 3*mt*t*t*p2[0] + t**3*p3[0]
    y = mt**3*p0[1] + 3*mt*mt*t*p1[1] + 3*mt*t*t*p2[1] + t**3*p3[1]
    return (x, y)

def bez2(p0, p1, p2, t):
    mt = 1 - t
    x = mt*mt*p0[0] + 2*mt*t*p1[0] + t*t*p2[0]
    y = mt*mt*p0[1] + 2*mt*t*p1[1] + t*t*p2[1]
    return (x, y)

TOKEN = re.compile(r"([MmLlHhVvCcSsQqTtAaZz])|(-?\d*\.?\d+(?:e[-+]?\d+)?)", re.I)

def parse_path_d(d, curve_n=14):
    """path 'd' -> список полилиний [(x,y), ...]. Поддержка MLCQSHVTZ (кроме A)."""
    toks = [(m.group(1), m.group(2)) for m in TOKEN.finditer(d)]
    i, cx = 0, 0.0
    cy = 0.0
    sx = sy = 0.0
    strokes, cur = [], []
    cmd = None
    last_ctrl = None

    def nums():
        nonlocal i
        vals = []
        while i < len(toks) and toks[i][0] is None and toks[i][1] is not None:
            vals.append(float(toks[i][1])); i += 1
        return vals

    def flush():
        nonlocal cur
        if len(cur) >= 2:
            strokes.append(cur)
        cur = []

    while i < len(toks):
        c, v = toks[i]
        if c is not None:
            cmd = c; i += 1
        if cmd is None:
            break
        rel = cmd.islower()
        C = cmd.upper()
        if C == "M":
            vals = nums()
            for k in range(0, len(vals) - 1, 2):
                x, y = vals[k], vals[k+1]
                if rel and (k > 0 or cx != 0 or cy != 0):
                    x += cx if k == 0 else cur[-1][0]
                    y += cy if k == 0 else cur[-1][1]
                if k > 0:
                    cur.append((x, y))
                else:
                    flush(); cx, cy, sx, sy = x, y, x, y; cur = [(x, y)]
            if len(vals) == 2:
                cx, cy, sx, sy = vals[0], vals[1], vals[0], vals[1]
                flush(); cur = [(cx, cy)]
            if len(vals) % 2 != 0 or not vals:
                break
            if len(vals) > 2:
                cx, cy = cur[-1]
            cmd = "l" if cmd == "m" else "L"
        elif C == "L":
            vals = nums()
            for k in range(0, len(vals) - 1, 2):
                x, y = (cx + vals[k], cy + vals[k+1]) if rel else (vals[k], vals[k+1])
                cur.append((x, y)); cx, cy = x, y
        elif C == "H":
            for v_ in nums():
                x = cx + v_ if rel else v_
                cur.append((x, cy)); cx = x
        elif C == "V":
            for v_ in nums():
                y = cy + v_ if rel else v_
                cur.append((cx, y)); cy = y
        elif C in ("C", "S"):
            vals = nums()
            step = 6 if C == "C" else 4
            for k in range(0, len(vals) - step + 1, step):
                if C == "C":
                    p1 = (cx + vals[k], cy + vals[k+1]) if rel else (vals[k], vals[k+1])
                    p2 = (cx + vals[k+2], cy + vals[k+3]) if rel else (vals[k+2], vals[k+3])
                    p3 = (cx + vals[k+4], cy + vals[k+5]) if rel else (vals[k+4], vals[k+5])
                else:
                    p1 = last_ctrl if last_ctrl else (cx, cy)
                    p2 = (cx + vals[k], cy + vals[k+1]) if rel else (vals[k], vals[k+1])
                    p3 = (cx + vals[k+2], cy + vals[k+3]) if rel else (vals[k+2], vals[k+3])
                p0 = (cx, cy)
                for j in range(1, curve_n + 1):
                    cur.append(bez3(p0, p1, p2, p3, j / curve_n))
                last_ctrl = p2
                cx, cy = p3
            if C == "C" and vals:
                last_ctrl = p2
        elif C in ("Q", "T"):
            vals = nums()
            step = 4 if C == "Q" else 2
            for k in range(0, len(vals) - step + 1, step):
                if C == "Q":
                    p1 = (cx + vals[k], cy + vals[k+1]) if rel else (vals[k], vals[k+1])
                    p2 = (cx + vals[k+2], cy + vals[k+3]) if rel else (vals[k+2], vals[k+3])
                else:
                    p1 = last_ctrl if last_ctrl else (cx, cy)
                    p2 = (cx + vals[k], cy + vals[k+1]) if rel else (vals[k], vals[k+1])
                p0 = (cx, cy)
                for j in range(1, curve_n + 1):
                    cur.append(bez2(p0, p1, p2, j / curve_n))
                last_ctrl = p1
                cx, cy = p2
        elif C == "Z":
            if cur and (abs(cur[-1][0] - sx) > 1e-6 or abs(cur[-1][1] - sy) > 1e-6):
                cur.append((sx, sy))
            flush()
            cx, cy = sx, sy
        elif C == "A":
            n = 7
            nums_n = nums()
            for k in range(0, len(nums_n) - n + 1, n):
                x = (cx + nums_n[k+5]) if rel else nums_n[k+5]
                y = (cy + nums_n[k+6]) if rel else nums_n[k+6]
                cur.append((x, y)); cx, cy = x, y
        else:
            break
    flush()
    return strokes

def elem_polylines(el):
    """Все полилинии элемента (path/line/polyline/polygon)."""
    tag = el.tag.replace(SVGNS, "")
    out = []
    if tag == "path":
        d = el.get("d", "")
        if d.strip():
            out.extend(parse_path_d(d))
    elif tag in ("line", "polyline", "polygon"):
        pts = re.findall(r"(-?\d*\.?\d+)[, ](-?\d*\.?\d+)", el.get("points", ""))
        if len(pts) >= 2:
            out.append([(float(a), float(b)) for a, b in pts])
    elif tag == "rect":
        x, y = float(el.get("x", 0)), float(el.get("y", 0))
        w, h = float(el.get("width", 0)), float(el.get("height", 0))
        out.append([(x, y), (x + w, y), (x + w, y + h), (x, y + h), (x, y)])
    return out

def apply_transform(el, pts):
    """Простые transform: translate/scale/matrix (одна на элемент)."""
    t = el.get("transform")
    if not t:
        return pts
    m = re.match(r"\s*(translate|scale|matrix)\s*\(([^)]*)\)", t)
    if not m:
        return pts
    kind, vals = m.group(1), [float(x) for x in re.findall(r"-?\d*\.?\d+", m.group(2))]
    res = []
    for x, y in pts:
        if kind == "translate":
            x, y = x + vals[0], y + (vals[1] if len(vals) > 1 else 0)
        elif kind == "scale":
            sx = vals[0] if vals else 1
            sy = vals[1] if len(vals) > 1 else sx
            x, y = x * sx, y * sy
        elif kind == "matrix":
            a, b, c, d_, e, f = (vals + [0]*6)[:6]
            x, y = a*x + c*y + e, b*x + d_*y + f
        res.append((x, y))
    return res

def all_paths(root):
    """(id, polylines) по всем элементам документа."""
    out = []
    for el in root.iter():
        tag = el.tag.replace(SVGNS, "")
        if tag in ("path", "line", "polyline", "polygon", "rect"):
            lines = [apply_transform(el, pl) for pl in elem_polylines(el)]
            lines = [l for l in lines if len(l) >= 2]
            if lines:
                eid = el.get("id", "")
                out.append((eid, lines))
    return out

# ---------- шаблон ----------

RUS = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя0123456789.,!?"

def make_template(path, cols=12, cell_w=120, cell_h=170, margin=60):
    chars = list(RUS)
    rows = math.ceil(len(chars) / cols)
    W = margin * 2 + cols * cell_w
    H = margin * 2 + rows * cell_h + 40
    parts = []
    parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" '
                 f'width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
    parts.append(f'<rect width="{W}" height="{H}" fill="white"/>')
    parts.append(f'<text x="{margin}" y="30" font-size="18" fill="#888">'
                 f'Рисуйте буквы по ячейкам. Базовая линия — сплошная черта, '
                 f'заглавные — до пунктирной. Один контур = одна буква.</text>')
    baseline = 0
    for idx, ch in enumerate(chars):
        r, c = divmod(idx, cols)
        x0 = margin + c * cell_w
        y0 = margin + 40 + r * cell_h
        bl = y0 + cell_h * 0.78          # baseline в ячейке
        cap = y0 + cell_h * 0.10         # верх заглавных
        baseline = bl
        parts.append(f'<rect x="{x0}" y="{y0}" width="{cell_w}" height="{cell_h}" '
                     f'fill="none" stroke="#cccccc"/>')
        parts.append(f'<line x1="{x0}" y1="{bl:.0f}" x2="{x0+cell_w}" y2="{bl:.0f}" '
                     f'stroke="#4488ff"/>')
        parts.append(f'<line x1="{x0}" y1="{cap:.0f}" x2="{x0+cell_w}" y2="{cap:.0f}" '
                     f'stroke="#cccccc" stroke-dasharray="4 4"/>')
        parts.append(f'<text x="{x0+cell_w-14}" y="{y0+18}" font-size="13" '
                     f'fill="#999">{ch}</text>')
    parts.append(f'<line x1="0" y1="{baseline:.0f}" x2="{W}" y2="{baseline:.0f}" '
                 f'stroke="#ff0000" stroke-width="0.5" opacity="0.3"/>')
    parts.append("</svg>")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))
    print(f"шаблон -> {path} ({len(chars)} ячеек)")

# ---------- сборка шрифта ----------

def build_font(svg_path, chars, cell_cols, cell_w, cell_h, margin, baseline_px,
               cap_px, adv_gap):
    tree = ET.parse(svg_path)
    root = tree.getroot()
    entries = all_paths(root)
    if not entries:
        sys.exit("В SVG не найдено контуров (path/line/polyline)")

    # сетка
    glyphs = {}
    used_by_id = set()
    for eid, lines in entries:
        m = re.match(r"ch[_ .:-]*(.+)", eid or "")
        if m and m.group(1) in chars:
            ch = m.group(1)
            pts = [p for l in lines for p in l]
            xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
            if ch not in glyphs:
                glyphs[ch] = {"lines": [], "bbox": [min(xs), min(ys), max(xs), max(ys)]}
            glyphs[ch]["lines"].extend(lines)
            glyphs[ch]["bbox"] = [
                min(glyphs[ch]["bbox"][0], min(xs)),
                min(glyphs[ch]["bbox"][1], min(ys)),
                max(glyphs[ch]["bbox"][2], max(xs)),
                max(glyphs[ch]["bbox"][3], max(ys)),
            ]
            used_by_id.add(ch)

    if not glyphs:
        # позиционный маппинг по сетке
        cell_centers = {}
        for idx, ch in enumerate(chars):
            r, c = divmod(idx, cell_cols)
            cx = margin + c * cell_w + cell_w / 2
            cy = margin + 40 + r * cell_h + cell_h / 2
            cell_centers[(c, r)] = ch
        for eid, lines in entries:
            pts = [p for l in lines for p in l]
            if not pts:
                continue
            xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
            cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
            c = int((cx - margin) // cell_w)
            r = int((cy - margin - 40) // cell_h)
            ch = cell_centers.get((c, r))
            if ch is None:
                print(f"  ! контур вне сетки: bbox x {min(xs):.0f} y {min(ys):.0f} — пропуск")
                continue
            if ch not in glyphs:
                glyphs[ch] = {"lines": [], "bbox": [min(xs), min(ys), max(xs), max(ys)]}
            glyphs[ch]["lines"].extend(lines)
            glyphs[ch]["bbox"] = [
                min(glyphs[ch]["bbox"][0], min(xs)),
                min(glyphs[ch]["bbox"][1], min(ys)),
                max(glyphs[ch]["bbox"][2], max(xs)),
                max(glyphs[ch]["bbox"][3], max(ys)),
            ]

    # координаты: y вверх, baseline=0
    scale = 22.0 / cap_px if cap_px else 1.0
    out_glyphs = {}
    for ch in chars:
        if ch not in glyphs:
            print(f"  ! нет глифа для {ch!r}")
            continue
        g = glyphs[ch]
        x0, y0, x1, y1 = g["bbox"]
        if baseline_px is None:
            # многострочный шаблон: baseline берём из ряда, где нарисован глиф
            row = int(((y0 + y1) / 2 - margin - 40) // cell_h)
            if row < 0:
                row = 0
            base = margin + 40 + row * cell_h + cell_h * 0.78
        else:
            base = baseline_px  # пользователь задал свою базовую линию
        strokes = [[[p[0] - x0, base - p[1]] for p in l] for l in g["lines"]]
        strokes = [[[px * scale, py * scale] for px, py in s] for s in strokes]
        adv = (x1 - x0) * scale + 22.0 * adv_gap
        out_glyphs[ch] = {"advance": round(adv, 1), "strokes": strokes}

    data = {
        "format": "stroke-font-v1",
        "name": svg_path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1],
        "upem": 22,
        "cap_height": 22.0,
        "note": "шрифт из почерка (svg2font.py), baseline=0, y вверх",
        "glyphs": out_glyphs,
    }
    return data

def render_preview(data, png_path):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    chars = list(data["glyphs"].keys())
    cols = 12
    rows = math.ceil(len(chars) / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 0.62, rows * 0.85),
                             constrained_layout=True)
    for ax in np.atleast_1d(axes).flat:
        ax.axis("off")
    for ax, ch in zip(np.atleast_1d(axes).flat, chars):
        g = data["glyphs"][ch]
        for s in g["strokes"]:
            pts = np.asarray(s, float)
            ax.plot(pts[:, 0], pts[:, 1], "k-", lw=1.0)
        ax.set_title(ch, fontsize=7)
        ax.set_aspect("equal")
    fig.savefig(png_path, dpi=110)
    print(f"превью -> {png_path}")

def main():
    ap = argparse.ArgumentParser(description="SVG -> stroke-font JSON (шрифт из почерка)")
    ap.add_argument("svg", nargs="?", help="входной SVG")
    ap.add_argument("-o", "--out", default="my_handwriting.json")
    ap.add_argument("--make-template", default=None,
                    help="создать шаблон-сетку (путь к файлу) и выйти")
    ap.add_argument("--chars", default=RUS, help="символы по порядку сетки")
    ap.add_argument("--cols", type=int, default=12, help="колонок в сетке")
    ap.add_argument("--cell-w", type=float, default=120)
    ap.add_argument("--cell-h", type=float, default=170)
    ap.add_argument("--margin", type=float, default=60)
    ap.add_argument("--baseline", type=float, default=None,
                    help="Y базовой линии в SVG px (по умолчанию — из шаблона)")
    ap.add_argument("--cap", type=float, default=136.0,
                    help="высота заглавной буквы в SVG px (в шаблоне ~136)")
    ap.add_argument("--adv-gap", type=float, default=0.28,
                    help="зазор между буквами (доля высоты заглавной)")
    ap.add_argument("--preview", default=None, help="PNG превью шрифта")
    args = ap.parse_args()

    if args.make_template:
        make_template(args.make_template, cols=args.cols, cell_w=args.cell_w,
                      cell_h=args.cell_h, margin=args.margin)
        return
    if not args.svg:
        sys.exit("Укажите SVG или --make-template file.svg")

    # baseline: None => для каждого глифа берём baseline его ряда шаблона
    data = build_font(args.svg, args.chars, args.cols, args.cell_w, args.cell_h,
                      args.margin, args.baseline, args.cap, args.adv_gap)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)
    print(f"OK {len(data['glyphs'])} глифов -> {args.out}")
    if args.preview:
        render_preview(data, args.preview)

if __name__ == "__main__":
    main()
