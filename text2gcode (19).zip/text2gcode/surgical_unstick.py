#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""surgical_unstick.py — точечное удаление перемычек-«палок» из v1-шрифта.

Таблица удаления составлена ВИЗУАЛЬНЫМ разбором каждой перемычки
(сетка /tmp/all_conns.png): убираем вставки, которые на бумаге видны
как отдельная линия (через букву, над буквой, дубль штриха с отрывом).
Сохраняем заполнители реальных разрывов («т» — базовая линия, «и/й/л» —
наштриховые ретрейсы, «а» — правая дуга овал→ножка) — иначе возвращаются
обрывы.
"""
import json, math, sys

ORIG = '/home/z/my-project/text2gcode/text2gcode/fonts/propisi_original.json'
V1 = sys.argv[1] if len(sys.argv) > 1 else \
    '/tmp/propisi_v1_backup.json'
OUT = sys.argv[2] if len(sys.argv) > 2 else \
    '/home/z/my-project/text2gcode/text2gcode/fonts/propisi.json'

# глиф -> список хорд (мм@10мм, 1 знак) к удалению; 'ALL' — все вставки
CUT = {
    '#':  'ALL',   # палка насквозь + дуга
    'a':  'ALL',   # дуги вдоль верха овала с отрывом
    'm':  'ALL',   # дубль первой ножки
    'n':  'ALL',   # дубль левой ноги
    'u':  'ALL',   # V-образная палка внутри чаши
    'а':  [3.2],   # только внутренняя диагональ; правая дуга остаётся
    'н':  'ALL',   # диагональ низ-лево -> верх-право насквозь
    'у':  'ALL',   # дуга над вершиной V
    'щ':  [2.0],   # верхняя дуга с отрывом; короткая на-штрихе остаётся
    'ъ':  'ALL',   # «шляпа» над буквой
    'љ':  [2.4],   # верхняя дуга
    'њ':  'ALL',   # обе верхние дуги
    'ћ':  'ALL',   # верхняя дуга
    'ў':  'ALL',   # верхняя дуга
    '…':  'ALL',   # точки соединены линиями
}

orig = json.load(open(ORIG, encoding='utf-8'))
v1 = json.load(open(V1, encoding='utf-8'))

removed = []
for ch, G in v1['glyphs'].items():
    og = orig['glyphs'].get(ch)
    if not og or ch not in CUT:
        continue
    orig_pts = set()
    for s in og['strokes']:
        for p in s:
            orig_pts.add((round(p[0], 1), round(p[1], 1)))

    def find_runs(s):
        runs, cur, in_run = [], [], False
        for p in s:
            is_new = (round(p[0], 1), round(p[1], 1)) not in orig_pts
            if is_new and not in_run:
                in_run = True
                cur = []
            if not is_new and in_run:
                in_run = False
                if cur:
                    runs.append(cur)
                cur = []
            if in_run:
                cur.append(p)
        if in_run and cur:
            runs.append(cur)
        return runs

    new_strokes = []
    for s in G['strokes']:
        runs = find_runs(s)
        if not runs:
            new_strokes.append(list(s))
            continue
        cut = []
        for run in runs:
            A, B = run[0], run[-1]
            gap = math.dist(A, B) * 10.0 / 634.0
            spec = CUT[ch]
            doit = (spec == 'ALL'
                    or any(abs(gap - g) < 0.15 for g in spec))
            cut.append(doit)
            if doit:
                removed.append((ch, gap, len(run)))
        if not any(cut):
            new_strokes.append(list(s))
            continue
        pieces, cur_piece = [], []
        run_idx, in_run = -1, False
        for p in s:
            is_new = (round(p[0], 1), round(p[1], 1)) not in orig_pts
            if is_new and not in_run:
                run_idx += 1
                in_run = True
            elif not is_new and in_run:
                in_run = False
            if in_run:
                if cut[run_idx]:
                    if len(cur_piece) > 1:
                        pieces.append(cur_piece)
                    cur_piece = []
                continue
            cur_piece.append(p)
        if len(cur_piece) > 1:
            pieces.append(cur_piece)
        new_strokes.extend(pieces)

    G['strokes'] = [[[round(p[0], 1), round(p[1], 1)] for p in s]
                    for s in new_strokes if len(s) > 1]

print(f"вырезано перемычек: {len(removed)}")
for ch, gmm, n in removed:
    print(f"  {ch!r}: gap={gmm:.2f}мм ({n} точек)")

v1['note'] = (v1.get('note', '').split(' | v2-хирургия')[0] +
              ' | v2-хирургия: удалены перемычки-палки '
              '(surgical_unstick.py, визуальная таблица)').strip(' |')
with open(OUT, 'w', encoding='utf-8') as f:
    json.dump(v1, f, ensure_ascii=False)
print('сохранено ->', OUT)
