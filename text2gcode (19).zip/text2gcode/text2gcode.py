#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
text2gcode.py — генератор G-code рукописного текста для перьевого плоттера
на FluidNC / GRBL.

Перо управляется осью Z:  G0 Z<z_up> — поднять,  G1 Z<z_down> — опустить.

Одиночный режим:

  py text2gcode.py "Привет, мир!"
  py text2gcode.py --file tekst.txt
  py text2gcode.py tekst.txt
  py text2gcode.py tekst.docx          (Word «как есть»: жирный, курсив,
                                        подчёркнутый, размеры, заголовки,
                                        центр; --rich off = только текст)
  py text2gcode.py "С праздником!" --font print --height 12 --out pozdravlenie.nc
  py text2gcode.py "Строка 1\nСтрока 2" --align center

Пакетный режим — обработать все *.txt и *.docx рядом:

  py text2gcode.py --all-txt
  py text2gcode.py
  py text2gcode.py --all-txt --dir C:\notes
  py text2gcode.py --all-txt --dir C:\notes --recursive

Каждый файл будет сохранён как .nc с тем же именем рядом с исходным.

Лист: по умолчанию текст вписывается в A4. Если он вылезает за лист,
высота букв автоматически уменьшается и текст сдвигается внутрь полей:

  --page a4|a3|a5|letter|off        размер листа (по умолчанию a4)
  --orient portrait|landscape|auto  ориентация (auto выберет сам)
  --margin 10                       поле от края листа, мм

Абзац из Блокнота или Word — это обычно ОДНА длинная строка на весь
абзац. Чтобы буквы при этом не сжимались до нечитаемых, длинные строки
автоматически переносятся по словам в ширину листа (как в редакторе):

  --wrap on|off                     перенос длинных строк (по умолчанию on);
                                    off = рисовать строку как есть, только
                                    с уменьшением высоты

Проверить версию:  py text2gcode.py --version

Оптимизация пера — включена по умолчанию, две ступени:
1) сшивка штрихов: концы штрихов, между которыми зазор не больше допуска,
рисуются одной непрерывной линией (при надобности задом наперёд и в другом
порядке) — перо поднимается вдвое реже;
2) перемычки «связного письма»: соседние буквы и штрихи с зазором до
большего допуска соединяются короткой линией без подъёма — как в рукописи.

  --join-eps ЧИСЛО|0                допуск сшивки, мм; по умолчанию auto
                                    = 3% высоты букв (~0.3 мм при 10 мм);
                                    0 = выключить сшивку
  --link-mm ЧИСЛО|0                 перемычки между буквами, мм; auto
                                    = 15% высоты букв (~1.5 мм при 10 мм);
                                    0 = выключить перемычки
  --z-hop ЧИСЛО                     короткие переходы (до 5 мм) поднимать
                                    не на --z-up, а на эту высоту, мм
                                    (например 1.0; по умолчанию 0 = выкл)

По умолчанию скорости:
  рисование F3000.000
  подвод    F9000.000
  Z         F9000.000
  Z вверх   4.000

Шрифты лежат в папке ./fonts рядом со скриптом (формат stroke-font-v1 JSON).
"""
import argparse
import json
import math
import os
import sys
import re
import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION = "2.11"

TEXT_EXTENSIONS = {".txt", ".text", ".md", ".utf8", ".ansi", ".docx"}

PAGE_SIZES = {
    "a4": (210.0, 297.0),      # (ширина, высота) в портретной ориентации
    "a3": (297.0, 420.0),
    "a5": (148.0, 210.0),
    "letter": (215.9, 279.4),
}

TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "c", "ч": "ch", "ш": "sh", "щ": "sch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}


def read_docx(path):
    """
    Читает текст из документа Word (.docx) без внешних библиотек:
    абзацы -> строки, табуляция -> пробел, принудительный перенос -> \n.
    """
    import zipfile
    import xml.etree.ElementTree as ET

    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

    if not os.path.isfile(path):
        sys.exit(f"Файл не найден: {path!r}")

    try:
        with zipfile.ZipFile(path) as z:
            xml_bytes = z.read("word/document.xml")
    except zipfile.BadZipFile:
        sys.exit(
            f"{path!r} не похож на документ Word (.docx). "
            "Если это старый .doc — пересохраните в Word как .docx или .txt"
        )
    except KeyError:
        sys.exit(f"В {path!r} нет word/document.xml — это не .docx?")

    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as e:
        sys.exit(f"Ошибка чтения {path!r}: {e}")

    paras = []
    for p in root.iter(W + "p"):
        parts = []
        for node in p.iter():
            if node.tag == W + "t":
                parts.append(node.text or "")
            elif node.tag == W + "tab":
                parts.append(" ")
            elif node.tag == W + "br":
                parts.append("\n")
        paras.append("".join(parts))

    return "\n".join(paras)


def read_text_file(path):
    """Читает текстовый файл, пытаясь угадать кодировку Notepad."""
    if not os.path.isfile(path):
        sys.exit(f"Файл не найден: {path!r}")

    if path.lower().endswith(".docx"):
        return read_docx(path)

    with open(path, "rb") as f:
        data = f.read()

    if not data:
        return ""

    # UTF-16 with BOM
    if data.startswith(b"\xff\xfe") or data.startswith(b"\xfe\xff"):
        try:
            return data.decode("utf-16")
        except UnicodeDecodeError:
            pass

    # UTF-8 with BOM
    if data.startswith(b"\xef\xbb\xbf"):
        try:
            return data.decode("utf-8-sig")
        except UnicodeDecodeError:
            pass

    # Обычный UTF-8, затем Windows-1251, затем latin-1 как запасной вариант
    for enc in ("utf-8", "cp1251", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue

    return data.decode("utf-8", errors="replace")


def normalize_text(s):
    # На случай, если файл был ошибочно прочитан как UTF-16 без BOM
    s = s.replace("\x00", "")
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = s.replace("\t", " ")

    # Убираем только завершающие переводы строки, пустые строки внутри сохраняем
    return s.rstrip("\n")


# ==============================================================
# Word «как есть» (v2.6): форматирование из .docx -> штрихи
# ==============================================================

WORD_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

HEAD_RATIO = {1: 1.9, 2: 1.6, 3: 1.35, 4: 1.2, 5: 1.1}


def _run_style(r):
    """(bold, italic, underline, sz_полупункты) из w:rPr run'а."""
    rpr = r.find(WORD_NS + "rPr")
    if rpr is None:
        return (False, False, False, None)

    def flag(tag):
        e = rpr.find(WORD_NS + tag)
        if e is None:
            return False
        v = e.get(WORD_NS + "val")
        return not (v is not None and v.lower() in ("0", "false", "none"))

    sz = None
    e = rpr.find(WORD_NS + "sz")
    if e is not None:
        try:
            sz = float(e.get(WORD_NS + "val"))
        except (TypeError, ValueError):
            pass
    return (flag("b"), flag("i"), flag("u"), sz)


def read_docx_rich(path):
    """
    .docx -> (абзацы, метаданные) с сохранением форматирования.

    абзац = {"align": None|"center"|"right", "pstyle": id|None,
             "chars": [[символ, b, i, u, sz, run_id, ratio], ...]}
    ratio проставляется позже с учётом body_sz и стилей.
    """
    import zipfile
    import xml.etree.ElementTree as ET

    W = WORD_NS

    if not os.path.isfile(path):
        sys.exit(f"Файл не найден: {path!r}")

    try:
        with zipfile.ZipFile(path) as z:
            xml_bytes = z.read("word/document.xml")
            try:
                styles_bytes = z.read("word/styles.xml")
            except KeyError:
                styles_bytes = None
    except zipfile.BadZipFile:
        sys.exit(
            f"{path!r} не похож на документ Word (.docx). "
            "Если это старый .doc — пересохраните в Word как .docx или .txt"
        )
    except KeyError:
        sys.exit(f"В {path!r} нет word/document.xml — это не .docx?")

    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as e:
        sys.exit(f"Ошибка чтения {path!r}: {e}")

    # --- styles.xml: базовый размер, размеры и уровни заголовков стилей
    doc_sz = None
    style_sz = {}
    style_head = {}
    if styles_bytes:
        try:
            sroot = ET.fromstring(styles_bytes)
            dd = sroot.find(W + "docDefaults")
            if dd is not None:
                e = dd.find(f"{W}rPrDefault/{W}rPr/{W}sz")
                if e is not None:
                    try:
                        doc_sz = float(e.get(W + "val"))
                    except (TypeError, ValueError):
                        pass
            for st in sroot.findall(W + "style"):
                sid = st.get(W + "styleId")
                if not sid:
                    continue
                e = st.find(f"{W}rPr/{W}sz")
                if e is not None:
                    try:
                        style_sz[sid] = float(e.get(W + "val"))
                    except (TypeError, ValueError):
                        pass
                nm = st.find(W + "name")
                nmv = ((nm.get(W + "val") if nm is not None else "")
                       or "").lower()
                m = re.search(r"heading\s*(\d)", nmv) or \
                    re.search(r"заголовок\s*(\d)", nmv)
                if m:
                    style_head[sid] = int(m.group(1))
        except ET.ParseError:
            pass

    # --- самый частый размер в документе = размер основного текста
    sz_count = {}
    for e in root.iter(W + "sz"):
        v = e.get(W + "val")
        if v:
            try:
                v = float(v)
                sz_count[v] = sz_count.get(v, 0) + 1
            except ValueError:
                pass
    body_sz = doc_sz or (max(sz_count, key=sz_count.get) if sz_count
                         else 22.0)

    # --- абзацы
    paras = []
    rid = 0
    for p in root.iter(W + "p"):
        ppr = p.find(W + "pPr")
        align = None
        pstyle = None
        bullet = False
        if ppr is not None:
            jc = ppr.find(W + "jc")
            if jc is not None:
                v = (jc.get(W + "val") or "").lower()
                align = {"center": "center", "right": "right",
                         "end": "right"}.get(v)
            ps = ppr.find(W + "pStyle")
            if ps is not None:
                pstyle = ps.get(W + "val")
            if ppr.find(W + "numPr") is not None:
                bullet = True

        parts = []  # (символ, b, i, u, sz, rid) либо ("\n", ...)
        for r in p.iter(W + "r"):
            b, i, u, sz = _run_style(r)
            rid += 1
            for node in r:
                if node.tag == W + "t":
                    for ch in (node.text or ""):
                        parts.append((ch, b, i, u, sz, rid))
                elif node.tag == W + "tab":
                    parts.append((" ", b, i, u, sz, rid))
                elif node.tag == W + "br":
                    parts.append(("\n", False, False, False, None, rid))

        if bullet and parts:
            rid += 1
            parts.insert(0, ("•", False, False, False, None, rid))
            parts.insert(1, (" ", False, False, False, None, rid))

        parts.append(("\n", False, False, False, None, rid))
        seg = []
        for item in parts:
            if item[0] == "\n":
                paras.append({"align": align, "pstyle": pstyle,
                              "chars": seg})
                seg = []
            else:
                seg.append(list(item))

    meta = {"body_sz": body_sz, "style_sz": style_sz,
            "style_head": style_head}
    _rich_ratios(paras, meta)
    return paras, meta


def _rich_ratios(paras, meta):
    """Каждому символу — ratio размера к основному тексту."""
    body = meta["body_sz"] or 22.0
    for para in paras:
        pstyle = para["pstyle"]
        para_sz = meta["style_sz"].get(pstyle) if pstyle else None
        head_lvl = meta["style_head"].get(pstyle) if pstyle else None
        for c in para["chars"]:
            sz = c[4]
            if sz is None:
                sz = para_sz
            if sz is None and head_lvl:
                sz = body * HEAD_RATIO.get(min(head_lvl, 5), 1.1)
            c.append(1.0 if sz is None else max(0.35, min(6.0, sz / body)))


def rich_empty(paras):
    return not any(p["chars"] for p in paras)


def _glyph_of(font, ch):
    g = font["glyphs"].get(ch)
    if g is None:
        alt = {"«": '"', "»": '"', "—": "-", "–": "-", "…": ".",
               "•": "-", "·": "-"}.get(ch)
        g = font["glyphs"].get(alt) if alt else None
    return g


def rich_width(font, chars, base_scale, spacing_mm):
    """Ширина последовательности символов в мм."""
    cap_u = cap_height_units(font)
    space_u = font["glyphs"].get(" ", {}).get("advance", cap_u / 3)
    w = 0.0
    for c in chars:
        g = _glyph_of(font, c[0])
        w += (g["advance"] if g else space_u) * base_scale * c[6]
        w += spacing_mm
    return w


def _rich_tokens(stream):
    """Поток символов -> токены: слова и группы пробелов (стили целы)."""
    toks = []
    cur = [stream[0]]
    for c in stream[1:]:
        if (c[0] == " ") == (cur[0][0] == " "):
            cur.append(c)
        else:
            toks.append(cur)
            cur = [c]
    toks.append(cur)
    return toks


def rich_wrap(font, paras, base_scale, spacing_mm, max_w):
    """
    Перенос абзацев «как есть» по словам.
    Возвращает строки {"chars", "w", "rmax", "align"}; None = разрыв абзаца.
    """
    lines = []
    for para in paras:
        align = para["align"]
        stream = para["chars"]
        if not stream:
            lines.append(None)
            continue

        def mk(chars_):
            return {
                "chars": chars_,
                "w": rich_width(font, chars_, base_scale, spacing_mm),
                "rmax": max(c[6] for c in chars_),
                "align": align,
            }

        def split_long(tok):
            chunks = []
            piece = []
            for c in tok:
                if piece and rich_width(font, piece + [c], base_scale,
                                        spacing_mm) > max_w:
                    chunks.append(piece)
                    piece = [c]
                else:
                    piece.append(c)
            if piece:
                chunks.append(piece)
            return chunks

        toks = _rich_tokens(stream)
        n_before = len(lines)
        line = None
        for tok in toks:
            is_space = tok[0][0] == " "
            if line is None:
                if is_space:
                    continue
                if rich_width(font, tok, base_scale, spacing_mm) > max_w:
                    chunks = split_long(tok)
                    for ch_ in chunks[:-1]:
                        lines.append(mk(ch_))
                    line = chunks[-1]
                else:
                    line = list(tok)
            else:
                if rich_width(font, line + tok, base_scale,
                              spacing_mm) <= max_w:
                    line = line + tok
                else:
                    lines.append(mk(line))
                    if is_space:
                        line = None
                    elif rich_width(font, tok, base_scale,
                                    spacing_mm) > max_w:
                        chunks = split_long(tok)
                        for ch_ in chunks[:-1]:
                            lines.append(mk(ch_))
                        line = chunks[-1]
                    else:
                        line = list(tok)
        if line:
            lines.append(mk(line))
        if len(lines) == n_before:
            lines.append(None)      # абзац из одних пробелов = разрыв

    return lines


def _variant_glyph(font, g, ch, bold, italic, sc, cache,
                   bold_style="shift", bold_off=0.12):
    """Глиф с преобразованиями стиля; жирный — утолщение штриха
    (тип закраски):
      shift  — второй штрих со сдвигом вправо (как было в 2.6-2.7,
               самый быстрый; буква на полтолщины шире);
      repeat — второй проход по тому же месту: чернила наслаиваются,
               буква темнее, ширина строки не меняется (шариковая ручка);
      wide   — три прохода: -off/2, 0, +off/2 — симметрично шире
               (максимально «жирный», времени уходит больше).
    Курсив = наклон. Кэшируется по (символ, стиль, масштаб)."""
    key = (ch, bold, italic, round(sc, 3), bold_style, round(bold_off, 4))
    v = cache.get(key)
    if v is not None:
        return v
    strokes = g["strokes"]
    if italic:
        strokes = [[(x + 0.16 * yv, yv) for x, yv in s] for s in strokes]
    if bold:
        off = (bold_off / sc) if sc > 1e-6 else 0.0
        st2 = []
        if bold_style == "repeat":
            for s in strokes:
                st2.append(s)
                st2.append(list(s))
        elif bold_style == "wide":
            for s in strokes:
                st2.append([(x - off / 2.0, yv) for x, yv in s])
                st2.append(list(s))
                st2.append([(x + off / 2.0, yv) for x, yv in s])
        else:  # shift — по умолчанию, совместимо с 2.6/2.7
            for s in strokes:
                st2.append(s)
                st2.append([(x + off, yv) for x, yv in s])
        strokes = st2
    v = {"advance": g["advance"], "strokes": strokes}
    cache[key] = v
    return v


def _rich_lines_at(font, paras, h, spacing_mm, max_w=None, wrap_on=True):
    """Строки «как есть» при высоте основного текста h."""
    cap_u = cap_height_units(font)
    base_scale = h / cap_u
    if max_w is None or not wrap_on:
        lines = []
        for para in paras:
            if not para["chars"]:
                lines.append(None)
                continue
            chars_ = para["chars"]
            lines.append({
                "chars": chars_,
                "w": rich_width(font, chars_, base_scale, spacing_mm),
                "rmax": max(c[6] for c in chars_),
                "align": para["align"],
            })
        return lines
    return rich_wrap(font, paras, base_scale, spacing_mm, max_w)


def build_rich_layout(font, lines, base_h, spacing_mm, line_factor,
                      x0_mm, y0_mm, area_w=None,
                      bold_style="shift", bold_off=0.12):
    """Строки -> items. Жирный — утолщение штриха (bold_style),
    курсив = наклон, подчёркнутый = линия под строкой. Baseline общий
    для строки. area_w — ширина текстовой области для центрирования/
    правого края; None (page off) — центрировать вокруг x0, как в
    обычном режиме."""
    cap_u = cap_height_units(font)
    base_scale = base_h / cap_u
    space_u = font["glyphs"].get(" ", {}).get("advance", cap_u / 3)

    items = []
    cache = {}
    warned = set()
    y = y0_mm
    li = 0
    for line in lines:
        if line is None:
            y -= base_h * line_factor
            li += 1
            continue

        off = 0.0
        if line["align"] == "center":
            off = ((area_w - line["w"]) / 2.0 if area_w is not None
                   else -line["w"] / 2.0)
        elif line["align"] == "right":
            off = (area_w - line["w"] if area_w is not None
                   else -line["w"])

        pen = 0.0
        marks = []  # [x_нач, x_кон, run_id, подчёркнут?, ratio]
        for ch, b, i, u, _sz, r_id, ratio in line["chars"]:
            g = _glyph_of(font, ch)
            sc = base_scale * ratio
            x_here = x0_mm + pen + off
            if g is None:
                if ch != " " and ch not in warned:
                    warned.add(ch)
                    print(f"  ! символ {ch!r} отсутствует в шрифте — пропуск")
                adv_u = space_u
            else:
                variant = _variant_glyph(font, g, ch, b, i, sc, cache,
                                         bold_style, bold_off)
                items.append((li, x_here, y, variant, sc))
                adv_u = g["advance"]
            marks.append([x_here, x_here + adv_u * sc, r_id, u, ratio])
            pen += adv_u * sc + spacing_mm

        # подчёркивание: непрерывные куски одного run'а
        k = 0
        while k < len(marks):
            if marks[k][3]:
                j = k
                while (j + 1 < len(marks)
                       and marks[j + 1][2] == marks[k][2]
                       and marks[j + 1][3]):
                    j += 1
                x1 = marks[k][0]
                x2 = marks[j][1]
                uy = -0.22 * base_h * marks[k][4]
                items.append((li, x1, y,
                              {"strokes": [[(0.0, uy), (x2 - x1, uy)]]},
                              1.0))
                k = j + 1
            else:
                k += 1

        y -= base_h * line_factor * line["rmax"]
        li += 1

    return items, base_scale


def _rich_drawn_text(lines):
    return "\n".join(
        "".join(c[0] for c in line["chars"])
        for line in lines if line is not None
    )


def fit_rich(font, paras, meta, args):
    """Вписывание «Word как есть» в лист. Возвращает как fit_items."""
    b_style = getattr(args, "bold_style", "shift")
    b_off = float(getattr(args, "bold_off", 0.12) or 0.0)
    if args.page == "off":
        lines = _rich_lines_at(font, paras, args.height, args.spacing,
                               wrap_on=args.wrap)
        items, scale = build_rich_layout(
            font, lines, args.height, args.spacing, args.line,
            args.x0, args.y0, bold_style=b_style, bold_off=b_off)
        return items, scale, [], None, None, _rich_drawn_text(lines)

    margin = args.margin
    pw_full, ph_full = PAGE_SIZES[args.page]

    def try_fit(orient):
        pw_o, ph_o = (pw_full, ph_full) if orient == "portrait" \
            else (ph_full, pw_full)
        avail_w = pw_o - 2 * margin
        avail_h = ph_o - 2 * margin
        h = args.height
        lines = []
        items = scale = None
        for _ in range(10):
            lines = _rich_lines_at(font, paras, h, args.spacing,
                                   avail_w, args.wrap)
            items, scale = build_rich_layout(
                font, lines, h, args.spacing, args.line,
                args.x0, args.y0, area_w=avail_w,
                bold_style=b_style, bold_off=b_off)
            bbox = items_bbox(items)
            if bbox is None:
                return None
            minx, maxx, miny, maxy = bbox
            W, H = maxx - minx, maxy - miny
            if W <= avail_w + 1e-6 and H <= avail_h + 1e-6:
                return items, scale, h, lines
            kw = avail_w / W if W > avail_w else 1.0
            kh = (avail_h / H) ** 0.5 if H > avail_h else 1.0
            k = min(kw, kh)
            if k >= 1.0:
                break
            h = max(0.1, math.floor(h * k * 10) / 10)
            if h <= 0.1:
                break
        return items, scale, h, lines

    if args.orient == "auto":
        r_p = try_fit("portrait")
        r_l = try_fit("landscape")
        if r_p is None and r_l is None:
            return [], 1.0, [], None, (pw_full, ph_full), ""
        if r_p is None:
            orient, res = "landscape", r_l
        elif r_l is None:
            orient, res = "portrait", r_p
        else:
            orient = "landscape" if r_l[2] > r_p[2] + 1e-9 else "portrait"
            res = r_l if orient == "landscape" else r_p
    else:
        orient = args.orient
        res = try_fit(orient)
        if res is None:
            return [], 1.0, [], None, (pw_full, ph_full), ""

    items, scale, h_eff, lines = res

    pw, ph = (pw_full, ph_full) if orient == "portrait" \
        else (ph_full, pw_full)
    avail_w = pw - 2 * margin
    avail_h = ph - 2 * margin

    notes = []
    page_note = f"лист {args.page.upper()} {orient}, поле {margin:g} мм"

    n_src = sum(1 for p in paras if p["chars"])
    n_out = sum(1 for l in lines if l is not None)
    if n_out > n_src:
        notes.append(
            f"перенос длинных строк: {n_src} -> {n_out} "
            f"(по ширине {avail_w:.0f} мм)"
        )
        page_note += f", перенос {n_src}->{n_out} стр."

    if h_eff < args.height - 1e-9:
        notes.append(
            f"высота букв уменьшена {args.height:g} -> {h_eff:g} мм, "
            f"чтобы всё поместилось"
        )
        page_note += f", масштаб {h_eff / args.height * 100:.0f}%"

    minx, maxx, miny, maxy = items_bbox(items)
    W, H = maxx - minx, maxy - miny

    dx = dy = 0.0
    if minx < margin:
        dx = margin - minx
    if maxx + dx > pw - margin:
        dx = pw - margin - maxx
    if miny < margin:
        dy = margin - miny
    if maxy + dy > ph - margin:
        dy = ph - margin - maxy
    if abs(dx) > 1e-6 or abs(dy) > 1e-6:
        notes.append(f"сдвиг внутрь листа: X{dx:+.1f} Y{dy:+.1f} мм")
        page_note += f", сдвиг X{dx:+.1f} Y{dy:+.1f}"
        items = [(li, x + dx, y + dy, g, sc)
                 for li, x, y, g, sc in items]

    page_note += f", текст {W:.0f}x{H:.0f} мм"
    return items, scale, notes, page_note, (pw, ph), _rich_drawn_text(lines)


def _load_content(path, args):
    """Файл -> (текст, rich_абзацы|None, метаданные|None)."""
    if path.lower().endswith(".docx") and getattr(args, "rich", True):
        try:
            paras, meta = read_docx_rich(path)
            if rich_empty(paras):
                return "", None, None
            return None, paras, meta
        except SystemExit as e:
            print(f"   ! Word «как есть» не удалось ({e}); "
                  f"печатаю как обычный текст")
        except Exception as e:
            print(f"   ! Word «как есть» не удалось ({e}); "
                  f"печатаю как обычный текст")
    return normalize_text(read_text_file(path)), None, None


def looks_like_text_file(path):
    return (
        os.path.isfile(path)
        and os.path.splitext(path)[1].lower() in TEXT_EXTENSIONS
    )


def load_font(ref):
    """ref: имя ('vasek'|'print') или путь к JSON."""
    if ref.endswith(".json") and os.path.exists(ref):
        path = ref
    else:
        cands = [
            os.path.join(SCRIPT_DIR, "fonts", ref + ".json"),
            os.path.join(SCRIPT_DIR, "fonts", ref.lower() + ".json"),
            os.path.join(SCRIPT_DIR, ref + ".json"),
            os.path.join(os.path.dirname(os.path.abspath(ref or ".")), ref + ".json"),
        ]
        for base in ("vasek_italic", "print_cyrillic"):
            if ref.lower() in base or base.replace("_", " ") == ref.lower():
                cands.insert(0, os.path.join(SCRIPT_DIR, "fonts", base + ".json"))

        path = next((c for c in cands if os.path.exists(c)), None)
        if path is None:
            sys.exit(f"Шрифт не найден: {ref!r}. Есть ли файл в {SCRIPT_DIR}/fonts ?")

    with open(path, encoding="utf-8") as f:
        return json.load(f)


def glyph_bbox_mm(g, scale):
    xs, ys = [], []
    for s in g["strokes"]:
        for p in s:
            xs.append(p[0])
            ys.append(p[1])

    if not xs:
        return None

    return (
        min(xs) * scale,
        max(xs) * scale,
        min(ys) * scale,
        max(ys) * scale,
    )


def cap_height_units(font):
    cap = font.get("cap_height")
    if cap:
        return float(cap)

    g = font["glyphs"].get("А") or font["glyphs"].get("A")
    if g and g["strokes"]:
        return max(p[1] for s in g["strokes"] for p in s)

    return font.get("upem", 1000) * 0.7


def translit_name(text, maxlen=24):
    t = text.replace("\n", " ")
    out = []
    for ch in t.lower():
        out.append(TRANSLIT.get(ch, ch if ch.isalnum() else "_"))

    s = re.sub(r"_+", "_", "".join(out)).strip("_") or "gcode"
    return s[:maxlen]


def parse_xy(s):
    try:
        x, y = s.split(",")
        return (float(x), float(y))
    except Exception:
        raise argparse.ArgumentTypeError(f"Ожидалось 'X,Y', получено {s!r}")


_DEC = 2  # знаков после запятой в координатах (мм); меняется --decimals


def fmt(v):
    v = float(v)
    if abs(v) < 0.0005:
        v = 0.0
    return f"{v:.{_DEC}f}"


def fword(f):
    """Подача без лишних нулей: 3000.0 -> 'F3000', 762.5 -> 'F762.5'."""
    s = f"{float(f):.3f}".rstrip("0").rstrip(".")
    return "F" + (s or "0")


def wrap_text_lines(font, text, height_mm, spacing_mm, max_w_mm):
    """
    Перенос длинных строк по словам в ширину max_w_mm (при высоте букв
    height_mm и межбуквенном интервале spacing_mm).

    Абзац из Блокнота/Word — это одна длинная строка на весь абзац.
    Без переноса такая строка ужимается до нечитаемой высоты. Здесь
    строка делится по пробелам, слишком длинное слово — по символам.

    Возвращает (список_строк, число_разрывов).
    """
    cap_u = cap_height_units(font)
    scale = height_mm / cap_u
    space_u = font["glyphs"].get(" ", {}).get("advance", cap_u / 3)

    def width_mm(s):
        w_units = 0.0
        n = 0
        for ch in s:
            g = font["glyphs"].get(ch)
            if g is None:
                alt = {"«": '"', "»": '"', "—": "-", "–": "-", "…": "."}.get(ch)
                g = font["glyphs"].get(alt) if alt else None
            w_units += g["advance"] if g else space_u
            n += 1
        return w_units * scale + n * spacing_mm

    out = []
    breaks = 0
    cur = [""]

    def push_word(w):
        # слово само длиннее строки — режем по символам
        piece = ""
        for chx in w:
            if piece and width_mm(piece + chx) > max_w_mm:
                out.append(piece)
                piece = chx
            else:
                piece += chx
        cur[0] = piece

    for src in text.split("\n"):
        if not src.strip():
            out.append("")          # пустая строка = разрыв абзаца
            cur[0] = ""
            continue

        if width_mm(src) <= max_w_mm:
            if cur[0]:
                out.append(cur[0])
                cur[0] = ""
            out.append(src)
            continue

        for word in src.split(" "):
            if not word:
                continue
            if not cur[0]:
                if width_mm(word) > max_w_mm:
                    push_word(word)
                    breaks += 1
                else:
                    cur[0] = word
                continue
            cand = cur[0] + " " + word
            if width_mm(cand) <= max_w_mm:
                cur[0] = cand
            else:
                out.append(cur[0])
                breaks += 1
                if width_mm(word) > max_w_mm:
                    push_word(word)
                else:
                    cur[0] = word
        if cur[0]:
            out.append(cur[0])
            cur[0] = ""

    return out, breaks


def build_layout(
    font,
    text,
    height_mm,
    spacing_mm,
    line_factor,
    align,
    x0_mm,
    y0_mm,
):
    """
    Возвращает:
      items = [(line_index, x_mm, y_mm, glyph, scale), ...]
      scale
    """
    cap_u = cap_height_units(font)
    scale = height_mm / cap_u
    space_u = font["glyphs"].get(" ", {}).get("advance", cap_u / 3)
    line_step = height_mm * line_factor

    lines = text.split("\n")
    result = []
    widths = []

    for li, line in enumerate(lines):
        pen_u = 0.0
        placed = []

        for ch in line:
            g = font["glyphs"].get(ch)

            if g is None:
                # замены нерисуемых символов
                alt = {"«": '"', "»": '"', "—": "-", "–": "-", "…": ".",
                       "•": "-", "·": "-"}.get(ch)
                g = font["glyphs"].get(alt) if alt else None

                if g is None:
                    print(f"  ! символ {ch!r} отсутствует в шрифте — пропуск")
                    pen_u += space_u
                    continue

            placed.append((pen_u, g))
            pen_u += g["advance"] + spacing_mm / scale

        widths.append(pen_u * scale)
        result.append(placed)

    out = []
    for li, placed in enumerate(result):
        y_mm = y0_mm - li * line_step
        off = 0.0

        if align == "center":
            off = -widths[li] / 2.0
        elif align == "right":
            off = -widths[li]

        for pen_u, g in placed:
            out.append((li, x0_mm + pen_u * scale + off, y_mm, g, scale))

    return out, scale


def items_bbox(items):
    """Габарит всей раскладки в мм: (minx, maxx, miny, maxy) или None."""
    minx = miny = float("inf")
    maxx = maxy = float("-inf")
    found = False

    for _li, x_mm, y_mm, glyph, sc in items:
        for stroke in glyph["strokes"]:
            for px, py in stroke:
                found = True
                x = x_mm + px * sc
                y = y_mm + py * sc
                if x < minx:
                    minx = x
                if x > maxx:
                    maxx = x
                if y < miny:
                    miny = y
                if y > maxy:
                    maxy = y

    if not found:
        return None

    return (minx, maxx, miny, maxy)


def _dedupe(pts, tol2=1e-12):
    """Убирает подряд идущие дублирующиеся точки полилинии."""
    out = [pts[0]]
    for p in pts[1:]:
        dx = p[0] - out[-1][0]
        dy = p[1] - out[-1][1]
        if dx * dx + dy * dy > tol2:
            out.append(p)
    return out


def line_polylines(items):
    """
    Раскладка -> штрихи построчно в мм:
      [(line_index, [[(x, y), ...], ...]), ...]
    """
    lines = {}

    for li, x_mm, y_mm, glyph, sc in items:
        bucket = lines.setdefault(li, [])

        for stroke in glyph["strokes"]:
            if not stroke:
                continue

            pts = [(x_mm + p[0] * sc, y_mm + p[1] * sc) for p in stroke]

            if len(pts) == 1:
                bucket.append(pts)
                continue

            clean = _dedupe(pts)
            bucket.append(clean if len(clean) > 1 else [clean[0]])

    return sorted(lines.items())


def merge_polylines(polys, eps):
    """
    Сшивка штрихов в непрерывные трассы (главная оптимизация пера).

    Если конец текущей трассы (или её начало) находится не дальше eps мм
    от начала/конца одной из оставшихся полилиний — она продолжает трассу,
    при надобности в обратном направлении. Перо в таких местах НЕ
    поднимается: вместо кучи отдельных штрихов получаются длинные
    непрерывные линии. Порядок рисования может меняться — на бумаге
    результат тот же самый.

    Возвращает (трассы, число_склеек).
    """
    remaining = [list(p) for p in polys]

    if eps <= 0 or len(remaining) < 2:
        return remaining, 0

    eps2 = eps * eps
    merged = []
    cur = remaining.pop(0)
    joined = 0

    def nearest(px, py):
        """Ближайшая оставшаяся полилиния к точке: (индекс, d2, с_конца?)."""
        bi, bd, brev = -1, float("inf"), False
        for i, s in enumerate(remaining):
            dx = s[0][0] - px
            dy = s[0][1] - py
            d = dx * dx + dy * dy
            if d < bd:
                bd, bi, brev = d, i, False
            dx = s[-1][0] - px
            dy = s[-1][1] - py
            d = dx * dx + dy * dy
            if d < bd:
                bd, bi, brev = d, i, True
        return bi, bd, brev

    while remaining:
        # 1) продолжение с хвоста текущей трассы
        bi, bd, brev = nearest(cur[-1][0], cur[-1][1])
        if bd <= eps2:
            s = remaining.pop(bi)
            if brev:
                s.reverse()
            cur.extend(s)
            joined += 1
            continue

        # 2) продолжение с головы (трасса растёт назад)
        bi, bd, brev = nearest(cur[0][0], cur[0][1])
        if bd <= eps2:
            s = remaining.pop(bi)
            if brev:
                s.reverse()
            cur = s + cur
            joined += 1
            continue

        # 3) трасса закончена — новая начинается с ближайшей оставшейся
        merged.append(cur)
        bi, bd, brev = nearest(cur[-1][0], cur[-1][1])
        s = remaining.pop(bi)
        if brev:
            s.reverse()
        cur = s

    merged.append(cur)
    return merged, joined


def _seg_cross(p1, p2, p3, p4):
    def ccw(a, b, c):
        return (c[1] - a[1]) * (b[0] - a[0]) > (b[1] - a[1]) * (c[0] - a[0])
    return (ccw(p1, p3, p4) != ccw(p2, p3, p4)
            and ccw(p1, p2, p3) != ccw(p1, p2, p4))


def _dist_to_seg(p, a, b):
    ax, ay = a
    bx, by = b
    px, py = p
    dx, dy = bx - ax, by - ay
    L2 = dx * dx + dy * dy
    if L2 < 1e-12:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / L2))
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def _bridge_crosses(a, b, polys, skip_pair, tol):
    """Пересекает ли отрезок a->b чужие штрихи (кроме стыкуемых).

    Пересечения в пределах tol от концов стыка не считаются — там
    штрихи и должны сходиться."""
    i, j = skip_pair
    for k, s in enumerate(polys):
        if k in (i, j):
            continue
        for m in range(len(s) - 1):
            c, d = s[m], s[m + 1]
            if (_dist_to_seg(a, c, d) < tol
                    or _dist_to_seg(b, c, d) < tol):
                continue
            if _seg_cross(a, b, c, d):
                return True
    return False


def bridge_polylines(polys, eps):
    """Перемычки между штрихами (связное письмо) с защитой от

    "зачеркиваний": перемычка ставится только если прямая между
    концами не пересекает другие штрихи строки. Порядок может
    меняться — на бумаге результат тот же.

    Возвращает (трассы, число_склеек)."""
    remaining = [list(p) for p in polys]
    if eps <= 0 or len(remaining) < 2:
        return remaining, 0

    eps2 = eps * eps
    tol = min(0.2, eps * 0.35)     # зона законного контакта у стыка, мм
    merged = []
    cur = remaining.pop(0)
    joined = 0

    def candidates(px, py):
        """Оставшиеся полилинии по расстоянию до точки:
        [(d2, индекс, с_конца?), ...]"""
        out = []
        for i, s in enumerate(remaining):
            dx = s[0][0] - px
            dy = s[0][1] - py
            out.append((dx * dx + dy * dy, i, False))
            dx = s[-1][0] - px
            dy = s[-1][1] - py
            out.append((dx * dx + dy * dy, i, True))
        out.sort(key=lambda c: c[0])
        return out

    while remaining:
        done = False
        for d2, bi, brev in candidates(cur[-1][0], cur[-1][1]):
            if d2 > eps2:
                break               # дальше все ещё дальше
            s = remaining[bi]
            tip = s[-1] if brev else s[0]
            if _bridge_crosses(cur[-1], tip, remaining + [cur],
                               (bi, len(remaining)), tol):
                continue            # перемычка пересекает штрих — ищем другую
            s = remaining.pop(bi)
            if brev:
                s.reverse()
            cur.extend(s)
            joined += 1
            done = True
            break
        if done:
            continue

        # к голове текущей трассы
        for d2, bi, brev in candidates(cur[0][0], cur[0][1]):
            if d2 > eps2:
                break
            s = remaining[bi]
            tip = s[-1] if brev else s[0]
            if _bridge_crosses(cur[0], tip, remaining + [cur],
                               (bi, len(remaining)), tol):
                continue
            s = remaining.pop(bi)
            if brev:
                s.reverse()
            cur = s + cur
            joined += 1
            done = True
            break
        if done:
            continue

        # трасса закончена — новая начинается с ближайшей оставшейся
        merged.append(cur)
        d2, bi, brev = candidates(cur[-1][0], cur[-1][1])[0]
        s = remaining.pop(bi)
        if brev:
            s.reverse()
        cur = s

    merged.append(cur)
    return merged, joined


def build_pen_paths(items, eps, link_eps=0.0):
    """
    items -> полилинии построчно со сшивкой (две ступени).

    Ступень 1 (eps, невидимые стыки) — сшивает совпадающие/почти
    совпадающие концы штрихов.
    Ступень 2 (link_eps > eps, перемычки) — догоняет более крупные зазоры:
    концы букв, засечки печатного шрифта — рисуются короткой линией без
    подъёма пера, как связное письмо.

    Возвращает (pen_paths, было, после_ступени_1, итог, число_перемычек):
      pen_paths = [(line_index, [полилиния, ...]), ...]
    """
    raw = joined = bridges = 0
    out = []

    for li, polys in line_polylines(items):
        raw += len(polys)
        merged, j1 = merge_polylines(polys, eps)
        joined += len(merged)

        if link_eps > eps:
            merged, nb = bridge_polylines(merged, link_eps)
            bridges += nb

        out.append((li, [_dedupe(m) if len(m) > 1 else m for m in merged]))

    became = sum(len(m) for _, m in out)
    return out, raw, joined, became, bridges


def fit_items(font, text, args):
    """
    Раскладка текста и вписывание в лист (--page, по умолчанию A4).

    1. Длинные строки (абзацы из Блокнота/Word) переносятся по словам
       в ширину листа (--wrap on) — буквы остаются крупными.
    2. Если и после переноса текст не влезает по высоте — высота букв
       уменьшается (с повторным переносом: буквы ниже — строк влезает
       больше, поэтому выигрыш квадратичный).
    3. Ориентация auto: выбирается та, где буквы в итоге выше.
    4. Последний рубеж — сдвиг внутрь печатной области.

    Возвращает (items, scale, notes, page_note, (pw, ph)|None,
    нарисованный_текст).
    """
    if args.page == "off":
        items, scale = build_layout(
            font, text, args.height, args.spacing,
            args.line, args.align, args.x0, args.y0,
        )
        return items, scale, [], None, None, text

    margin = args.margin
    pw_full, ph_full = PAGE_SIZES[args.page]
    wrap_on = getattr(args, "wrap", True)

    def try_fit(orient):
        """Подбирает высоту букв (с переносом строк) для ориентации.

        Возвращает (items, scale, h, строки) или None для пустого текста."""
        pw_o, ph_o = (
            (pw_full, ph_full) if orient == "portrait" else (ph_full, pw_full)
        )
        avail_w = pw_o - 2 * margin
        avail_h = ph_o - 2 * margin

        h = args.height
        wrapped = text.split("\n")
        items = scale = None

        for _ in range(10):
            if wrap_on:
                wrapped, _nb = wrap_text_lines(
                    font, text, h, args.spacing, avail_w
                )
                sp = args.spacing
            else:
                # без переноса интервал сжимается вместе с буквами,
                # иначе строка из сотен символов не влезет ни при какой высоте
                wrapped = text.split("\n")
                sp = args.spacing * (h / args.height)

            items, scale = build_layout(
                font, "\n".join(wrapped), h, sp,
                args.line, args.align, args.x0, args.y0,
            )
            bbox = items_bbox(items)
            if bbox is None:
                return None

            minx, maxx, miny, maxy = bbox
            W = maxx - minx
            H = maxy - miny

            if W <= avail_w + 1e-6 and H <= avail_h + 1e-6:
                return items, scale, h, wrapped

            kw = avail_w / W if W > avail_w else 1.0
            if H > avail_h:
                kh = (avail_h / H) ** 0.5 if wrap_on else avail_h / H
            else:
                kh = 1.0
            k = min(kw, kh)
            if k >= 1.0:
                break
            h = max(0.1, math.floor(h * k * 10) / 10)
            if h <= 0.1:
                break

        return items, scale, h, wrapped

    # Ориентация: auto выбирает ту, где после переноса буквы выше
    if args.orient == "auto":
        r_p = try_fit("portrait")
        r_l = try_fit("landscape")

        if r_p is None and r_l is None:
            return [], 1.0, [], None, (pw_full, ph_full), text
        if r_p is None:
            orient, res = "landscape", r_l
        elif r_l is None:
            orient, res = "portrait", r_p
        else:
            orient = "landscape" if r_l[2] > r_p[2] + 1e-9 else "portrait"
            res = r_l if orient == "landscape" else r_p
    else:
        orient = args.orient
        res = try_fit(orient)
        if res is None:
            return [], 1.0, [], None, (pw_full, ph_full), text

    items, scale, h_eff, wrapped_lines = res

    pw, ph = (pw_full, ph_full) if orient == "portrait" else (ph_full, pw_full)
    avail_w = pw - 2 * margin
    avail_h = ph - 2 * margin

    notes = []
    page_note = f"лист {args.page.upper()} {orient}, поле {margin:g} мм"

    n_src = len(text.split("\n"))
    if len(wrapped_lines) > n_src:
        notes.append(
            f"перенос длинных строк: {n_src} -> {len(wrapped_lines)} "
            f"(по ширине {avail_w:.0f} мм)"
        )
        page_note += f", перенос {n_src}->{len(wrapped_lines)} стр."

    if h_eff < args.height - 1e-9:
        notes.append(
            f"высота букв уменьшена {args.height:g} -> {h_eff:g} мм, "
            f"чтобы все строки поместились"
        )
        page_note += f", масштаб {h_eff / args.height * 100:.0f}%"

    minx, maxx, miny, maxy = items_bbox(items)
    W = maxx - minx
    H = maxy - miny

    # Сдвиг внутрь печатной области
    dx = 0.0
    dy = 0.0
    if minx < margin:
        dx = margin - minx
    if maxx + dx > pw - margin:
        dx = pw - margin - maxx
    if miny < margin:
        dy = margin - miny
    if maxy + dy > ph - margin:
        dy = ph - margin - maxy

    if abs(dx) > 1e-6 or abs(dy) > 1e-6:
        notes.append(f"сдвиг внутрь листа: X{dx:+.1f} Y{dy:+.1f} мм")
        page_note += f", сдвиг X{dx:+.1f} Y{dy:+.1f}"
        items = [(li, x + dx, y + dy, g, sc) for li, x, y, g, sc in items]

    page_note += f", текст {W:.0f}x{H:.0f} мм"
    return items, scale, notes, page_note, (pw, ph), "\n".join(wrapped_lines)


def gcode_from_items(text, font, pen_paths, args, source_path=None,
                     page_note=None, lifts=None):
    """
    pen_paths — полилинии в мм со сшивкой: [(line_index, [...]), ...].
    lifts — (штрихов_было, стало_трасс, eps) для шапки .nc.
    """
    global _DEC
    _DEC = max(2, min(4, int(getattr(args, "decimals", 2) or 2)))
    g = []

    g.append("; ==== text2gcode.py — перьевой плоттер FluidNC/GRBL ====")
    if source_path:
        g.append(f"; источник: {source_path}")
    g.append(f"; текст: {text.replace(chr(10), ' / ')}")
    if page_note:
        g.append(f"; {page_note}")
    g.append(
        f"; шрифт: {font.get('name', 'unknown')}  "
        f"высота букв: {fmt(args.height)} мм"
    )
    g.append(
        f"; перо: Z{fmt(args.z_down)}=вниз, Z{fmt(args.z_up)}=вверх  "
        f"подачи: рисование F{fmt(args.f_draw)}, "
        f"подвод F{fmt(args.f_travel)}, Z F{fmt(args.f_z)}"
    )
    if lifts and lifts["final"] < lifts["raw"]:
        if lifts["bridges"] > 0:
            g.append(
                f"; оптимизация: сшивка (допуск {lifts['eps']:.2f} мм) "
                f"+ перемычки (до {lifts['link']:.2f} мм) — "
                f"подъёмов пера {lifts['raw']} -> {lifts['final']}"
            )
        else:
            g.append(
                f"; оптимизация: сшивка штрихов (допуск {lifts['eps']:.2f} мм) — "
                f"подъёмов пера {lifts['raw']} -> {lifts['final']}"
            )
    g.append(
        f"; создано: {datetime.datetime.now().isoformat(timespec='seconds')}"
    )

    g.append("G21 ; mm")
    g.append("G90 ; absolute")
    g.append(f"G0 Z{fmt(args.z_up)} ; перо вверх")

    # Подача модальная (как в GRBL и положено): слово F ставится только
    # при СМЕНЕ скорости — файл заметно короче, запись на SD и печать
    # по USB быстрее.
    last_f = [None]

    def fw(f):
        if last_f[0] is None or abs(float(f) - last_f[0]) > 0.001:
            last_f[0] = float(f)
            return fword(f)
        return ""

    def travel(x, y):
        g.append(f"G0 X{fmt(x)} Y{fmt(y)} {fw(args.f_travel)}".rstrip())

    def pen_down():
        g.append(f"G1 Z{fmt(args.z_down)} {fw(args.f_z)}".rstrip())

    stats = {
        "strokes": 0,
        "lifts_raw": (lifts["raw"] if lifts else 0),
        "draw": 0.0,
        "travel": 0.0,
        "downs": 0,
    }

    z_hop = getattr(args, "z_hop", 0.0) or 0.0
    hop = z_hop if 0.0 < z_hop < args.z_up else 0.0

    prev_end = None
    first = True

    for _li, polys in pen_paths:
        for stroke in polys:
            pts = list(stroke)

            # Точка/точка-тире: делаем минимальный штрих, чтобы перо
            # что-то оставило
            if len(pts) == 1 or (len(pts) == 2 and pts[0] == pts[1]):
                pts = [pts[0], (pts[0][0] + 0.05, pts[0][1])]

            if first:
                travel(*pts[0])
                pen_down()
                first = False
            else:
                dx = pts[0][0] - prev_end[0]
                dy = pts[0][1] - prev_end[1]
                d = (dx * dx + dy * dy) ** 0.5
                stats["travel"] += d

                # Короткий переход — поднимаем перо чуть-чуть (--z-hop)
                z_lvl = hop if (hop and d <= 5.0) else args.z_up
                g.append(f"G0 Z{fmt(z_lvl)}")
                travel(*pts[0])
                pen_down()

            stats["downs"] += 1

            cur = pts[0]
            for px, py in pts[1:]:
                g.append(f"G1 X{fmt(px)} Y{fmt(py)} {fw(args.f_draw)}".rstrip())

                dx = px - cur[0]
                dy = py - cur[1]
                stats["draw"] += (dx * dx + dy * dy) ** 0.5

                cur = (px, py)

            stats["strokes"] += 1
            prev_end = cur

    g.append("; конец")
    g.append(f"G0 Z{fmt(args.z_up + 5)} ; перо высоко вверх")

    if args.home:
        g.append(
            f"G0 X{fmt(args.home[0])} Y{fmt(args.home[1])} "
            f"{fw(args.f_travel)}".rstrip()
        )

    return g, stats


def render_preview(png_path, pen_paths, args, page=None):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)

    if page:
        # рамка листа и печатной области — видно, как текст вписан в A4
        pw, ph = page
        m = args.margin
        ax.add_patch(
            plt.Rectangle((0, 0), pw, ph, fill=False, ec="#999999", lw=1.2)
        )
        if pw - 2 * m > 0 and ph - 2 * m > 0:
            ax.add_patch(
                plt.Rectangle(
                    (m, m), pw - 2 * m, ph - 2 * m,
                    fill=False, ec="#cccccc", lw=0.8, ls="--",
                )
            )
        ax.set_xlim(-6, pw + 6)
        ax.set_ylim(-6, ph + 6)

    for _li, polys in pen_paths:
        for pts in polys:
            if len(pts) >= 2:
                xs, ys = zip(*pts)
                ax.plot(xs, ys, "k-", lw=1.0)
            elif pts:
                ax.plot([pts[0][0]], [pts[0][1]], "k.", ms=2)

    ax.set_aspect("equal")
    ax.axis("off")
    fig.savefig(png_path, dpi=110)
    plt.close(fig)


def estimate_minutes(stats, args):
    t_draw = stats["draw"] / args.f_draw if args.f_draw else 0.0
    z_range = abs(args.z_up - args.z_down)
    t_move = stats["downs"] * z_range / args.f_z if args.f_z else 0.0
    t_travel = stats["travel"] / args.f_travel if args.f_travel else 0.0
    return t_draw + t_move + t_travel


def generate_one(text, source_path, out_path, font, args, preview_path=None,
                 rich=None, rich_meta=None):
    # Интервал по умолчанию: рукописным шрифтам 0 (буквы уже соединены),
    # печатным 0.6 мм
    if getattr(args, "spacing", None) is None:
        args.spacing = 0.0 if font.get("cursive") else 0.6

    if rich is not None:
        items, scale, notes, page_note, page, drawn_text = fit_rich(
            font, rich, rich_meta, args
        )
    else:
        items, scale, notes, page_note, page, drawn_text = fit_items(
            font, text, args
        )

    for note in notes:
        print(f"   * {note}")

    # Допуск сшивки: auto = 3% фактической высоты букв (0.3 мм при 10 мм)
    if args.join_eps is None:
        eff_h = cap_height_units(font) * scale
        eps = min(0.5, max(0.05, 0.03 * eff_h))
    else:
        eps = args.join_eps

    # Перемычки (связное письмо): auto = 20% высоты букв — хватает на
    # стыки букв рукописного шрифта, а защита от пересечений ниже
    # не даёт перемычкам рисовать через буквы
    if args.link_mm is None:
        link = 0.20 * cap_height_units(font) * scale
    else:
        link = args.link_mm

    pen_paths, raw_n, joined_n, opt_n, n_bridges = build_pen_paths(
        items, eps, link
    )

    if eps > 0 and joined_n < raw_n:
        print(
            f"   * сшивка штрихов: подъёмов пера {raw_n} -> {joined_n} "
            f"(допуск {eps:.2f} мм)"
        )

    if link > eps and opt_n < joined_n:
        print(
            f"   * перемычки (до {link:.2f} мм): "
            f"подъёмов пера {joined_n} -> {opt_n}"
        )

    # Контроль: все ли точки внутри печатной области листа
    if page:
        pts = [p for _, polys in pen_paths for poly in polys for p in poly]
        if pts:
            pw_, ph_ = page
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            inside = (
                min(xs) >= args.margin - 0.5
                and min(ys) >= args.margin - 0.5
                and max(xs) <= pw_ - args.margin + 0.5
                and max(ys) <= ph_ - args.margin + 0.5
            )
            size_txt = f"{max(xs) - min(xs):.0f}x{max(ys) - min(ys):.0f} мм"
            if inside:
                print(
                    f"   габарит {size_txt} — внутри листа "
                    f"{args.page.upper()} {pw_:.0f}x{ph_:.0f} мм"
                )
            else:
                print(
                    f"   ! ВНИМАНИЕ: габарит {size_txt} выходит за "
                    f"печатную область {args.page.upper()} "
                    f"{pw_:.0f}x{ph_:.0f} мм (поле {args.margin:g} мм)"
                )

    g, stats = gcode_from_items(
        drawn_text, font, pen_paths, args, source_path, page_note,
        lifts={
            "raw": raw_n,
            "joined": joined_n,
            "final": opt_n,
            "eps": eps,
            "link": link,
            "bridges": n_bridges,
        },
    )

    with open(out_path, "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(g) + "\n")

    if preview_path:
        try:
            render_preview(preview_path, pen_paths, args, page)
            print(f"   превью -> {preview_path}")
        except ImportError:
            print("   ! для превью нужен matplotlib:  pip install matplotlib")
        except Exception as e:
            print(f"   ! превью не создано: {e}")

    return stats, items


def find_txt_files(directory, recursive=False):
    directory = os.path.abspath(directory)

    if not os.path.isdir(directory):
        sys.exit(f"Каталог не найден: {directory!r}")

    files = []

    def wanted(name):
        return name.lower().endswith((".txt", ".docx"))

    if recursive:
        for root, dirs, names in os.walk(directory):
            dirs.sort()
            for name in sorted(names):
                if wanted(name):
                    full = os.path.join(root, name)
                    if os.path.isfile(full):
                        files.append(full)
    else:
        for name in sorted(os.listdir(directory)):
            if wanted(name):
                full = os.path.join(directory, name)
                if os.path.isfile(full):
                    files.append(full)

    return files


def main():
    ap = argparse.ArgumentParser(
        description="Текст/файл/все *.txt/*.docx -> G-code для перьевого плоттера (FluidNC/GRBL)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    ap.add_argument(
        "--version",
        action="version",
        version=f"text2gcode {VERSION}",
    )

    ap.add_argument(
        "text",
        nargs="?",
        default=None,
        help=r"текст; \n = новая строка. Если это существующий .txt/.docx файл — будет прочитан из файла",
    )

    ap.add_argument(
        "--file",
        "--in",
        "-i",
        dest="text_file",
        default=None,
        metavar="FILE",
        help="прочитать текст из файла: .txt из Блокнота или .docx из Word",
    )

    ap.add_argument(
        "--all-txt",
        action="store_true",
        help="обработать все *.txt и *.docx в каталоге (--dir, по умолчанию текущий)",
    )

    ap.add_argument(
        "--dir",
        default=None,
        metavar="DIR",
        help="каталог для --all-txt; если указан, включает пакетный режим",
    )

    ap.add_argument(
        "--recursive",
        action="store_true",
        help="вместе с --all-txt искать файлы также в подпапках",
    )

    ap.add_argument(
        "--font",
        default="vasek",
        help="шрифт: vasek | print | путь к JSON",
    )

    ap.add_argument(
        "--out",
        default=None,
        help="имя .nc файла; нельзя использовать вместе с --all-txt",
    )

    ap.add_argument(
        "--height",
        type=float,
        default=10,
        help="высота ЗАГЛАВНЫХ букв, мм",
    )

    ap.add_argument(
        "--spacing",
        type=float,
        default=None,
        metavar="ММ",
        help="дополнительный межбуквенный интервал, мм; по умолчанию auto: "
             "0 для рукописных шрифтов (у них буквы уже соединены), "
             "0.6 для печатных",
    )

    ap.add_argument(
        "--line",
        type=float,
        default=1.8,
        help="межстрочный интервал, кратный высоте",
    )

    ap.add_argument(
        "--align",
        choices=["left", "center", "right"],
        default="left",
    )

    ap.add_argument(
        "--x0",
        type=float,
        default=10.0,
        help="X начала текста, мм",
    )

    ap.add_argument(
        "--y0",
        type=float,
        default=100.0,
        help="Y базовой линии 1-й строки, мм",
    )

    ap.add_argument(
        "--page",
        choices=["a4", "a3", "a5", "letter", "off"],
        default="a4",
        help="лист для вписывания текста; off = без ограничений",
    )

    ap.add_argument(
        "--orient",
        choices=["portrait", "landscape", "auto"],
        default="auto",
        help="ориентация листа; auto выберет лучшую сам",
    )

    ap.add_argument(
        "--margin",
        type=float,
        default=10.0,
        help="поле от края листа, мм",
    )

    ap.add_argument(
        "--wrap",
        choices=["on", "off"],
        default="on",
        help="перенос длинных строк по словам при вписывании в лист "
             "(абзацы из Блокнота/Word не дают буквам сжиматься в нить); "
             "off = строка как есть, только с уменьшением высоты",
    )

    ap.add_argument(
        "--rich",
        choices=["on", "off"],
        default="on",
        help="Word «как есть» для .docx: жирный, курсив, подчёркнутый, "
             "размеры, заголовки, центрирование; off = только текст",
    )

    ap.add_argument(
        "--bold-style",
        choices=["shift", "repeat", "wide"],
        default="repeat",
        help="чем рисовать ЖИРНЫЙ в Word (тип закраски штрихом): "
             "repeat = второй проход по тому же месту, темнее — для "
             "шариковой ручки (по умолчанию); shift = второй штрих "
             "со сдвигом вправо (как было в 2.6-2.7, самый быстрый); "
             "wide = три прохода, симметрично шире",
    )

    ap.add_argument(
        "--bold-off",
        type=float,
        default=0.12,
        metavar="ММ",
        help="утолщение жирного, мм (для --bold-style shift/wide)",
    )

    ap.add_argument(
        "--join-eps",
        type=float,
        default=None,
        metavar="ММ",
        help="допуск сшивки штрихов (рисовать без подъёма пера), мм; "
             "по умолчанию auto = 3%% высоты букв; 0 — выключить",
    )

    ap.add_argument(
        "--link-mm",
        type=float,
        default=None,
        metavar="ММ",
        help="перемычки между буквами (связное письмо): соединять без "
             "подъёма пера зазоры до этой длины, мм; по умолчанию "
             "auto = 15%% высоты букв; 0 — выключить",
    )

    ap.add_argument(
        "--z-hop",
        type=float,
        default=0.0,
        metavar="ММ",
        help="короткие переходы (до 5 мм) поднимать на эту высоту вместо "
             "--z-up, мм; 0 — выключено (по умолчанию)",
    )

    ap.add_argument(
        "--z-up",
        type=float,
        default=4.0,
        help="Z поднятия пера, мм",
    )

    ap.add_argument(
        "--z-down",
        type=float,
        default=0.0,
        help="Z прижатия пера, мм",
    )

    ap.add_argument(
        "--f-draw",
        type=float,
        default=3000.0,
        help="подача рисования, мм/мин",
    )

    ap.add_argument(
        "--f-travel",
        type=float,
        default=9000.0,
        help="подача подвода, мм/мин",
    )

    ap.add_argument(
        "--f-z",
        type=float,
        default=9000.0,
        help="подача Z / пера, мм/мин",
    )

    ap.add_argument(
        "--decimals",
        type=int,
        default=2,
        choices=(2, 3, 4),
        help="знаков в координатах: 2 = шаг 0.01 мм (файл меньше на ~25%%, "
             "запись на SD и печать быстрее); 3 = как в старых версиях",
    )

    ap.add_argument(
        "--home",
        type=parse_xy,
        default=None,
        metavar="'X,Y'",
        help="вернуться в точку 'X,Y' в конце",
    )

    ap.add_argument(
        "--preview",
        nargs="?",
        const="auto",
        default=None,
        metavar="PATH",
        help=(
            "PNG предпросмотр. В одиночном режиме: имя файла или каталог. "
            "В режиме --all-txt: auto или каталог."
        ),
    )

    args = ap.parse_args()
    args.wrap = args.wrap == "on"
    args.rich = args.rich == "on"

    # Если ничего не указано — молча обрабатываем все .txt рядом.
    if (
        args.text is None
        and args.text_file is None
        and not args.all_txt
        and args.dir is None
    ):
        args.all_txt = True
        args.dir = "."

    # --dir сам по себе включает пакетный режим.
    if args.dir is not None and not args.all_txt:
        args.all_txt = True

    # ------------------------------------------------------------------
    # Пакетный режим: все *.txt
    # ------------------------------------------------------------------
    if args.all_txt:
        if args.text is not None or args.text_file is not None:
            ap.error("--all-txt нельзя совмещать с текстом или --file")

        if args.out is not None:
            ap.error(
                "--all-txt нельзя совмещать с --out; "
                "каждый .txt сохранится как .nc рядом с собой"
            )

        directory = args.dir or "."
        files = find_txt_files(directory, args.recursive)

        if not files:
            print(f"Не найдено *.txt в {os.path.abspath(directory)}")
            return

        font = load_font(args.font)

        total = {
            "files": 0,
            "strokes": 0,
            "lifts_raw": 0,
            "downs": 0,
            "draw": 0.0,
            "travel": 0.0,
            "minutes": 0.0,
        }

        ok = 0
        skipped = 0
        failed = 0

        for src in files:
            try:
                text, rich, rmeta = _load_content(src, args)

                if rich is None and not text.strip():
                    print(f"-- {src}: пусто, пропуск")
                    skipped += 1
                    continue

                out = os.path.splitext(src)[0] + ".nc"

                preview_path = None
                if args.preview:
                    pv = str(args.preview)

                    if pv.lower() == "auto":
                        preview_path = os.path.splitext(out)[0] + ".png"
                    elif os.path.isdir(pv):
                        preview_path = os.path.join(
                            pv,
                            os.path.splitext(os.path.basename(out))[0] + ".png",
                        )
                    else:
                        sys.exit(
                            "В режиме --all-txt --preview должен быть 'auto' "
                            "или существующий каталог"
                        )

                stats, _ = generate_one(
                    text, src, out, font, args, preview_path,
                    rich=rich, rich_meta=rmeta,
                )
                minutes = estimate_minutes(stats, args)

                if stats.get("lifts_raw", 0) > stats["strokes"]:
                    lifts_info = (
                        f"подъёмов: {stats['lifts_raw']}->{stats['strokes']}, "
                    )
                else:
                    lifts_info = f"штрихов: {stats['strokes']}, "

                print(f"OK -> {out}  {lifts_info}~{minutes:.1f} мин")

                total["files"] += 1
                total["strokes"] += stats["strokes"]
                total["lifts_raw"] += stats.get("lifts_raw", 0)
                total["downs"] += stats["downs"]
                total["draw"] += stats["draw"]
                total["travel"] += stats["travel"]
                total["minutes"] += minutes

                ok += 1

            except SystemExit:
                raise
            except Exception as e:
                print(f"! {src}: {e}")
                failed += 1

        if total["lifts_raw"] > total["strokes"]:
            lift_txt = (
                f"подъёмов пера {total['lifts_raw']}->{total['strokes']}, "
            )
        else:
            lift_txt = f"штрихов {total['strokes']}, "

        print(
            f"Готово: файлов {ok}, пропущено {skipped}, ошибок {failed}; "
            f"{lift_txt}"
            f"путь рисования {total['draw']:.0f} мм, "
            f"подвод {total['travel']:.0f} мм, "
            f"оценка времени ~{total['minutes']:.1f} мин"
        )
        return

    # ------------------------------------------------------------------
    # Одиночный режим
    # ------------------------------------------------------------------
    rich = rmeta = None
    source_path = None

    if args.text_file:
        if args.text is not None:
            ap.error(
                "Нельзя одновременно указывать текст и --file. "
                "Оставьте что-то одно."
            )

        text, rich, rmeta = _load_content(args.text_file, args)
        source_path = args.text_file

    elif args.text is None:
        ap.error("Нужен текст или файл с текстом (--file).")

    else:
        if looks_like_text_file(args.text):
            text, rich, rmeta = _load_content(args.text, args)
            source_path = args.text
        else:
            text = normalize_text(args.text.replace(r"\n", "\n"))

    out = args.out

    if out is None:
        if source_path:
            out = os.path.splitext(source_path)[0] + ".nc"
        else:
            out = translit_name(text) + ".nc"

    if not out.lower().endswith(".nc"):
        out += ".nc"

    preview_path = None
    if args.preview:
        pv = str(args.preview)

        if pv.lower() == "auto":
            preview_path = os.path.splitext(out)[0] + ".png"
        elif os.path.isdir(pv):
            preview_path = os.path.join(
                pv,
                os.path.splitext(os.path.basename(out))[0] + ".png",
            )
        else:
            preview_path = pv

    font = load_font(args.font)

    stats, _ = generate_one(
        text, source_path, out, font, args, preview_path,
        rich=rich, rich_meta=rmeta,
    )
    minutes = estimate_minutes(stats, args)

    print(f"OK -> {out}")
    if stats.get("lifts_raw", 0) > stats["strokes"]:
        print(
            f"   подъёмов пера: {stats['lifts_raw']} -> {stats['strokes']} "
            f"(сшивка штрихов)"
        )
    else:
        print(f"   штрихов (опусканий пера): {stats['strokes']}")
    print(
        f"   путь рисования: {stats['draw']:.0f} мм, "
        f"подвод: {stats['travel']:.0f} мм, "
        f"оценка времени ~{minutes:.1f} мин"
    )


if __name__ == "__main__":
    main()
